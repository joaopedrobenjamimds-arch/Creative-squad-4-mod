package com.cs4.reliquias.command;

import com.cs4.reliquias.relic.RelicManager;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class Cs4Command {
    private Cs4Command() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                CommandManager.literal("cs4")
                        .requires(source -> source.hasPermissionLevel(2))
                        .then(CommandManager.literal("reliquias")
                                .executes(context -> {
                                    ServerPlayerEntity player = context.getSource().getPlayerOrThrow();
                                    ItemStack shulkerBox = RelicManager.createRelicsShulkerBox();
                                    player.giveOrDropStack(shulkerBox);
                                    context.getSource().sendFeedback(
                                            () -> Text.literal("Você recebeu a Shulker Box com as Relíquias CS4.")
                                                    .formatted(Formatting.YELLOW),
                                            false
                                    );
                                    return 1;
                                })
                        )
        );
    }
}
