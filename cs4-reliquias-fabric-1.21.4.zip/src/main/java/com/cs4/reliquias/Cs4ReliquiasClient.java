package com.cs4.reliquias;

import net.fabricmc.api.ClientModInitializer;

public class Cs4ReliquiasClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Renderização e efeitos visuais das relíquias são processados via Mixins de RenderState.
    }
}
