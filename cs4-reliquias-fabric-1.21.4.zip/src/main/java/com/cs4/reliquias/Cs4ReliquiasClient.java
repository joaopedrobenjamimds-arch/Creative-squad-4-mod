package com.cs4.reliquias;

import com.cs4.reliquias.client.ClientDisguiseCache;
import com.cs4.reliquias.client.RelogioScreen;
import com.cs4.reliquias.network.OpenRelogioPayload;
import com.cs4.reliquias.network.SyncDisguisesPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class Cs4ReliquiasClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(OpenRelogioPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        context.client().setScreen(new RelogioScreen(payload))
                )
        );

        ClientPlayNetworking.registerGlobalReceiver(SyncDisguisesPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        ClientDisguiseCache.setAll(payload.disguises())
                )
        );

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
                ClientDisguiseCache.clear()
        );
    }
}
