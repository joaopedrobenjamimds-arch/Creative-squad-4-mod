package com.cs4.reliquias.relic;

import com.cs4.reliquias.Cs4ReliquiasMod;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.component.type.UseCooldownComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class RelicManager {
    public static final String RELIC_NBT_KEY = "cs4_relic";
    public static final String TRACK_UUID_KEY = "cs4_track_uuid";
    public static final String TRACK_NAME_KEY = "cs4_track_name";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String RELOGIO_ID = "relogio_lendario";
    public static final String BUSSOLA_ID = "bussola_lendaria";

    private RelicManager() {
    }

    public static ItemStack createLampiaoLendario() {
        ItemStack stack = new ItemStack(Items.SOUL_LANTERN, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, LAMPIAO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Lampião Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        return stack;
    }

    public static ItemStack createEscudoLendario() {
        ItemStack stack = new ItemStack(Items.SHIELD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, ESCUDO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Escudo Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(15.0F, Optional.of(Identifier.of(Cs4ReliquiasMod.MOD_ID, ESCUDO_ID)))
        );
        return stack;
    }

    public static ItemStack createReliquiaMineracao(RegistryWrapper.WrapperLookup registries) {
        ItemStack stack = new ItemStack(Items.IRON_PICKAXE, 1);
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquia da mineração").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));

        RegistryEntry<Enchantment> efficiencyEntry = registries
                .getOrThrow(RegistryKeys.ENCHANTMENT)
                .getOrThrow(Enchantments.EFFICIENCY);

        ItemEnchantmentsComponent.Builder enchantments = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
        enchantments.set(efficiencyEntry, 1000);
        stack.set(DataComponentTypes.ENCHANTMENTS, enchantments.build().withShowInTooltip(false));
        return stack;
    }

    public static ItemStack createRelogioLendario() {
        ItemStack stack = new ItemStack(Items.CLOCK, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, RELOGIO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relógio Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        return stack;
    }

    public static ItemStack createBussolaLendaria() {
        ItemStack stack = new ItemStack(Items.COMPASS, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, BUSSOLA_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Bússola Lendária").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        return stack;
    }

    public static ItemStack createRelicsShulkerBox(RegistryWrapper.WrapperLookup registries) {
        ItemStack shulker = new ItemStack(Items.BLACK_SHULKER_BOX, 1);
        shulker.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquias CS4").styled(style -> style.withColor(Formatting.GOLD).withItalic(false))
        );
        List<ItemStack> relics = List.of(
                createLampiaoLendario(),
                createEscudoLendario(),
                createReliquiaMineracao(registries),
                createRelogioLendario(),
                createBussolaLendaria()
        );
        shulker.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(relics));
        return shulker;
    }

    public static boolean isLampiaoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SOUL_LANTERN)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return LAMPIAO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isEscudoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SHIELD)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return ESCUDO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isRelogioLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.CLOCK)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return RELOGIO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isBussolaLendaria(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.COMPASS)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return BUSSOLA_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static UUID getTrackedTargetUuid(ItemStack stack) {
        if (!isBussolaLendaria(stack)) {
            return null;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return null;
        }
        NbtCompound nbt = customData.copyNbt();
        String rawUuid = nbt.getString(TRACK_UUID_KEY);
        if (rawUuid == null || rawUuid.isEmpty()) {
            return null;
        }
        try {
            return UUID.fromString(rawUuid);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    public static String getTrackedTargetName(ItemStack stack) {
        if (!isBussolaLendaria(stack)) {
            return "";
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return "";
        }
        return customData.copyNbt().getString(TRACK_NAME_KEY);
    }

    public static void setTrackedTarget(ItemStack stack, UUID targetUuid, String targetName) {
        if (!isBussolaLendaria(stack) || targetUuid == null) {
            return;
        }
        NbtComponent existing = stack.get(DataComponentTypes.CUSTOM_DATA);
        NbtCompound nbt = existing != null ? existing.copyNbt() : new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, BUSSOLA_ID);
        nbt.putString(TRACK_UUID_KEY, targetUuid.toString());
        nbt.putString(TRACK_NAME_KEY, targetName != null ? targetName : "");
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
    }

    public static boolean isHoldingLampiao(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isLampiaoLendario(player.getMainHandStack())
                || isLampiaoLendario(player.getOffHandStack());
    }

    public static boolean isHoldingRelogio(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isRelogioLendario(player.getMainHandStack())
                || isRelogioLendario(player.getOffHandStack());
    }

    public static boolean isHoldingBussola(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isBussolaLendaria(player.getMainHandStack())
                || isBussolaLendaria(player.getOffHandStack());
    }
}
