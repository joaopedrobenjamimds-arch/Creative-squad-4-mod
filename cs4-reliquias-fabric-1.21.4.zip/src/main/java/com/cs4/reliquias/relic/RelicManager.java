package com.cs4.reliquias.relic;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

public final class RelicManager {
    public static final String RELIC_NBT_KEY = "cs4_relic";
    public static final String LAMPIAO_ID = "lampiao_lendario";

    private RelicManager() {
    }

    public static ItemStack createLampiaoLendario() {
        ItemStack stack = new ItemStack(Items.SOUL_LANTERN, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, LAMPIAO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Lampião Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        return stack;
    }

    public static ItemStack createRelicsShulkerBox() {
        ItemStack shulker = new ItemStack(Items.BLACK_SHULKER_BOX, 1);
        shulker.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquias CS4").styled(style -> style.withColor(Formatting.GOLD).withItalic(false))
        );
        List<ItemStack> relics = List.of(
                createLampiaoLendario()
        );
        shulker.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(relics));
        return shulker;
    }

    public static boolean isLampiaoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SOUL_LANTERN)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return LAMPIAO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isHoldingLampiao(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isLampiaoLendario(player.getMainHandStack())
                || isLampiaoLendario(player.getOffHandStack());
    }
}
