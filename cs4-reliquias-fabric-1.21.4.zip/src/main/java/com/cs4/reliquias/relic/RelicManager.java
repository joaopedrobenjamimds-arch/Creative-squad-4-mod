package com.cs4.reliquias.relic;

import com.cs4.reliquias.Cs4ReliquiasMod;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.component.type.UseCooldownComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Optional;

public final class RelicManager {
    public static final String RELIC_NBT_KEY = "cs4_relic";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String ESCUDO_ID = "escudo_lendario";

    private RelicManager() {
    }

    public static ItemStack createLampiaoLendario() {
        ItemStack stack = new ItemStack(Items.SOUL_LANTERN, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, LAMPIAO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Lampião Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        return stack;
    }

    public static ItemStack createEscudoLendario() {
        ItemStack stack = new ItemStack(Items.SHIELD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, ESCUDO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Escudo Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(15.0F, Optional.of(Identifier.of(Cs4ReliquiasMod.MOD_ID, ESCUDO_ID)))
        );
        return stack;
    }

    public static ItemStack createReliquiaMineracao(RegistryWrapper.WrapperLookup registries) {
        ItemStack stack = new ItemStack(Items.IRON_PICKAXE, 1);
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquia da mineração").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));

        RegistryEntry<Enchantment> efficiencyEntry = registries
                .getOrThrow(RegistryKeys.ENCHANTMENT)
                .getOrThrow(Enchantments.EFFICIENCY);

        ItemEnchantmentsComponent.Builder enchantments = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
        enchantments.set(efficiencyEntry, 1000);
        stack.set(DataComponentTypes.ENCHANTMENTS, enchantments.build().withShowInTooltip(false));
        return stack;
    }

    public static ItemStack createRelicsShulkerBox(RegistryWrapper.WrapperLookup registries) {
        ItemStack shulker = new ItemStack(Items.BLACK_SHULKER_BOX, 1);
        shulker.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquias CS4").styled(style -> style.withColor(Formatting.GOLD).withItalic(false))
        );
        List<ItemStack> relics = List.of(
                createLampiaoLendario(),
                createEscudoLendario(),
                createReliquiaMineracao(registries)
        );
        shulker.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(relics));
        return shulker;
    }

    public static boolean isLampiaoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SOUL_LANTERN)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return LAMPIAO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isEscudoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SHIELD)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return ESCUDO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isHoldingLampiao(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isLampiaoLendario(player.getMainHandStack())
                || isLampiaoLendario(player.getOffHandStack());
    }
}
