package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockItem.class)
public class BlockItemMixin {
    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("HEAD"), cancellable = true)
    private void cs4$preventLampiaoPlacement(ItemPlacementContext context, CallbackInfoReturnable<ActionResult> cir) {
        if (RelicManager.isLampiaoLendario(context.getStack())) {
            cir.setReturnValue(ActionResult.FAIL);
        }
    }
}
