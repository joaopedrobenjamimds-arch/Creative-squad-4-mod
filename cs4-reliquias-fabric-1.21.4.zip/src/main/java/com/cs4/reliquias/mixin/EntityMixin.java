package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "isInvisible", at = @At("HEAD"), cancellable = true)
    private void cs4$isInvisibleWithLampiao(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity player && RelicManager.isHoldingLampiao(player)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void cs4$isInvisibleToWithLampiao(PlayerEntity viewer, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity holder && RelicManager.isHoldingLampiao(holder)) {
            cir.setReturnValue(true);
        }
    }
}
