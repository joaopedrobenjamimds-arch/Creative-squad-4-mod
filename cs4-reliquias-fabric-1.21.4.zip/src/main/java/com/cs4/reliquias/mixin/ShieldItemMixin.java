package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.SonicBoomAbility;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.consume.UseAction;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ShieldItem.class)
public class ShieldItemMixin {
    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void cs4$useEscudoLendario(World world, PlayerEntity user, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack stack = user.getStackInHand(hand);
        if (!RelicManager.isEscudoLendario(stack)) {
            return;
        }

        if (user.getItemCooldownManager().isCoolingDown(stack)) {
            cir.setReturnValue(ActionResult.FAIL);
            return;
        }

        if (world instanceof ServerWorld serverWorld) {
            SonicBoomAbility.fire(serverWorld, user, stack);
        }
        cir.setReturnValue(ActionResult.SUCCESS);
    }

    @Inject(method = "getUseAction", at = @At("HEAD"), cancellable = true)
    private void cs4$disableShieldUseAction(ItemStack stack, CallbackInfoReturnable<UseAction> cir) {
        if (RelicManager.isEscudoLendario(stack)) {
            cir.setReturnValue(UseAction.NONE);
        }
    }

    @Inject(method = "getMaxUseTime", at = @At("HEAD"), cancellable = true)
    private void cs4$disableShieldMaxUseTime(ItemStack stack, LivingEntity user, CallbackInfoReturnable<Integer> cir) {
        if (RelicManager.isEscudoLendario(stack)) {
            cir.setReturnValue(0);
        }
    }
}
