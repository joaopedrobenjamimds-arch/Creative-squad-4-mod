package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
    @Inject(
            method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("TAIL")
    )
    private void cs4$applyLampiaoState(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (RelicManager.isHoldingLampiao(player)) {
            state.invisible = true;
            state.invisibleToPlayer = true;
            state.displayName = null;
            state.nameLabelPos = null;
            state.hasOutline = false;
            state.capeVisible = false;
            state.stuckArrowCount = 0;
            state.stingerCount = 0;
            state.leftHandItemState.clear();
            state.rightHandItemState.clear();
            state.headItemRenderState.clear();
            state.wearingSkullProfile = null;
            state.wearingSkullType = null;
            state.equippedHeadStack = ItemStack.EMPTY;
            state.equippedLegsStack = ItemStack.EMPTY;
            state.equippedFeetStack = ItemStack.EMPTY;
            if (!state.equippedChestStack.isOf(Items.ELYTRA)) {
                state.equippedChestStack = ItemStack.EMPTY;
            }
        }
    }

    @Inject(method = "renderRightArm", at = @At("HEAD"), cancellable = true)
    private void cs4$hideFirstPersonRightArm(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            Identifier skinTexture,
            boolean sleeveVisible,
            CallbackInfo ci
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && RelicManager.isHoldingLampiao(client.player)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"), cancellable = true)
    private void cs4$hideFirstPersonLeftArm(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            Identifier skinTexture,
            boolean sleeveVisible,
            CallbackInfo ci
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && RelicManager.isHoldingLampiao(client.player)) {
            ci.cancel();
        }
    }
}
