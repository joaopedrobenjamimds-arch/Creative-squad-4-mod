package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.ServerTwinHelmetManager;
import com.cs4.reliquias.relic.SonicBoomAbility;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerPlayerEntity.class)
public class ServerPlayerEntityMixin {
    @Inject(method = "shouldDamagePlayer", at = @At("HEAD"), cancellable = true)
    private void cs4$allowSonicBoomOnPlayers(PlayerEntity attacker, CallbackInfoReturnable<Boolean> cir) {
        if (SonicBoomAbility.isApplying()) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void cs4$linkTwinHelmetDeath(DamageSource damageSource, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;
        ServerTwinHelmetManager.onWearerDeath(self);
    }
}
