package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.client.LampiaoRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(LivingEntityRenderState.class)
public class LivingEntityRenderStateMixin implements LampiaoRenderState {
    @Unique
    private boolean cs4$lampiaoActive;

    @Override
    public boolean cs4$isLampiaoActive() {
        return this.cs4$lampiaoActive;
    }

    @Override
    public void cs4$setLampiaoActive(boolean active) {
        this.cs4$lampiaoActive = active;
    }
}
