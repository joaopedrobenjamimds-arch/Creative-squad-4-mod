package com.cs4.reliquias;

import com.cs4.reliquias.command.Cs4Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

public class Cs4ReliquiasMod implements ModInitializer {
    public static final String MOD_ID = "cs4reliquias";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                Cs4Command.register(dispatcher)
        );
    }
}
