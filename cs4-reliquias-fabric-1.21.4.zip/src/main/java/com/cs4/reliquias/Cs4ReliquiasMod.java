package com.cs4.reliquias;

import com.cs4.reliquias.command.Cs4Command;
import com.cs4.reliquias.compass.ServerCompassManager;
import com.cs4.reliquias.disguise.DisguiseState;
import com.cs4.reliquias.disguise.ServerDisguiseManager;
import com.cs4.reliquias.network.OpenBussolaPayload;
import com.cs4.reliquias.network.OpenRelogioPayload;
import com.cs4.reliquias.network.SelectCompassTargetPayload;
import com.cs4.reliquias.network.SelectDisguisePayload;
import com.cs4.reliquias.network.SyncCompassTargetsPayload;
import com.cs4.reliquias.network.SyncDisguisesPayload;
import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerTwinHelmetManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;

public class Cs4ReliquiasMod implements ModInitializer {
    public static final String MOD_ID = "cs4reliquias";

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(OpenRelogioPayload.ID, OpenRelogioPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncDisguisesPayload.ID, SyncDisguisesPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectDisguisePayload.ID, SelectDisguisePayload.CODEC);

        PayloadTypeRegistry.playS2C().register(OpenBussolaPayload.ID, OpenBussolaPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncCompassTargetsPayload.ID, SyncCompassTargetsPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectCompassTargetPayload.ID, SelectCompassTargetPayload.CODEC);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                Cs4Command.register(dispatcher)
        );

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (RelicManager.isRelogioLendario(stack)) {
                if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
                    ServerDisguiseManager.sendOpenGui(serverPlayer);
                }
                return ActionResult.SUCCESS;
            }
            if (RelicManager.isBussolaLendaria(stack)) {
                if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
                    ServerCompassManager.sendOpenGui(serverPlayer, stack);
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        ServerPlayNetworking.registerGlobalReceiver(SelectDisguisePayload.ID, (payload, context) ->
                context.server().execute(() ->
                        ServerDisguiseManager.handleSelection(context.server(), context.player(), payload.targetUuid())
                )
        );

        ServerPlayNetworking.registerGlobalReceiver(SelectCompassTargetPayload.ID, (payload, context) ->
                context.server().execute(() ->
                        ServerCompassManager.handleSelection(context.server(), context.player(), payload.targetUuid())
                )
        );

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                ServerDisguiseManager.syncToPlayer(handler.player)
        );

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerCompassManager.onDisconnect(handler.player.getUuid());
            ServerTwinHelmetManager.onDisconnect(handler.player.getUuid());
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            ServerCompassManager.tick(server);
            ServerTwinHelmetManager.tick(server);
        });

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            DisguiseState.clearServer();
            ServerCompassManager.clearServer();
            ServerTwinHelmetManager.clearServer();
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            DisguiseState.clearServer();
            ServerCompassManager.clearServer();
            ServerTwinHelmetManager.clearServer();
        });
    }
}
