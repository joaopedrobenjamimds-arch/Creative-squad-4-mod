package com.cs4.reliquias;

import com.cs4.reliquias.command.Cs4Command;
import com.cs4.reliquias.relic.RelicManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.util.ActionResult;

public class Cs4ReliquiasMod implements ModInitializer {
    public static final String MOD_ID = "cs4reliquias";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                Cs4Command.register(dispatcher)
        );

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (RelicManager.isLampiaoLendario(player.getStackInHand(hand))) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }
}
