package com.cs4.reliquias;

import com.cs4.reliquias.command.Cs4Command;
import com.cs4.reliquias.disguise.DisguiseState;
import com.cs4.reliquias.disguise.ServerDisguiseManager;
import com.cs4.reliquias.network.OpenRelogioPayload;
import com.cs4.reliquias.network.SelectDisguisePayload;
import com.cs4.reliquias.network.SyncDisguisesPayload;
import com.cs4.reliquias.relic.RelicManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;

public class Cs4ReliquiasMod implements ModInitializer {
    public static final String MOD_ID = "cs4reliquias";

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(OpenRelogioPayload.ID, OpenRelogioPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncDisguisesPayload.ID, SyncDisguisesPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectDisguisePayload.ID, SelectDisguisePayload.CODEC);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                Cs4Command.register(dispatcher)
        );

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!RelicManager.isRelogioLendario(stack)) {
                return ActionResult.PASS;
            }
            if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
                ServerDisguiseManager.sendOpenGui(serverPlayer);
            }
            return ActionResult.SUCCESS;
        });

        ServerPlayNetworking.registerGlobalReceiver(SelectDisguisePayload.ID, (payload, context) ->
                context.server().execute(() ->
                        ServerDisguiseManager.handleSelection(context.server(), context.player(), payload.targetUuid())
                )
        );

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                ServerDisguiseManager.syncToPlayer(handler.player)
        );

        ServerLifecycleEvents.SERVER_STARTING.register(server -> DisguiseState.clearServer());
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> DisguiseState.clearServer());
    }
}
