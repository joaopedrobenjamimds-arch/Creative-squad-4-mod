package com.cs4.reliquias.client;

import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.disguise.DisguiseState;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.client.util.SkinTextures;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ClientDisguiseCache {
    private static final Map<String, GameProfile> PROFILE_CACHE = new ConcurrentHashMap<>();
    private static final ThreadLocal<Boolean> READING_LIST_ENTRY = ThreadLocal.withInitial(() -> false);

    private ClientDisguiseCache() {
    }

    public static void setAll(Map<UUID, DisguiseData> disguises) {
        DisguiseState.clientMap().clear();
        DisguiseState.clientMap().putAll(disguises);
    }

    public static void clear() {
        DisguiseState.clearClient();
        PROFILE_CACHE.clear();
    }

    public static boolean isReadingListEntry() {
        return Boolean.TRUE.equals(READING_LIST_ENTRY.get());
    }

    public static SkinTextures resolveSkinTextures(DisguiseData data) {
        if (data == null) {
            return DefaultSkinHelper.getSteve();
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (data.textureValue() != null && !data.textureValue().isEmpty()) {
            String key = data.targetUuid() + ":" + data.textureValue().hashCode();
            GameProfile profile = PROFILE_CACHE.computeIfAbsent(key, ignored -> data.toGameProfile());
            return client.getSkinProvider().getSkinTextures(profile);
        }

        if (client.getNetworkHandler() != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(data.targetUuid());
            if (entry != null && !isReadingListEntry()) {
                READING_LIST_ENTRY.set(true);
                try {
                    if (DisguiseState.getClientDisguise(data.targetUuid()) == null) {
                        return entry.getSkinTextures();
                    }
                } finally {
                    READING_LIST_ENTRY.set(false);
                }
            }
        }

        return DefaultSkinHelper.getSkinTextures(data.targetUuid());
    }
}
