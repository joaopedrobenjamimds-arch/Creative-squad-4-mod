package com.cs4.reliquias.client;

public interface LampiaoRenderState {
    boolean cs4$isLampiaoActive();

    void cs4$setLampiaoActive(boolean active);
}
