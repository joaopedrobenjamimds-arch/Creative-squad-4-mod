# CS4 Relíquias (Minecraft 1.21.4 - Fabric)

Mod inspirado nos Itens Lendários da Creative Squad 4, utilizando exclusivamente itens vanilla modificados via Data Components e Mixins.

## Relíquias incluídas nesta versão
- **Relíquia 01 — Lampião Lendário** (`minecraft:soul_lantern`)
  - Nome amarelo: `Lampião Lendário`
  - Invisibilidade automática ao segurar na mão principal ou secundária
  - Zero partículas
  - Oculta corpo, skin, armadura, itens nas mãos (em 3ª pessoa/multiplayer) e nametag, mantendo a **Elytra visível** e a proteção da armadura intacta
  - Em 1ª pessoa: mão invisível, itens nas mãos visíveis
  - Bloqueado de ser colocado no chão, permitindo interação normal com baús, shulkers, botões e portas
- **Relíquia 02 — Escudo Lendário** (`minecraft:shield`)
  - Nome amarelo: `Escudo Lendário`
  - Não defende ataques; o botão direito dispara diretamente uma rajada sônica na direção em que o jogador estiver olhando
  - Efeito visual e sonoro do Sonic Boom do Warden
  - Causa 4 corações de dano (8 HP) em mobs e jogadores ignorando completamente a armadura do alvo
  - Recarga individual de 15 segundos por jogador
- **Relíquia da mineração** (`minecraft:iron_pickaxe`)
  - Nome amarelo: `Relíquia da mineração`, brilho de encantamento, Eficiência 1000 (tooltip oculto) e inquebrável
- **Relíquia 04 — Relógio Lendário** (`minecraft:clock`)
  - Nome amarelo: `Relógio Lendário`
  - Botão direito abre uma GUI personalizada listando todos os jogadores online com cabeça e nome
  - Permite assumir fielmente a skin e o nome visual do jogador escolhido (sincronizado no multiplayer)
  - Possui botão **Voltar ao Normal** para restaurar completamente a skin e o nome originais
- **Relíquia 05 — Bússola Lendária** (`minecraft:compass`)
  - Nome amarelo: `Bússola Lendária`
  - Botão direito abre a mesma GUI de jogadores online com cabeça e nome
  - Ao clicar em um jogador, a bússola passa a apontar continuamente para ele, atualizando dinamicamente conforme o alvo se movimenta no multiplayer
- Obtido via comando: `/cs4 reliquias` (entrega uma Shulker Box Preta com as relíquias)

## Como compilar o arquivo .jar

### Opção 1: Compilação local (Java 21 + Gradle)
1. Instale o **Java 21 (JDK)** e o **Gradle 8.12+** (ou abra esta pasta no **IntelliJ IDEA**, que baixa o Gradle automaticamente).
2. No terminal dentro da pasta do projeto, execute:
   ```bash
   gradle build
   ```
3. O arquivo `.jar` compilado estará em `build/libs/cs4-reliquias-1.0.0.jar`.

### Opção 2: Compilação automática via GitHub Actions (sem instalar Java)
1. Envie esta pasta para um repositório no GitHub.
2. Abra a aba **Actions** do repositório e execute o workflow **Build CS4 Relíquias Mod**.
3. Baixe o arquivo `.jar` pronto nos **Artifacts** da execução.

## Instalação no Minecraft
1. Instale o **Fabric Loader** para **Minecraft 1.21.4**.
2. Coloque na pasta `mods/`:
   - `fabric-api-0.119.2+1.21.4.jar` (ou versão compatível da Fabric API para 1.21.4)
   - `cs4-reliquias-1.0.0.jar`
3. No jogo (com OP/cheats ativados), execute `/cs4 reliquias`.
