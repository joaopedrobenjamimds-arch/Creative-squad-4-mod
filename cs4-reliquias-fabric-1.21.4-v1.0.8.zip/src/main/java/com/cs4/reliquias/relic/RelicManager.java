package com.cs4.reliquias.relic;

import com.cs4.reliquias.Cs4ReliquiasMod;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.component.type.UseCooldownComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class RelicManager {
    public static final String RELIC_NBT_KEY = "cs4_relic";
    public static final String TRACK_UUID_KEY = "cs4_track_uuid";
    public static final String TRACK_NAME_KEY = "cs4_track_name";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String RELOGIO_ID = "relogio_lendario";
    public static final String BUSSOLA_ID = "bussola_lendaria";
    public static final String CAPACETE_GEMEOS_ID = "capacete_gemeos";
    public static final String TRIDENTE_ID = "tridente_lendario";
    public static final String ESPADA_CACADOR_ID = "espada_cacador";
    public static final String BOTA_LENDARIA_ID = "bota_lendaria";
    public static final String POCAO_ID = "pocao_lendaria";
    public static final String DRAGAO_ID = "dragao_lendario";
    public static final String PENA_ID = "pena_lendaria";
    public static final String BATATA_BOBO_ID = "batata_do_bobo";
    public static final int POCAO_LENDARIA_COLOR = 0x9B30FF;

    private RelicManager() {
    }

    public static ItemStack createLampiaoLendario() {
        ItemStack stack = new ItemStack(Items.SOUL_LANTERN, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, LAMPIAO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Lampião Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        return stack;
    }

    public static ItemStack createEscudoLendario() {
        ItemStack stack = new ItemStack(Items.SHIELD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, ESCUDO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Escudo Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(15.0F, Optional.of(Identifier.of(Cs4ReliquiasMod.MOD_ID, ESCUDO_ID)))
        );
        return stack;
    }

    public static ItemStack createReliquiaMineracao(RegistryWrapper.WrapperLookup registries) {
        ItemStack stack = new ItemStack(Items.IRON_PICKAXE, 1);
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquia da mineração").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));

        RegistryEntry<Enchantment> efficiencyEntry = registries
                .getOrThrow(RegistryKeys.ENCHANTMENT)
                .getOrThrow(Enchantments.EFFICIENCY);

        ItemEnchantmentsComponent.Builder enchantments = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
        enchantments.set(efficiencyEntry, 1000);
        stack.set(DataComponentTypes.ENCHANTMENTS, enchantments.build().withShowInTooltip(false));
        return stack;
    }

    public static ItemStack createRelogioLendario() {
        ItemStack stack = new ItemStack(Items.CLOCK, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, RELOGIO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relógio Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        return stack;
    }

    public static ItemStack createBussolaLendaria() {
        ItemStack stack = new ItemStack(Items.COMPASS, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, BUSSOLA_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Bússola Lendária").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        return stack;
    }

    public static ItemStack createCapaceteGemeos() {
        ItemStack stack = new ItemStack(Items.TURTLE_HELMET, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, CAPACETE_GEMEOS_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Capacete Lendário dos Gêmeos").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));

        AttributeModifiersComponent baseModifiers = Items.TURTLE_HELMET.getComponents()
                .getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        AttributeModifiersComponent modifiers = baseModifiers.with(
                EntityAttributes.MAX_HEALTH,
                new EntityAttributeModifier(
                        Identifier.of(Cs4ReliquiasMod.MOD_ID, "capacete_gemeos_vida"),
                        10.0,
                        EntityAttributeModifier.Operation.ADD_VALUE
                ),
                AttributeModifierSlot.HEAD
        );
        stack.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, modifiers);
        return stack;
    }

    public static ItemStack createTridenteLendario(RegistryWrapper.WrapperLookup registries) {
        ItemStack stack = new ItemStack(Items.TRIDENT, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, TRIDENTE_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Tridente Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));

        RegistryWrapper.Impl<Enchantment> enchantmentRegistry = registries.getOrThrow(RegistryKeys.ENCHANTMENT);
        ItemEnchantmentsComponent.Builder enchantments = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
        enchantments.set(enchantmentRegistry.getOrThrow(Enchantments.LOYALTY), 3);
        enchantments.set(enchantmentRegistry.getOrThrow(Enchantments.IMPALING), 7);
        enchantments.set(enchantmentRegistry.getOrThrow(Enchantments.SHARPNESS), 7);
        stack.set(DataComponentTypes.ENCHANTMENTS, enchantments.build());

        AttributeModifiersComponent modifiers = AttributeModifiersComponent.builder()
                .add(
                        EntityAttributes.ATTACK_DAMAGE,
                        new EntityAttributeModifier(
                                Item.BASE_ATTACK_DAMAGE_MODIFIER_ID,
                                8.0,
                                EntityAttributeModifier.Operation.ADD_VALUE
                        ),
                        AttributeModifierSlot.MAINHAND
                )
                .add(
                        EntityAttributes.ATTACK_SPEED,
                        new EntityAttributeModifier(
                                Item.BASE_ATTACK_SPEED_MODIFIER_ID,
                                -1.6,
                                EntityAttributeModifier.Operation.ADD_VALUE
                        ),
                        AttributeModifierSlot.MAINHAND
                )
                .build();
        stack.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, modifiers);
        return stack;
    }

    public static ItemStack createEspadaCacador(RegistryWrapper.WrapperLookup registries) {
        ItemStack stack = new ItemStack(Items.GOLDEN_SWORD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, ESPADA_CACADOR_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Espada do Caçador").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));

        RegistryWrapper.Impl<Enchantment> enchantmentRegistry = registries.getOrThrow(RegistryKeys.ENCHANTMENT);
        ItemEnchantmentsComponent.Builder enchantments = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
        enchantments.set(enchantmentRegistry.getOrThrow(Enchantments.KNOCKBACK), 10);
        stack.set(DataComponentTypes.ENCHANTMENTS, enchantments.build());
        return stack;
    }

    public static ItemStack createBotaLendaria() {
        ItemStack stack = new ItemStack(Items.DIAMOND_BOOTS, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, BOTA_LENDARIA_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Bota Lendária").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        return stack;
    }

    public static ItemStack createPocaoLendaria() {
        ItemStack stack = new ItemStack(Items.SPLASH_POTION, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, POCAO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Poção Lendária").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(
                DataComponentTypes.POTION_CONTENTS,
                new PotionContentsComponent(
                        Optional.empty(),
                        Optional.of(POCAO_LENDARIA_COLOR),
                        List.of(),
                        Optional.empty()
                )
        );
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(10.0F, Optional.of(Identifier.of(Cs4ReliquiasMod.MOD_ID, POCAO_ID)))
        );
        return stack;
    }

    public static ItemStack createDragaoLendario() {
        ItemStack stack = new ItemStack(Items.DRAGON_HEAD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, DRAGAO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Dragão Lendário").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.remove(DataComponentTypes.EQUIPPABLE);
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(5.0F, Optional.of(Identifier.of(Cs4ReliquiasMod.MOD_ID, DRAGAO_ID)))
        );
        return stack;
    }

    public static ItemStack createPenaLendaria() {
        ItemStack stack = new ItemStack(Items.FEATHER, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, PENA_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Pena Lendária").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        return stack;
    }

    public static ItemStack createBatataBobo() {
        ItemStack stack = new ItemStack(Items.POISONOUS_POTATO, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, BATATA_BOBO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        stack.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Batata do Bobo").styled(style -> style.withColor(Formatting.YELLOW).withItalic(false))
        );
        stack.remove(DataComponentTypes.CONSUMABLE);
        stack.remove(DataComponentTypes.FOOD);
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        return stack;
    }

    public static ItemStack createRelicsShulkerBox(RegistryWrapper.WrapperLookup registries) {
        ItemStack shulker = new ItemStack(Items.BLACK_SHULKER_BOX, 1);
        shulker.set(
                DataComponentTypes.CUSTOM_NAME,
                Text.literal("Relíquias CS4").styled(style -> style.withColor(Formatting.GOLD).withItalic(false))
        );
        List<ItemStack> relics = List.of(
                createLampiaoLendario(),
                createEscudoLendario(),
                createReliquiaMineracao(registries),
                createRelogioLendario(),
                createBussolaLendaria(),
                createCapaceteGemeos(),
                createCapaceteGemeos(),
                createTridenteLendario(registries),
                createEspadaCacador(registries),
                createBotaLendaria(),
                createPocaoLendaria(),
                createDragaoLendario(),
                createPenaLendaria(),
                createBatataBobo()
        );
        shulker.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(relics));
        return shulker;
    }

    public static boolean isLampiaoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SOUL_LANTERN)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return LAMPIAO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isEscudoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SHIELD)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return ESCUDO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isRelogioLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.CLOCK)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return RELOGIO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isBussolaLendaria(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.COMPASS)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return BUSSOLA_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isCapaceteGemeos(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.TURTLE_HELMET)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return CAPACETE_GEMEOS_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isTridenteLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.TRIDENT)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return TRIDENTE_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isEspadaCacador(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.GOLDEN_SWORD)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return ESPADA_CACADOR_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isBotaLendaria(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.DIAMOND_BOOTS)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return BOTA_LENDARIA_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isPocaoLendaria(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.SPLASH_POTION)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return POCAO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isDragaoLendario(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.DRAGON_HEAD)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return DRAGAO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isPenaLendaria(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.FEATHER)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return PENA_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static boolean isBatataBobo(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.POISONOUS_POTATO)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        NbtCompound nbt = customData.copyNbt();
        return BATATA_BOBO_ID.equals(nbt.getString(RELIC_NBT_KEY));
    }

    public static UUID getTrackedTargetUuid(ItemStack stack) {
        if (!isBussolaLendaria(stack)) {
            return null;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return null;
        }
        NbtCompound nbt = customData.copyNbt();
        String rawUuid = nbt.getString(TRACK_UUID_KEY);
        if (rawUuid == null || rawUuid.isEmpty()) {
            return null;
        }
        try {
            return UUID.fromString(rawUuid);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    public static String getTrackedTargetName(ItemStack stack) {
        if (!isBussolaLendaria(stack)) {
            return "";
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return "";
        }
        return customData.copyNbt().getString(TRACK_NAME_KEY);
    }

    public static void setTrackedTarget(ItemStack stack, UUID targetUuid, String targetName) {
        if (!isBussolaLendaria(stack) || targetUuid == null) {
            return;
        }
        NbtComponent existing = stack.get(DataComponentTypes.CUSTOM_DATA);
        NbtCompound nbt = existing != null ? existing.copyNbt() : new NbtCompound();
        nbt.putString(RELIC_NBT_KEY, BUSSOLA_ID);
        nbt.putString(TRACK_UUID_KEY, targetUuid.toString());
        nbt.putString(TRACK_NAME_KEY, targetName != null ? targetName : "");
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
    }

    public static boolean isHoldingLampiao(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isLampiaoLendario(player.getMainHandStack())
                || isLampiaoLendario(player.getOffHandStack());
    }

    public static boolean isHoldingRelogio(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isRelogioLendario(player.getMainHandStack())
                || isRelogioLendario(player.getOffHandStack());
    }

    public static boolean isHoldingBussola(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isBussolaLendaria(player.getMainHandStack())
                || isBussolaLendaria(player.getOffHandStack());
    }

    public static boolean isWearingCapaceteGemeos(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isCapaceteGemeos(player.getEquippedStack(EquipmentSlot.HEAD));
    }

    public static boolean isWearingBotaLendaria(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isBotaLendaria(player.getEquippedStack(EquipmentSlot.FEET));
    }

    public static boolean isHoldingPenaLendaria(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isPenaLendaria(player.getMainHandStack())
                || isPenaLendaria(player.getOffHandStack());
    }

    public static boolean hasEspadaCacador(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            if (isEspadaCacador(inventory.getStack(i))) {
                return true;
            }
        }
        if (player.currentScreenHandler != null && isEspadaCacador(player.currentScreenHandler.getCursorStack())) {
            return true;
        }
        return false;
    }

    public static boolean hasBatataBobo(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        if (isBatataBobo(player.getMainHandStack()) || isBatataBobo(player.getOffHandStack())) {
            return true;
        }
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            if (isBatataBobo(inventory.getStack(i))) {
                return true;
            }
        }
        if (player.currentScreenHandler != null && isBatataBobo(player.currentScreenHandler.getCursorStack())) {
            return true;
        }
        return false;
    }
}
