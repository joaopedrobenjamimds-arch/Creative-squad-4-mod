package com.cs4.reliquias.compass;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public record TrackedPlayerPos(Identifier dimensionId, BlockPos pos) {
    public void write(PacketByteBuf buf) {
        buf.writeIdentifier(dimensionId);
        buf.writeBlockPos(pos);
    }

    public static TrackedPlayerPos read(PacketByteBuf buf) {
        Identifier dim = buf.readIdentifier();
        BlockPos pos = buf.readBlockPos();
        return new TrackedPlayerPos(dim, pos);
    }
}
