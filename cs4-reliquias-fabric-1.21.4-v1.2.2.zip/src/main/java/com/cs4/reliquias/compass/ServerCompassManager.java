package com.cs4.reliquias.compass;

import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.network.OpenBussolaPayload;
import com.cs4.reliquias.network.SyncCompassTargetsPayload;
import com.cs4.reliquias.relic.RelicManager;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerCompassManager {
    private static final Set<UUID> PLAYERS_WITH_SYNCED_TARGETS = ConcurrentHashMap.newKeySet();

    private ServerCompassManager() {
    }

    public static void sendOpenGui(ServerPlayerEntity player, ItemStack bussolaStack) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        List<DisguiseData> onlinePlayers = new ArrayList<>();
        for (ServerPlayerEntity online : server.getPlayerManager().getPlayerList()) {
            onlinePlayers.add(DisguiseData.fromPlayer(online));
        }

        UUID trackedUuid = RelicManager.getTrackedTargetUuid(bussolaStack);
        String trackedName = RelicManager.getTrackedTargetName(bussolaStack);
        if (trackedUuid != null) {
            ServerPlayerEntity onlineTarget = server.getPlayerManager().getPlayer(trackedUuid);
            if (onlineTarget != null) {
                trackedName = onlineTarget.getGameProfile().getName();
            }
        }

        ServerPlayNetworking.send(
                player,
                new OpenBussolaPayload(onlinePlayers, trackedUuid != null, trackedName)
        );
    }

    public static void handleSelection(MinecraftServer server, ServerPlayerEntity player, UUID targetUuid) {
        ItemStack stack = findHeldBussola(player);
        if (stack.isEmpty()) {
            return;
        }

        ServerPlayerEntity target = server.getPlayerManager().getPlayer(targetUuid);
        if (target == null) {
            player.sendMessage(
                    Text.literal("O jogador selecionado não está mais online.").formatted(Formatting.RED),
                    true
            );
            return;
        }

        String targetName = target.getGameProfile().getName();
        RelicManager.setTrackedTarget(stack, target.getUuid(), targetName);
        syncPlayerTargets(server, player);

        player.sendMessage(
                Text.literal("Bússola Lendária rastreando " + targetName + ".").formatted(Formatting.YELLOW),
                true
        );
    }

    public static void tick(MinecraftServer server) {
        if (server.getTicks() % 10 != 0) {
            return;
        }
        for (ServerPlayerEntity online : server.getPlayerManager().getPlayerList()) {
            syncPlayerTargets(server, online);
        }
    }

    public static void onDisconnect(UUID playerUuid) {
        PLAYERS_WITH_SYNCED_TARGETS.remove(playerUuid);
    }

    public static void clearServer() {
        PLAYERS_WITH_SYNCED_TARGETS.clear();
    }

    private static ItemStack findHeldBussola(ServerPlayerEntity player) {
        if (RelicManager.isBussolaLendaria(player.getMainHandStack())) {
            return player.getMainHandStack();
        }
        if (RelicManager.isBussolaLendaria(player.getOffHandStack())) {
            return player.getOffHandStack();
        }
        return ItemStack.EMPTY;
    }

    private static void syncPlayerTargets(MinecraftServer server, ServerPlayerEntity viewer) {
        Set<UUID> trackedUuids = new HashSet<>();
        PlayerInventory inventory = viewer.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack invStack = inventory.getStack(i);
            if (RelicManager.isBussolaLendaria(invStack)) {
                UUID targetUuid = RelicManager.getTrackedTargetUuid(invStack);
                if (targetUuid != null) {
                    trackedUuids.add(targetUuid);
                }
            }
        }

        Map<UUID, TrackedPlayerPos> positions = new HashMap<>();
        for (UUID targetUuid : trackedUuids) {
            ServerPlayerEntity target = server.getPlayerManager().getPlayer(targetUuid);
            if (target != null) {
                positions.put(
                        targetUuid,
                        new TrackedPlayerPos(
                                target.getServerWorld().getRegistryKey().getValue(),
                                target.getBlockPos()
                        )
                );
            }
        }

        if (!positions.isEmpty()) {
            PLAYERS_WITH_SYNCED_TARGETS.add(viewer.getUuid());
            ServerPlayNetworking.send(viewer, new SyncCompassTargetsPayload(positions));
        } else if (PLAYERS_WITH_SYNCED_TARGETS.remove(viewer.getUuid())) {
            ServerPlayNetworking.send(viewer, new SyncCompassTargetsPayload(positions));
        }
    }
}
