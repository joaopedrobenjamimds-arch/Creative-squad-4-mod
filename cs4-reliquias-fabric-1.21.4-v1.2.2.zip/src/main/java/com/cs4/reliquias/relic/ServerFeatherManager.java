package com.cs4.reliquias.relic;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerFeatherManager {
    private static final int LEVITATION_AMPLIFIER = 2; // Nível III
    private static final int EFFECT_DURATION_TICKS = 40;
    private static final int REFRESH_THRESHOLD_TICKS = 25;

    private static final Set<UUID> ACTIVE_HOLDERS = ConcurrentHashMap.newKeySet();

    private ServerFeatherManager() {
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID playerUuid = player.getUuid();
            if (!player.isAlive()) {
                ACTIVE_HOLDERS.remove(playerUuid);
                continue;
            }

            boolean holding = !player.isSpectator() && RelicManager.isHoldingPenaLendaria(player);
            if (holding) {
                ACTIVE_HOLDERS.add(playerUuid);
                StatusEffectInstance current = player.getStatusEffect(StatusEffects.LEVITATION);
                if (current == null
                        || current.getAmplifier() < LEVITATION_AMPLIFIER
                        || current.getDuration() <= REFRESH_THRESHOLD_TICKS) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.LEVITATION,
                            EFFECT_DURATION_TICKS,
                            LEVITATION_AMPLIFIER,
                            true,
                            true,
                            true
                    ));
                }
            } else if (ACTIVE_HOLDERS.remove(playerUuid)) {
                removeFeatherLevitationIfPresent(player);
            }
        }
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        ACTIVE_HOLDERS.remove(player.getUuid());
        if (!RelicManager.isHoldingPenaLendaria(player)) {
            removeFeatherLevitationIfPresent(player);
        }
    }

    public static void onDisconnect(UUID playerUuid) {
        ACTIVE_HOLDERS.remove(playerUuid);
    }

    public static void clearServer() {
        ACTIVE_HOLDERS.clear();
    }

    private static void removeFeatherLevitationIfPresent(ServerPlayerEntity player) {
        StatusEffectInstance current = player.getStatusEffect(StatusEffects.LEVITATION);
        if (current != null
                && current.getAmplifier() == LEVITATION_AMPLIFIER
                && current.getDuration() <= EFFECT_DURATION_TICKS) {
            player.removeStatusEffect(StatusEffects.LEVITATION);
        }
    }
}
