package com.cs4.reliquias.relic;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerHunterSwordManager {
    private static final int BAD_OMEN_AMPLIFIER = 4; // Nível V
    private static final int EFFECT_DURATION_TICKS = 40;
    private static final int REFRESH_THRESHOLD_TICKS = 25;
    private static final UUID NO_VICTIM_UUID = new UUID(0L, 0L);

    private static final Set<UUID> ACTIVE_HOLDERS = ConcurrentHashMap.newKeySet();
    private static final ThreadLocal<Deque<UUID>> FORCED_VICTIM_STACK = ThreadLocal.withInitial(ArrayDeque::new);

    private ServerHunterSwordManager() {
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID playerUuid = player.getUuid();
            if (!player.isAlive()) {
                ACTIVE_HOLDERS.remove(playerUuid);
                continue;
            }

            boolean hasSword = !player.isSpectator() && RelicManager.hasEspadaCacador(player);
            if (hasSword) {
                ACTIVE_HOLDERS.add(playerUuid);
                StatusEffectInstance current = player.getStatusEffect(StatusEffects.BAD_OMEN);
                if (current == null
                        || current.getAmplifier() < BAD_OMEN_AMPLIFIER
                        || current.getDuration() <= REFRESH_THRESHOLD_TICKS) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.BAD_OMEN,
                            EFFECT_DURATION_TICKS,
                            BAD_OMEN_AMPLIFIER,
                            true,
                            true,
                            true
                    ));
                }
            } else if (ACTIVE_HOLDERS.remove(playerUuid)) {
                StatusEffectInstance current = player.getStatusEffect(StatusEffects.BAD_OMEN);
                if (current != null
                        && current.getAmplifier() == BAD_OMEN_AMPLIFIER
                        && current.getDuration() <= EFFECT_DURATION_TICKS) {
                    player.removeStatusEffect(StatusEffects.BAD_OMEN);
                }
            }
        }
    }

    public static boolean isHunterSwordKill(DamageSource damageSource) {
        if (damageSource == null) {
            return false;
        }
        if (damageSource.getAttacker() instanceof PlayerEntity attacker) {
            ItemStack weapon = damageSource.getWeaponStack();
            if (weapon != null && RelicManager.isEspadaCacador(weapon)) {
                return true;
            }
            if (damageSource.getSource() == attacker && RelicManager.isEspadaCacador(attacker.getMainHandStack())) {
                return true;
            }
        }
        return false;
    }

    public static void pushForcedVictim(UUID victimUuid) {
        FORCED_VICTIM_STACK.get().push(victimUuid == null ? NO_VICTIM_UUID : victimUuid);
    }

    public static void popForcedVictim() {
        Deque<UUID> stack = FORCED_VICTIM_STACK.get();
        if (!stack.isEmpty()) {
            stack.pop();
        }
        if (stack.isEmpty()) {
            FORCED_VICTIM_STACK.remove();
        }
    }

    public static boolean isForcedVictim(UUID playerUuid) {
        if (playerUuid == null) {
            return false;
        }
        Deque<UUID> stack = FORCED_VICTIM_STACK.get();
        if (stack.isEmpty()) {
            return false;
        }
        UUID top = stack.peek();
        return !NO_VICTIM_UUID.equals(top) && playerUuid.equals(top);
    }

    public static void onDisconnect(UUID playerUuid) {
        ACTIVE_HOLDERS.remove(playerUuid);
    }

    public static void clearServer() {
        ACTIVE_HOLDERS.clear();
        FORCED_VICTIM_STACK.remove();
    }
}
