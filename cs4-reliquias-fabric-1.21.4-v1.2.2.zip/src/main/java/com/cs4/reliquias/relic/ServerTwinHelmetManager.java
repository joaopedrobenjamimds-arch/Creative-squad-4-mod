package com.cs4.reliquias.relic;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerTwinHelmetManager {
    private static final Map<UUID, Float> LAST_HEALTH = new ConcurrentHashMap<>();
    private static final ThreadLocal<Boolean> LINKING_DEATH = ThreadLocal.withInitial(() -> false);

    private ServerTwinHelmetManager() {
    }

    public static void tick(MinecraftServer server) {
        List<ServerPlayerEntity> wearers = new ArrayList<>();
        Set<UUID> wearerIds = new HashSet<>();

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (!player.isAlive()) {
                continue;
            }
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
            if (!player.isSpectator() && RelicManager.isWearingCapaceteGemeos(player)) {
                wearers.add(player);
                wearerIds.add(player.getUuid());
            }
        }

        LAST_HEALTH.keySet().removeIf(uuid -> !wearerIds.contains(uuid));

        if (wearers.size() < 2) {
            LAST_HEALTH.clear();
            return;
        }

        Map<UUID, Float> deltas = new HashMap<>();
        for (ServerPlayerEntity wearer : wearers) {
            Float prev = LAST_HEALTH.get(wearer.getUuid());
            if (prev != null) {
                float delta = wearer.getHealth() - prev;
                if (Math.abs(delta) > 0.0001F) {
                    deltas.put(wearer.getUuid(), delta);
                }
            }
        }

        if (!deltas.isEmpty()) {
            for (ServerPlayerEntity wearer : wearers) {
                float otherDelta = 0.0F;
                for (Map.Entry<UUID, Float> entry : deltas.entrySet()) {
                    if (!entry.getKey().equals(wearer.getUuid())) {
                        otherDelta += entry.getValue();
                    }
                }
                if (Math.abs(otherDelta) > 0.0001F && wearer.isAlive()) {
                    float targetHealth = wearer.getHealth() + otherDelta;
                    if (targetHealth <= 0.0F) {
                        wearer.kill(wearer.getServerWorld());
                    } else {
                        wearer.setHealth(Math.min(wearer.getMaxHealth(), targetHealth));
                    }
                }
            }
        }

        for (ServerPlayerEntity wearer : wearers) {
            if (wearer.isAlive()) {
                LAST_HEALTH.put(wearer.getUuid(), wearer.getHealth());
            } else {
                LAST_HEALTH.remove(wearer.getUuid());
            }
        }
    }

    public static void onWearerDeath(ServerPlayerEntity deadPlayer) {
        if (Boolean.TRUE.equals(LINKING_DEATH.get())) {
            return;
        }
        if (!RelicManager.isWearingCapaceteGemeos(deadPlayer)) {
            return;
        }
        MinecraftServer server = deadPlayer.getServer();
        if (server == null) {
            return;
        }

        LAST_HEALTH.remove(deadPlayer.getUuid());
        LINKING_DEATH.set(true);
        try {
            for (ServerPlayerEntity other : server.getPlayerManager().getPlayerList()) {
                if (other == deadPlayer || !other.isAlive() || other.isSpectator()) {
                    continue;
                }
                if (RelicManager.isWearingCapaceteGemeos(other)) {
                    LAST_HEALTH.remove(other.getUuid());
                    other.kill(other.getServerWorld());
                }
            }
        } finally {
            LINKING_DEATH.set(false);
        }
    }

    public static void onDisconnect(UUID playerUuid) {
        LAST_HEALTH.remove(playerUuid);
    }

    public static void clearServer() {
        LAST_HEALTH.clear();
    }
}
