package com.cs4.reliquias.relic;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerFoolPotatoManager {
    private static final int SLOWNESS_AMPLIFIER = 0; // Lentidão I
    private static final int EFFECT_DURATION_TICKS = 40;
    private static final int REFRESH_THRESHOLD_TICKS = 25;

    private static final Set<UUID> ACTIVE_HOLDERS = ConcurrentHashMap.newKeySet();

    private ServerFoolPotatoManager() {
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID playerUuid = player.getUuid();
            if (!player.isAlive()) {
                ACTIVE_HOLDERS.remove(playerUuid);
                continue;
            }

            boolean hasPotato = !player.isSpectator() && RelicManager.hasBatataBobo(player);
            if (hasPotato) {
                ACTIVE_HOLDERS.add(playerUuid);
                StatusEffectInstance current = player.getStatusEffect(StatusEffects.SLOWNESS);
                if (current == null
                        || current.getAmplifier() < SLOWNESS_AMPLIFIER
                        || current.getDuration() <= REFRESH_THRESHOLD_TICKS) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.SLOWNESS,
                            EFFECT_DURATION_TICKS,
                            SLOWNESS_AMPLIFIER,
                            true,
                            true,
                            true
                    ));
                }
            } else if (ACTIVE_HOLDERS.remove(playerUuid)) {
                removePotatoSlownessIfPresent(player);
            }
        }
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        ACTIVE_HOLDERS.remove(player.getUuid());
        if (!RelicManager.hasBatataBobo(player)) {
            removePotatoSlownessIfPresent(player);
        }
    }

    public static void onDisconnect(UUID playerUuid) {
        ACTIVE_HOLDERS.remove(playerUuid);
    }

    public static void clearServer() {
        ACTIVE_HOLDERS.clear();
    }

    private static void removePotatoSlownessIfPresent(ServerPlayerEntity player) {
        StatusEffectInstance current = player.getStatusEffect(StatusEffects.SLOWNESS);
        if (current != null
                && current.getAmplifier() == SLOWNESS_AMPLIFIER
                && current.getDuration() <= EFFECT_DURATION_TICKS) {
            player.removeStatusEffect(StatusEffects.SLOWNESS);
        }
    }
}
