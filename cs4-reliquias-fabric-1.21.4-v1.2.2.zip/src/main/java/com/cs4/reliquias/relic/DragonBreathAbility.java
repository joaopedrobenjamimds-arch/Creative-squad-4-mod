package com.cs4.reliquias.relic;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.DragonFireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

public final class DragonBreathAbility {
    public static final int COOLDOWN_TICKS = 5 * 20;

    private DragonBreathAbility() {
    }

    public static void fire(ServerWorld world, PlayerEntity user, ItemStack dragonHeadStack) {
        if (user.getItemCooldownManager().isCoolingDown(dragonHeadStack)) {
            return;
        }

        user.getItemCooldownManager().set(dragonHeadStack, COOLDOWN_TICKS);

        Vec3d look = user.getRotationVec(1.0F).normalize();
        Vec3d spawnPos = user.getEyePos().add(look.multiply(0.5));

        world.playSound(
                null,
                user.getX(),
                user.getY(),
                user.getZ(),
                SoundEvents.ENTITY_ENDER_DRAGON_SHOOT,
                SoundCategory.PLAYERS,
                2.0F,
                1.0F
        );

        for (int i = 1; i <= 4; i++) {
            Vec3d point = spawnPos.add(look.multiply(i * 0.65));
            world.spawnParticles(
                    ParticleTypes.DRAGON_BREATH,
                    point.x,
                    point.y,
                    point.z,
                    4,
                    0.12,
                    0.12,
                    0.12,
                    0.02
            );
        }

        DragonFireballEntity fireball = new DragonFireballEntity(world, user, look);
        fireball.setPosition(spawnPos);
        fireball.setVelocity(look.multiply(1.25));
        world.spawnEntity(fireball);
    }
}
