package com.cs4.reliquias.relic;

import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.WorldSavePath;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerRelicProtectionManager {
    private record SavedRelicSlot(int slot, ItemStack stack) {
    }

    private static final String CONFIG_FILE_NAME = "cs4_reliquias_settings.properties";
    private static final String KEEP_RELICS_KEY = "keep_reliquias";
    private static final Map<UUID, List<SavedRelicSlot>> SAVED_DEATH_RELICS = new ConcurrentHashMap<>();
    private static final Map<UUID, List<ItemStack>> PENDING_VOID_RELICS = new ConcurrentHashMap<>();
    private static volatile boolean keepRelicsOnDeath = false;

    private ServerRelicProtectionManager() {
    }

    public static boolean isKeepRelicsOnDeath() {
        return keepRelicsOnDeath;
    }

    public static void setKeepRelicsOnDeath(MinecraftServer server, boolean enabled) {
        keepRelicsOnDeath = enabled;
        saveConfig(server);
    }

    public static void loadConfig(MinecraftServer server) {
        keepRelicsOnDeath = false;
        if (server == null) {
            return;
        }
        Path configPath = server.getSavePath(WorldSavePath.ROOT).resolve(CONFIG_FILE_NAME);
        if (!Files.exists(configPath)) {
            return;
        }
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(configPath)) {
            props.load(in);
            keepRelicsOnDeath = Boolean.parseBoolean(props.getProperty(KEEP_RELICS_KEY, "false"));
        } catch (IOException ignored) {
        }
    }

    private static void saveConfig(MinecraftServer server) {
        if (server == null) {
            return;
        }
        Path configPath = server.getSavePath(WorldSavePath.ROOT).resolve(CONFIG_FILE_NAME);
        Properties props = new Properties();
        props.setProperty(KEEP_RELICS_KEY, Boolean.toString(keepRelicsOnDeath));
        try {
            if (configPath.getParent() != null) {
                Files.createDirectories(configPath.getParent());
            }
            try (OutputStream out = Files.newOutputStream(configPath)) {
                props.store(out, "CS4 Reliquias Settings");
            }
        } catch (IOException ignored) {
        }
    }

    public static void captureRelicsOnDeath(ServerPlayerEntity player) {
        if (player == null || player.isSpectator()) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        List<SavedRelicSlot> captured = new ArrayList<>();

        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (RelicManager.isAnyRelic(stack)) {
                captured.add(new SavedRelicSlot(i, stack.copy()));
                inventory.setStack(i, ItemStack.EMPTY);
            }
        }

        if (player.currentScreenHandler != null) {
            ItemStack cursor = player.currentScreenHandler.getCursorStack();
            if (RelicManager.isAnyRelic(cursor)) {
                captured.add(new SavedRelicSlot(-1, cursor.copy()));
                player.currentScreenHandler.setCursorStack(ItemStack.EMPTY);
            }
        }

        if (!captured.isEmpty()) {
            SAVED_DEATH_RELICS.compute(player.getUuid(), (uuid, existing) -> {
                if (existing == null) {
                    return captured;
                }
                List<SavedRelicSlot> merged = new ArrayList<>(existing);
                merged.addAll(captured);
                return merged;
            });
        }
    }

    public static void restoreRelicsOnRespawn(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        List<SavedRelicSlot> saved = SAVED_DEATH_RELICS.remove(uuid);
        PlayerInventory inventory = player.getInventory();
        boolean changed = false;

        if (saved != null && !saved.isEmpty()) {
            for (SavedRelicSlot entry : saved) {
                ItemStack stack = entry.stack().copy();
                if (stack.isEmpty()) {
                    continue;
                }
                int slot = entry.slot();
                if (slot >= 0 && slot < inventory.size() && inventory.getStack(slot).isEmpty()) {
                    inventory.setStack(slot, stack);
                } else {
                    giveOrDropToPlayer(player, stack);
                }
                changed = true;
            }
        }

        if (deliverPendingVoidRelics(player)) {
            changed = true;
        }

        if (changed) {
            inventory.markDirty();
            if (player.playerScreenHandler != null) {
                player.playerScreenHandler.sendContentUpdates();
            }
            if (player.currentScreenHandler != null) {
                player.currentScreenHandler.sendContentUpdates();
            }
        }
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null || player.isDead()) {
            return;
        }
        if (deliverPendingVoidRelics(player)) {
            player.getInventory().markDirty();
            if (player.playerScreenHandler != null) {
                player.playerScreenHandler.sendContentUpdates();
            }
        }
    }

    private static boolean deliverPendingVoidRelics(ServerPlayerEntity player) {
        List<ItemStack> pending = PENDING_VOID_RELICS.remove(player.getUuid());
        if (pending == null || pending.isEmpty()) {
            return false;
        }
        for (ItemStack stack : pending) {
            if (!stack.isEmpty()) {
                giveOrDropToPlayer(player, stack.copy());
            }
        }
        return true;
    }

    public static void rescueFromVoid(ItemEntity itemEntity, @Nullable UUID throwerUuid, @Nullable UUID ownerUuid) {
        if (itemEntity == null || itemEntity.isRemoved() || !(itemEntity.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }
        ItemStack stack = itemEntity.getStack();
        if (!RelicManager.isAnyRelic(stack)) {
            return;
        }

        UUID targetUuid = throwerUuid != null ? throwerUuid : ownerUuid;
        if (targetUuid == null) {
            Entity ownerEntity = itemEntity.getOwner();
            if (ownerEntity != null) {
                targetUuid = ownerEntity.getUuid();
            }
        }

        MinecraftServer server = serverWorld.getServer();
        if (targetUuid != null && server != null) {
            ItemStack rescued = stack.copy();
            itemEntity.setStack(ItemStack.EMPTY);
            itemEntity.discard();

            ServerPlayerEntity targetPlayer = server.getPlayerManager().getPlayer(targetUuid);
            if (targetPlayer != null && targetPlayer.isAlive()) {
                giveOrDropToPlayer(targetPlayer, rescued);
                targetPlayer.getInventory().markDirty();
                if (targetPlayer.playerScreenHandler != null) {
                    targetPlayer.playerScreenHandler.sendContentUpdates();
                }
            } else {
                PENDING_VOID_RELICS.compute(targetUuid, (uuid, existing) -> {
                    List<ItemStack> list = existing != null ? new ArrayList<>(existing) : new ArrayList<>();
                    list.add(rescued);
                    return list;
                });
            }
            return;
        }

        ServerPlayerEntity nearest = findNearestAlivePlayer(serverWorld, itemEntity);
        if (nearest != null) {
            ItemStack rescued = stack.copy();
            itemEntity.setStack(ItemStack.EMPTY);
            itemEntity.discard();
            giveOrDropToPlayer(nearest, rescued);
            nearest.getInventory().markDirty();
            if (nearest.playerScreenHandler != null) {
                nearest.playerScreenHandler.sendContentUpdates();
            }
        } else {
            double safeY = serverWorld.getBottomY() + 16.0;
            itemEntity.setVelocity(0.0, 0.1, 0.0);
            itemEntity.setPosition(itemEntity.getX(), safeY, itemEntity.getZ());
        }
    }

    @Nullable
    private static ServerPlayerEntity findNearestAlivePlayer(ServerWorld world, ItemEntity itemEntity) {
        ServerPlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (!player.isAlive() || player.isSpectator()) {
                continue;
            }
            double dist = player.squaredDistanceTo(itemEntity);
            if (dist < bestDist) {
                bestDist = dist;
                best = player;
            }
        }
        return best;
    }

    public static void giveOrDropToPlayer(ServerPlayerEntity player, ItemStack stack) {
        if (player == null || stack == null || stack.isEmpty()) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        ItemStack remaining = stack.copy();
        if (inventory.insertStack(remaining) && remaining.isEmpty()) {
            return;
        }
        if (!remaining.isEmpty()) {
            ItemEntity dropped = player.dropItem(remaining, false, true);
            if (dropped != null) {
                dropped.resetPickupDelay();
            }
        }
    }

    public static void clearServer() {
        SAVED_DEATH_RELICS.clear();
        PENDING_VOID_RELICS.clear();
        keepRelicsOnDeath = false;
    }
}
