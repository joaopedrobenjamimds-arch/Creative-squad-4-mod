package com.cs4.reliquias.relic;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class SonicBoomAbility {
    public static final int COOLDOWN_TICKS = 15 * 20;
    public static final float DAMAGE = 8.0F;
    public static final double RANGE = 20.0;
    private static final ThreadLocal<Boolean> APPLYING_SONIC_BOOM = ThreadLocal.withInitial(() -> false);

    private SonicBoomAbility() {
    }

    public static boolean isApplying() {
        return Boolean.TRUE.equals(APPLYING_SONIC_BOOM.get());
    }

    public static void fire(ServerWorld world, PlayerEntity user, ItemStack shieldStack) {
        user.getItemCooldownManager().set(shieldStack, COOLDOWN_TICKS);

        Vec3d start = user.getEyePos();
        Vec3d direction = user.getRotationVec(1.0F).normalize();
        Vec3d end = start.add(direction.multiply(RANGE));

        world.playSound(
                null,
                user.getX(),
                user.getY(),
                user.getZ(),
                SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                SoundCategory.PLAYERS,
                3.0F,
                1.0F
        );

        for (int i = 1; i <= (int) RANGE; i++) {
            Vec3d point = start.add(direction.multiply(i));
            world.spawnParticles(ParticleTypes.SONIC_BOOM, point.x, point.y, point.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        Box searchBox = new Box(start, end).expand(1.5);
        List<Entity> targets = world.getOtherEntities(
                user,
                searchBox,
                entity -> entity instanceof LivingEntity living && living.isAlive() && !entity.isSpectator()
        );

        for (Entity entity : targets) {
            Box targetBox = entity.getBoundingBox().expand(0.75);
            if (targetBox.contains(start) || targetBox.raycast(start, end).isPresent()) {
                APPLYING_SONIC_BOOM.set(true);
                try {
                    entity.damage(world, world.getDamageSources().sonicBoom(user), DAMAGE);
                } finally {
                    APPLYING_SONIC_BOOM.set(false);
                }
            }
        }
    }
}
