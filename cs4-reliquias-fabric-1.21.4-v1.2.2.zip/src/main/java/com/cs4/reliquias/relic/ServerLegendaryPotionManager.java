package com.cs4.reliquias.relic;

import com.cs4.reliquias.Cs4ReliquiasMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerLegendaryPotionManager {
    public static final int COOLDOWN_TICKS = 200;
    public static final long COOLDOWN_MS = 10_000L;
    public static final Identifier COOLDOWN_GROUP_ID = Identifier.of(Cs4ReliquiasMod.MOD_ID, RelicManager.POCAO_ID);

    private static final int REGEN_DURATION_TICKS = 440; // 22s
    private static final int REGEN_AMPLIFIER = 1; // Regeneração II
    private static final int SATURATION_DURATION_TICKS = 40; // 2s
    private static final int SATURATION_AMPLIFIER = 4; // Saturação V
    private static final int BLINDNESS_DURATION_TICKS = 160; // 8s

    private static final Map<UUID, Long> COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();

    private ServerLegendaryPotionManager() {
    }

    public static boolean tryBeginThrow(PlayerEntity user, ItemStack stack) {
        if (user == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        Long until = COOLDOWN_UNTIL_MS.get(user.getUuid());
        if (until != null && until > now) {
            int remainingTicks = Math.min(COOLDOWN_TICKS, Math.max(1, (int) Math.ceil((until - now) / 50.0)));
            user.getItemCooldownManager().set(COOLDOWN_GROUP_ID, remainingTicks);
            return false;
        }

        COOLDOWN_UNTIL_MS.put(user.getUuid(), now + COOLDOWN_MS);
        user.getItemCooldownManager().set(COOLDOWN_GROUP_ID, COOLDOWN_TICKS);
        return true;
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        Long until = COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until == null) {
            return;
        }
        long remainingMs = until - System.currentTimeMillis();
        if (remainingMs > 0L) {
            int remainingTicks = Math.min(COOLDOWN_TICKS, Math.max(1, (int) Math.ceil(remainingMs / 50.0)));
            player.getItemCooldownManager().set(COOLDOWN_GROUP_ID, remainingTicks);
        } else {
            COOLDOWN_UNTIL_MS.remove(player.getUuid());
        }
    }

    public static void handleSplashCollision(ServerWorld world, PotionEntity potion, HitResult hitResult) {
        Entity owner = potion.getOwner();
        Entity directHitEntity = hitResult instanceof EntityHitResult entityHit ? entityHit.getEntity() : null;

        Box box = potion.getBoundingBox().expand(4.0, 2.0, 4.0);
        List<PlayerEntity> players = world.getNonSpectatingEntities(PlayerEntity.class, box);
        for (PlayerEntity target : players) {
            if (!target.isAlive() || target.isSpectator()) {
                continue;
            }
            boolean isDirectHit = target == directHitEntity;
            if (!isDirectHit && potion.squaredDistanceTo(target) >= 16.0) {
                continue;
            }

            boolean isSelf = owner != null && target.getUuid().equals(owner.getUuid());
            if (isSelf) {
                target.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.REGENERATION,
                        REGEN_DURATION_TICKS,
                        REGEN_AMPLIFIER
                ));
                target.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.SATURATION,
                        SATURATION_DURATION_TICKS,
                        SATURATION_AMPLIFIER
                ));
            } else {
                target.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.BLINDNESS,
                        BLINDNESS_DURATION_TICKS,
                        0
                ));
            }
        }
    }

    public static void clearServer() {
        COOLDOWN_UNTIL_MS.clear();
    }
}
