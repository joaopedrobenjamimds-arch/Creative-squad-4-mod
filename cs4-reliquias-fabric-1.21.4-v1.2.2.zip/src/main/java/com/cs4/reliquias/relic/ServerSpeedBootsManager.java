package com.cs4.reliquias.relic;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerSpeedBootsManager {
    private static final int SPEED_AMPLIFIER = 4; // Nível V
    private static final int EFFECT_DURATION_TICKS = 40;
    private static final int REFRESH_THRESHOLD_TICKS = 25;

    private static final Set<UUID> ACTIVE_WEARERS = ConcurrentHashMap.newKeySet();

    private ServerSpeedBootsManager() {
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID playerUuid = player.getUuid();
            if (!player.isAlive()) {
                ACTIVE_WEARERS.remove(playerUuid);
                continue;
            }

            boolean wearing = !player.isSpectator() && RelicManager.isWearingBotaLendaria(player);
            if (wearing) {
                ACTIVE_WEARERS.add(playerUuid);
                StatusEffectInstance current = player.getStatusEffect(StatusEffects.SPEED);
                if (current == null
                        || current.getAmplifier() < SPEED_AMPLIFIER
                        || current.getDuration() <= REFRESH_THRESHOLD_TICKS) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.SPEED,
                            EFFECT_DURATION_TICKS,
                            SPEED_AMPLIFIER,
                            true,
                            true,
                            true
                    ));
                }
            } else if (ACTIVE_WEARERS.remove(playerUuid)) {
                removeBootsSpeedIfPresent(player);
            }
        }
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        ACTIVE_WEARERS.remove(player.getUuid());
        if (!RelicManager.isWearingBotaLendaria(player)) {
            removeBootsSpeedIfPresent(player);
        }
    }

    public static void onDisconnect(UUID playerUuid) {
        ACTIVE_WEARERS.remove(playerUuid);
    }

    public static void clearServer() {
        ACTIVE_WEARERS.clear();
    }

    private static void removeBootsSpeedIfPresent(ServerPlayerEntity player) {
        StatusEffectInstance current = player.getStatusEffect(StatusEffects.SPEED);
        if (current != null
                && current.getAmplifier() == SPEED_AMPLIFIER
                && current.getDuration() <= EFFECT_DURATION_TICKS) {
            player.removeStatusEffect(StatusEffects.SPEED);
        }
    }
}
