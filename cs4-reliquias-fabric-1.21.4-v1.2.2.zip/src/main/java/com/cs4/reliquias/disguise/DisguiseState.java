package com.cs4.reliquias.disguise;

import net.minecraft.entity.player.PlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DisguiseState {
    private static final Map<UUID, DisguiseData> SERVER_DISGUISES = new ConcurrentHashMap<>();
    private static final Map<UUID, DisguiseData> CLIENT_DISGUISES = new ConcurrentHashMap<>();

    private DisguiseState() {
    }

    public static Map<UUID, DisguiseData> serverMap() {
        return SERVER_DISGUISES;
    }

    public static Map<UUID, DisguiseData> clientMap() {
        return CLIENT_DISGUISES;
    }

    public static DisguiseData getDisguise(PlayerEntity player) {
        if (player == null) {
            return null;
        }
        return player.getWorld().isClient
                ? CLIENT_DISGUISES.get(player.getUuid())
                : SERVER_DISGUISES.get(player.getUuid());
    }

    public static DisguiseData getClientDisguise(UUID uuid) {
        if (uuid == null) {
            return null;
        }
        return CLIENT_DISGUISES.get(uuid);
    }

    public static void clearServer() {
        SERVER_DISGUISES.clear();
    }

    public static void clearClient() {
        CLIENT_DISGUISES.clear();
    }
}
