package com.cs4.reliquias.disguise;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Collection;
import java.util.UUID;

public record DisguiseData(
        UUID targetUuid,
        String targetName,
        String textureValue,
        String textureSignature
) {
    public static DisguiseData fromPlayer(ServerPlayerEntity player) {
        GameProfile profile = player.getGameProfile();
        String value = "";
        String signature = "";
        Collection<Property> textures = profile.getProperties().get("textures");
        if (textures != null && !textures.isEmpty()) {
            Property prop = textures.iterator().next();
            value = prop.value() != null ? prop.value() : "";
            signature = prop.signature() != null ? prop.signature() : "";
        }
        return new DisguiseData(profile.getId(), profile.getName(), value, signature);
    }

    public GameProfile toGameProfile() {
        GameProfile profile = new GameProfile(targetUuid, targetName);
        if (textureValue != null && !textureValue.isEmpty()) {
            profile.getProperties().put(
                    "textures",
                    new Property("textures", textureValue, (textureSignature != null && !textureSignature.isEmpty()) ? textureSignature : null)
            );
        }
        return profile;
    }

    public void write(PacketByteBuf buf) {
        buf.writeUuid(targetUuid);
        buf.writeString(targetName, 64);
        buf.writeString(textureValue != null ? textureValue : "", 32767);
        buf.writeString(textureSignature != null ? textureSignature : "", 32767);
    }

    public static DisguiseData read(PacketByteBuf buf) {
        UUID uuid = buf.readUuid();
        String name = buf.readString(64);
        String value = buf.readString(32767);
        String signature = buf.readString(32767);
        return new DisguiseData(uuid, name, value, signature);
    }
}
