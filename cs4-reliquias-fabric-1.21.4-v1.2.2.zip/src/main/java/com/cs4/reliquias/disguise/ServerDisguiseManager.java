package com.cs4.reliquias.disguise;

import com.cs4.reliquias.network.OpenRelogioPayload;
import com.cs4.reliquias.network.SyncDisguisesPayload;
import com.cs4.reliquias.relic.RelicManager;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class ServerDisguiseManager {
    private ServerDisguiseManager() {
    }

    public static void sendOpenGui(ServerPlayerEntity player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        List<DisguiseData> onlinePlayers = new ArrayList<>();
        for (ServerPlayerEntity online : server.getPlayerManager().getPlayerList()) {
            onlinePlayers.add(DisguiseData.fromPlayer(online));
        }

        DisguiseData current = DisguiseState.serverMap().get(player.getUuid());
        boolean disguised = current != null;
        String currentName = current != null ? current.targetName() : "";

        ServerPlayNetworking.send(player, new OpenRelogioPayload(onlinePlayers, disguised, currentName));
    }

    public static void handleSelection(MinecraftServer server, ServerPlayerEntity player, Optional<UUID> targetUuid) {
        if (!RelicManager.isHoldingRelogio(player)) {
            return;
        }

        if (targetUuid.isEmpty()) {
            DisguiseState.serverMap().remove(player.getUuid());
            broadcastAll(server);
            player.sendMessage(
                    Text.literal("Você voltou à sua aparência original.").formatted(Formatting.YELLOW),
                    true
            );
            return;
        }

        UUID chosenId = targetUuid.get();
        if (chosenId.equals(player.getUuid())) {
            DisguiseState.serverMap().remove(player.getUuid());
            broadcastAll(server);
            player.sendMessage(
                    Text.literal("Você voltou à sua aparência original.").formatted(Formatting.YELLOW),
                    true
            );
            return;
        }

        ServerPlayerEntity target = server.getPlayerManager().getPlayer(chosenId);
        if (target == null) {
            player.sendMessage(
                    Text.literal("O jogador selecionado não está mais online.").formatted(Formatting.RED),
                    true
            );
            return;
        }

        DisguiseData disguise = DisguiseData.fromPlayer(target);
        DisguiseState.serverMap().put(player.getUuid(), disguise);
        broadcastAll(server);
        player.sendMessage(
                Text.literal("Transformado em " + disguise.targetName() + ".").formatted(Formatting.YELLOW),
                true
        );
    }

    public static void syncToPlayer(ServerPlayerEntity player) {
        ServerPlayNetworking.send(
                player,
                new SyncDisguisesPayload(new HashMap<>(DisguiseState.serverMap()))
        );
    }

    public static void broadcastAll(MinecraftServer server) {
        SyncDisguisesPayload payload = new SyncDisguisesPayload(new HashMap<>(DisguiseState.serverMap()));
        for (ServerPlayerEntity online : server.getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(online, payload);
        }
    }
}
