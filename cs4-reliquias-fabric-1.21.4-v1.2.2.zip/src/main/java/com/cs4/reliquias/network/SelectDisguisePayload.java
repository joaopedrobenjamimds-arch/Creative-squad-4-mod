package com.cs4.reliquias.network;

import com.cs4.reliquias.Cs4ReliquiasMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.Optional;
import java.util.UUID;

public record SelectDisguisePayload(Optional<UUID> targetUuid) implements CustomPayload {
    public static final CustomPayload.Id<SelectDisguisePayload> ID =
            new CustomPayload.Id<>(Identifier.of(Cs4ReliquiasMod.MOD_ID, "select_disguise"));

    public static final PacketCodec<RegistryByteBuf, SelectDisguisePayload> CODEC =
            PacketCodec.of(SelectDisguisePayload::write, SelectDisguisePayload::read);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }

    private void write(RegistryByteBuf buf) {
        buf.writeBoolean(targetUuid.isPresent());
        targetUuid.ifPresent(buf::writeUuid);
    }

    private static SelectDisguisePayload read(RegistryByteBuf buf) {
        boolean present = buf.readBoolean();
        Optional<UUID> uuid = present ? Optional.of(buf.readUuid()) : Optional.empty();
        return new SelectDisguisePayload(uuid);
    }
}
