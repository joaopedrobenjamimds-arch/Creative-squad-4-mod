package com.cs4.reliquias.network;

import com.cs4.reliquias.Cs4ReliquiasMod;
import com.cs4.reliquias.disguise.DisguiseData;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public record OpenRelogioPayload(
        List<DisguiseData> onlinePlayers,
        boolean currentlyDisguised,
        String currentDisguiseName
) implements CustomPayload {
    public static final CustomPayload.Id<OpenRelogioPayload> ID =
            new CustomPayload.Id<>(Identifier.of(Cs4ReliquiasMod.MOD_ID, "open_relogio"));

    public static final PacketCodec<RegistryByteBuf, OpenRelogioPayload> CODEC =
            PacketCodec.of(OpenRelogioPayload::write, OpenRelogioPayload::read);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }

    private void write(RegistryByteBuf buf) {
        buf.writeVarInt(onlinePlayers.size());
        for (DisguiseData entry : onlinePlayers) {
            entry.write(buf);
        }
        buf.writeBoolean(currentlyDisguised);
        buf.writeString(currentDisguiseName != null ? currentDisguiseName : "", 64);
    }

    private static OpenRelogioPayload read(RegistryByteBuf buf) {
        int count = buf.readVarInt();
        List<DisguiseData> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            list.add(DisguiseData.read(buf));
        }
        boolean disguised = buf.readBoolean();
        String currentName = buf.readString(64);
        return new OpenRelogioPayload(list, disguised, currentName);
    }
}
