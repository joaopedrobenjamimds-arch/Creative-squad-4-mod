package com.cs4.reliquias.network;

import com.cs4.reliquias.Cs4ReliquiasMod;
import com.cs4.reliquias.compass.TrackedPlayerPos;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public record SyncCompassTargetsPayload(Map<UUID, TrackedPlayerPos> targets) implements CustomPayload {
    public static final CustomPayload.Id<SyncCompassTargetsPayload> ID =
            new CustomPayload.Id<>(Identifier.of(Cs4ReliquiasMod.MOD_ID, "sync_compass_targets"));

    public static final PacketCodec<RegistryByteBuf, SyncCompassTargetsPayload> CODEC =
            PacketCodec.of(SyncCompassTargetsPayload::write, SyncCompassTargetsPayload::read);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }

    private void write(RegistryByteBuf buf) {
        buf.writeVarInt(targets.size());
        for (Map.Entry<UUID, TrackedPlayerPos> entry : targets.entrySet()) {
            buf.writeUuid(entry.getKey());
            entry.getValue().write(buf);
        }
    }

    private static SyncCompassTargetsPayload read(RegistryByteBuf buf) {
        int size = buf.readVarInt();
        Map<UUID, TrackedPlayerPos> map = new HashMap<>(size);
        for (int i = 0; i < size; i++) {
            UUID uuid = buf.readUuid();
            TrackedPlayerPos pos = TrackedPlayerPos.read(buf);
            map.put(uuid, pos);
        }
        return new SyncCompassTargetsPayload(map);
    }
}
