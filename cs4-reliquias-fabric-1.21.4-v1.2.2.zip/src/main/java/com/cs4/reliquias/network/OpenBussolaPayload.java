package com.cs4.reliquias.network;

import com.cs4.reliquias.Cs4ReliquiasMod;
import com.cs4.reliquias.disguise.DisguiseData;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public record OpenBussolaPayload(
        List<DisguiseData> onlinePlayers,
        boolean currentlyTracking,
        String currentTargetName
) implements CustomPayload {
    public static final CustomPayload.Id<OpenBussolaPayload> ID =
            new CustomPayload.Id<>(Identifier.of(Cs4ReliquiasMod.MOD_ID, "open_bussola"));

    public static final PacketCodec<RegistryByteBuf, OpenBussolaPayload> CODEC =
            PacketCodec.of(OpenBussolaPayload::write, OpenBussolaPayload::read);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }

    private void write(RegistryByteBuf buf) {
        buf.writeVarInt(onlinePlayers.size());
        for (DisguiseData entry : onlinePlayers) {
            entry.write(buf);
        }
        buf.writeBoolean(currentlyTracking);
        buf.writeString(currentTargetName != null ? currentTargetName : "", 64);
    }

    private static OpenBussolaPayload read(RegistryByteBuf buf) {
        int count = buf.readVarInt();
        List<DisguiseData> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            list.add(DisguiseData.read(buf));
        }
        boolean tracking = buf.readBoolean();
        String targetName = buf.readString(64);
        return new OpenBussolaPayload(list, tracking, targetName);
    }
}
