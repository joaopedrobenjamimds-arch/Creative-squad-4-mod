package com.cs4.reliquias.network;

import com.cs4.reliquias.Cs4ReliquiasMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.UUID;

public record SelectCompassTargetPayload(UUID targetUuid) implements CustomPayload {
    public static final CustomPayload.Id<SelectCompassTargetPayload> ID =
            new CustomPayload.Id<>(Identifier.of(Cs4ReliquiasMod.MOD_ID, "select_compass_target"));

    public static final PacketCodec<RegistryByteBuf, SelectCompassTargetPayload> CODEC =
            PacketCodec.of(SelectCompassTargetPayload::write, SelectCompassTargetPayload::read);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }

    private void write(RegistryByteBuf buf) {
        buf.writeUuid(targetUuid);
    }

    private static SelectCompassTargetPayload read(RegistryByteBuf buf) {
        return new SelectCompassTargetPayload(buf.readUuid());
    }
}
