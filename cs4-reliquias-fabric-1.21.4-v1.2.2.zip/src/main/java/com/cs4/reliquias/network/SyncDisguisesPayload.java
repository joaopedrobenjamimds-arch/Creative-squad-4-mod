package com.cs4.reliquias.network;

import com.cs4.reliquias.Cs4ReliquiasMod;
import com.cs4.reliquias.disguise.DisguiseData;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public record SyncDisguisesPayload(Map<UUID, DisguiseData> disguises) implements CustomPayload {
    public static final CustomPayload.Id<SyncDisguisesPayload> ID =
            new CustomPayload.Id<>(Identifier.of(Cs4ReliquiasMod.MOD_ID, "sync_disguises"));

    public static final PacketCodec<RegistryByteBuf, SyncDisguisesPayload> CODEC =
            PacketCodec.of(SyncDisguisesPayload::write, SyncDisguisesPayload::read);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }

    private void write(RegistryByteBuf buf) {
        buf.writeVarInt(disguises.size());
        for (Map.Entry<UUID, DisguiseData> entry : disguises.entrySet()) {
            buf.writeUuid(entry.getKey());
            entry.getValue().write(buf);
        }
    }

    private static SyncDisguisesPayload read(RegistryByteBuf buf) {
        int size = buf.readVarInt();
        Map<UUID, DisguiseData> map = new HashMap<>(size);
        for (int i = 0; i < size; i++) {
            UUID playerUuid = buf.readUuid();
            DisguiseData data = DisguiseData.read(buf);
            map.put(playerUuid, data);
        }
        return new SyncDisguisesPayload(map);
    }
}
