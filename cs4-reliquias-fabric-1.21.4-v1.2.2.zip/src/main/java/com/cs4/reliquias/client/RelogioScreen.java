package com.cs4.reliquias.client;

import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.network.OpenRelogioPayload;
import com.cs4.reliquias.network.SelectDisguisePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Optional;

public class RelogioScreen extends Screen {
    private static final int CARD_HEIGHT = 24;
    private static final int CARD_GAP = 4;

    private final List<DisguiseData> onlinePlayers;
    private final boolean currentlyDisguised;
    private final String currentDisguiseName;

    private int page = 0;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private int rowsPerPage;
    private int pageSize;

    private ButtonWidget prevButton;
    private ButtonWidget nextButton;

    public RelogioScreen(OpenRelogioPayload payload) {
        super(Text.literal("Relógio Lendário"));
        this.onlinePlayers = payload.onlinePlayers();
        this.currentlyDisguised = payload.currentlyDisguised();
        this.currentDisguiseName = payload.currentDisguiseName();
    }

    @Override
    protected void init() {
        this.panelWidth = Math.min(344, this.width - 20);
        this.panelHeight = Math.min(248, this.height - 20);
        this.panelX = (this.width - this.panelWidth) / 2;
        this.panelY = (this.height - this.panelHeight) / 2;

        int headerHeight = 36;
        int footerHeight = 34;
        int listHeight = Math.max(CARD_HEIGHT, this.panelHeight - headerHeight - footerHeight);
        this.rowsPerPage = Math.max(1, listHeight / (CARD_HEIGHT + CARD_GAP));
        this.pageSize = this.rowsPerPage * 2;

        int totalPages = Math.max(1, (int) Math.ceil((double) onlinePlayers.size() / pageSize));
        if (page >= totalPages) {
            page = totalPages - 1;
        }

        int footerY = this.panelY + this.panelHeight - 26;
        int normalWidth = 114;
        int closeWidth = 60;
        int navWidth = 22;

        this.addDrawableChild(
                ButtonWidget.builder(Text.literal("Voltar ao Normal"), button -> {
                    ClientPlayNetworking.send(new SelectDisguisePayload(Optional.empty()));
                    this.close();
                }).dimensions(this.panelX + 10, footerY, normalWidth, 20).build()
        );

        this.prevButton = this.addDrawableChild(
                ButtonWidget.builder(Text.literal("<"), button -> {
                    if (page > 0) {
                        page--;
                        updateNavButtons();
                    }
                }).dimensions(this.panelX + this.panelWidth - closeWidth - navWidth * 2 - 18, footerY, navWidth, 20).build()
        );

        this.nextButton = this.addDrawableChild(
                ButtonWidget.builder(Text.literal(">"), button -> {
                    int maxPage = Math.max(0, (int) Math.ceil((double) onlinePlayers.size() / pageSize) - 1);
                    if (page < maxPage) {
                        page++;
                        updateNavButtons();
                    }
                }).dimensions(this.panelX + this.panelWidth - closeWidth - navWidth - 14, footerY, navWidth, 20).build()
        );

        this.addDrawableChild(
                ButtonWidget.builder(Text.literal("Fechar"), button -> this.close())
                        .dimensions(this.panelX + this.panelWidth - closeWidth - 10, footerY, closeWidth, 20)
                        .build()
        );

        updateNavButtons();
    }

    private void updateNavButtons() {
        int totalPages = Math.max(1, (int) Math.ceil((double) onlinePlayers.size() / pageSize));
        boolean hasMultiplePages = totalPages > 1;
        if (prevButton != null) {
            prevButton.visible = hasMultiplePages;
            prevButton.active = page > 0;
        }
        if (nextButton != null) {
            nextButton.visible = hasMultiplePages;
            nextButton.active = page < totalPages - 1;
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xE60F172A);
        context.drawBorder(panelX, panelY, panelWidth, panelHeight, 0xFFFBBF24);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("Relógio Lendário — Jogadores Online").formatted(Formatting.GOLD),
                panelX + panelWidth / 2,
                panelY + 9,
                0xFBBF24
        );

        String subtitle = currentlyDisguised && !currentDisguiseName.isEmpty()
                ? "Transformado em: " + currentDisguiseName
                : "Selecione um jogador para assumir skin e nome";
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal(subtitle).formatted(currentlyDisguised ? Formatting.YELLOW : Formatting.GRAY),
                panelX + panelWidth / 2,
                panelY + 21,
                0xCBD5E1
        );

        int startIdx = page * pageSize;
        int endIdx = Math.min(onlinePlayers.size(), startIdx + pageSize);
        int innerWidth = panelWidth - 20;
        int cardWidth = (innerWidth - CARD_GAP) / 2;
        int listStartY = panelY + 36;

        for (int i = startIdx; i < endIdx; i++) {
            int localIndex = i - startIdx;
            int col = localIndex % 2;
            int row = localIndex / 2;
            int cardX = panelX + 10 + col * (cardWidth + CARD_GAP);
            int cardY = listStartY + row * (CARD_HEIGHT + CARD_GAP);

            DisguiseData entry = onlinePlayers.get(i);
            boolean hovered = mouseX >= cardX && mouseX < cardX + cardWidth
                    && mouseY >= cardY && mouseY < cardY + CARD_HEIGHT;
            boolean isCurrent = currentlyDisguised && entry.targetName().equals(currentDisguiseName);

            int bgColor = hovered ? 0xFF334155 : (isCurrent ? 0xFF3B2F12 : 0xFF1E293B);
            int borderColor = isCurrent ? 0xFFFBBF24 : (hovered ? 0xFF94A3B8 : 0xFF475569);

            context.fill(cardX, cardY, cardX + cardWidth, cardY + CARD_HEIGHT, bgColor);
            context.drawBorder(cardX, cardY, cardWidth, CARD_HEIGHT, borderColor);

            SkinTextures textures = ClientDisguiseCache.resolveSkinTextures(entry);
            PlayerSkinDrawer.draw(context, textures, cardX + 4, cardY + 3, 18);

            int textX = cardX + 26;
            int maxTextWidth = cardWidth - 30;
            String displayName = this.textRenderer.trimToWidth(entry.targetName(), maxTextWidth);
            context.drawTextWithShadow(
                    this.textRenderer,
                    displayName,
                    textX,
                    cardY + 8,
                    isCurrent ? 0xFDE047 : 0xF8FAFC
            );
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (button != 0) {
            return false;
        }

        int startIdx = page * pageSize;
        int endIdx = Math.min(onlinePlayers.size(), startIdx + pageSize);
        int innerWidth = panelWidth - 20;
        int cardWidth = (innerWidth - CARD_GAP) / 2;
        int listStartY = panelY + 36;

        for (int i = startIdx; i < endIdx; i++) {
            int localIndex = i - startIdx;
            int col = localIndex % 2;
            int row = localIndex / 2;
            int cardX = panelX + 10 + col * (cardWidth + CARD_GAP);
            int cardY = listStartY + row * (CARD_HEIGHT + CARD_GAP);

            if (mouseX >= cardX && mouseX < cardX + cardWidth
                    && mouseY >= cardY && mouseY < cardY + CARD_HEIGHT) {
                DisguiseData chosen = onlinePlayers.get(i);
                if (this.client != null) {
                    this.client.getSoundManager().play(
                            PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F)
                    );
                }
                ClientPlayNetworking.send(new SelectDisguisePayload(Optional.of(chosen.targetUuid())));
                this.close();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
