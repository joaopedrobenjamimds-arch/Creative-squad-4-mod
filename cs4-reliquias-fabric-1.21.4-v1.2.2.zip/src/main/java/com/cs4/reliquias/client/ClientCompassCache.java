package com.cs4.reliquias.client;

import com.cs4.reliquias.compass.TrackedPlayerPos;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ClientCompassCache {
    private static final Map<UUID, TrackedPlayerPos> TARGET_POSITIONS = new ConcurrentHashMap<>();

    private ClientCompassCache() {
    }

    public static void setAll(Map<UUID, TrackedPlayerPos> targets) {
        TARGET_POSITIONS.clear();
        TARGET_POSITIONS.putAll(targets);
    }

    public static TrackedPlayerPos get(UUID targetUuid) {
        if (targetUuid == null) {
            return null;
        }
        return TARGET_POSITIONS.get(targetUuid);
    }

    public static void clear() {
        TARGET_POSITIONS.clear();
    }
}
