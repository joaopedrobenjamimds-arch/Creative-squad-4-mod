package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.client.ClientDisguiseCache;
import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.disguise.DisguiseState;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkinTextures", at = @At("HEAD"), cancellable = true)
    private void cs4$overrideDisguiseSkin(CallbackInfoReturnable<SkinTextures> cir) {
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
        DisguiseData disguise = DisguiseState.getClientDisguise(self.getUuid());
        if (disguise != null) {
            cir.setReturnValue(ClientDisguiseCache.resolveSkinTextures(disguise));
        }
    }
}
