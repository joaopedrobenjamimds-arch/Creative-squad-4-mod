package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.client.ClientCompassCache;
import com.cs4.reliquias.compass.TrackedPlayerPos;
import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.client.render.item.property.numeric.CompassState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(CompassState.class)
public class CompassStateMixin {
    @Shadow
    private float getAngleTo(Entity entity, long time, BlockPos pos) {
        return 0.0F;
    }

    @Shadow
    private float getAimlessAngle(int seed, long time) {
        return 0.0F;
    }

    @Inject(method = "getAngle", at = @At("HEAD"), cancellable = true)
    private void cs4$pointCompassAtTrackedPlayer(
            ItemStack stack,
            ClientWorld world,
            int seed,
            Entity user,
            CallbackInfoReturnable<Float> cir
    ) {
        if (!RelicManager.isBussolaLendaria(stack) || world == null || user == null) {
            return;
        }

        UUID targetUuid = RelicManager.getTrackedTargetUuid(stack);
        if (targetUuid == null) {
            cir.setReturnValue(this.getAimlessAngle(seed, world.getTime()));
            return;
        }

        PlayerEntity liveTarget = world.getPlayerByUuid(targetUuid);
        if (liveTarget != null) {
            cir.setReturnValue(this.getAngleTo(user, world.getTime(), liveTarget.getBlockPos()));
            return;
        }

        TrackedPlayerPos synced = ClientCompassCache.get(targetUuid);
        if (synced != null && world.getRegistryKey().getValue().equals(synced.dimensionId())) {
            cir.setReturnValue(this.getAngleTo(user, world.getTime(), synced.pos()));
            return;
        }

        cir.setReturnValue(this.getAimlessAngle(seed, world.getTime()));
    }
}
