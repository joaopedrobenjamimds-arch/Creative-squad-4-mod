package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.client.ClientDisguiseCache;
import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.disguise.DisguiseState;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerListEntry.class)
public class PlayerListEntryMixin {
    @Inject(method = "getSkinTextures", at = @At("HEAD"), cancellable = true)
    private void cs4$overrideTabHeadSkin(CallbackInfoReturnable<SkinTextures> cir) {
        if (ClientDisguiseCache.isReadingListEntry()) {
            return;
        }
        PlayerListEntry self = (PlayerListEntry) (Object) this;
        DisguiseData disguise = DisguiseState.getClientDisguise(self.getProfile().getId());
        if (disguise != null) {
            cir.setReturnValue(ClientDisguiseCache.resolveSkinTextures(disguise));
        }
    }
}
