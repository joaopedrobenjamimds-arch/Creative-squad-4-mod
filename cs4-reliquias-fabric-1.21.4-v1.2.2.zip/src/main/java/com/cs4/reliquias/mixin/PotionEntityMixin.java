package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerLegendaryPotionManager;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.WorldEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PotionEntity.class)
public class PotionEntityMixin {
    @Inject(method = "onCollision", at = @At("HEAD"), cancellable = true)
    private void cs4$onPocaoLendariaCollision(HitResult hitResult, CallbackInfo ci) {
        PotionEntity self = (PotionEntity) (Object) this;
        ItemStack stack = self.getStack();
        if (!RelicManager.isPocaoLendaria(stack)) {
            return;
        }

        if (self.getWorld() instanceof ServerWorld serverWorld) {
            ServerLegendaryPotionManager.handleSplashCollision(serverWorld, self, hitResult);
            serverWorld.syncWorldEvent(
                    WorldEvents.SPLASH_POTION_SPLASHED,
                    self.getBlockPos(),
                    RelicManager.POCAO_LENDARIA_COLOR
            );
            self.discard();
        }
        ci.cancel();
    }
}
