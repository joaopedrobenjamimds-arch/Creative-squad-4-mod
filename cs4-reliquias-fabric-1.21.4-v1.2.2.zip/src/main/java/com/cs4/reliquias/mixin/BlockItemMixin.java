package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.DragonBreathAbility;
import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockItem.class)
public class BlockItemMixin {
    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("HEAD"), cancellable = true)
    private void cs4$preventRelicPlacement(ItemPlacementContext context, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack stack = context.getStack();
        if (RelicManager.isLampiaoLendario(stack)) {
            cir.setReturnValue(ActionResult.FAIL);
            return;
        }
        if (RelicManager.isDragaoLendario(stack)) {
            PlayerEntity player = context.getPlayer();
            if (player == null || player.getItemCooldownManager().isCoolingDown(stack)) {
                cir.setReturnValue(ActionResult.FAIL);
                return;
            }
            if (context.getWorld() instanceof ServerWorld serverWorld) {
                DragonBreathAbility.fire(serverWorld, player, stack);
            }
            cir.setReturnValue(ActionResult.SUCCESS);
        }
    }
}
