package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.disguise.DisguiseState;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {
    @Inject(method = "getPlayerName", at = @At("HEAD"), cancellable = true)
    private void cs4$overrideTabPlayerName(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        if (entry == null) {
            return;
        }
        DisguiseData disguise = DisguiseState.getClientDisguise(entry.getProfile().getId());
        if (disguise != null) {
            cir.setReturnValue(Text.literal(disguise.targetName()));
        }
    }
}
