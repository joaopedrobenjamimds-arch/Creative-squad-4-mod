package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.SonicBoomAbility;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DamageSource.class)
public class DamageSourceMixin {
    @Inject(method = "isScaledWithDifficulty", at = @At("HEAD"), cancellable = true)
    private void cs4$fixedSonicBoomPlayerDamage(CallbackInfoReturnable<Boolean> cir) {
        if (SonicBoomAbility.isApplying()) {
            cir.setReturnValue(false);
        }
    }
}
