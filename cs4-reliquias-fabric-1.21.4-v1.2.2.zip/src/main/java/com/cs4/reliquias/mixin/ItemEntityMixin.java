package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerRelicProtectionManager;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(ItemEntity.class)
public class ItemEntityMixin {
    @Shadow
    private int itemAge;

    @Shadow
    @Nullable
    private UUID throwerUuid;

    @Shadow
    @Nullable
    private UUID owner;

    @Inject(method = "isFireImmune", at = @At("HEAD"), cancellable = true)
    private void cs4$relicFireImmune(CallbackInfoReturnable<Boolean> cir) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (RelicManager.isAnyRelic(self.getStack())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void cs4$relicDamageProtection(
            ServerWorld world,
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (!RelicManager.isAnyRelic(self.getStack())) {
            return;
        }
        if (source.isOf(DamageTypes.CACTUS)) {
            return;
        }
        if (source.isOf(DamageTypes.OUT_OF_WORLD)) {
            ServerRelicProtectionManager.rescueFromVoid(self, this.throwerUuid, this.owner);
            cir.setReturnValue(false);
            return;
        }
        self.extinguish();
        cir.setReturnValue(false);
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void cs4$relicGroundAndVoidProtection(CallbackInfo ci) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (self.getWorld().isClient || self.isRemoved()) {
            return;
        }
        ItemStack stack = self.getStack();
        if (!RelicManager.isAnyRelic(stack)) {
            return;
        }
        if (this.itemAge >= 5000) {
            this.itemAge = 1000;
        }
        if (self.isOnFire()) {
            self.extinguish();
        }
        if (self.getY() < (double) (self.getWorld().getBottomY() - 8)) {
            ServerRelicProtectionManager.rescueFromVoid(self, this.throwerUuid, this.owner);
            ci.cancel();
        }
    }
}
