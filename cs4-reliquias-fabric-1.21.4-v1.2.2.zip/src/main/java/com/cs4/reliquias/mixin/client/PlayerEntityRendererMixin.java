package com.cs4.reliquias.mixin.client;

import com.cs4.reliquias.client.ClientDisguiseCache;
import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.disguise.DisguiseState;
import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
    @Inject(
            method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("TAIL")
    )
    private void cs4$applyLampiaoState(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (RelicManager.isHoldingLampiao(player)) {
            state.invisible = true;
            state.invisibleToPlayer = true;
            state.displayName = null;
            state.nameLabelPos = null;
            state.playerName = null;
            state.name = "";
            state.hasOutline = false;
            state.onFire = false;
            state.capeVisible = false;
            state.hatVisible = false;
            state.jacketVisible = false;
            state.leftSleeveVisible = false;
            state.rightSleeveVisible = false;
            state.leftPantsLegVisible = false;
            state.rightPantsLegVisible = false;
            state.stuckArrowCount = 0;
            state.stingerCount = 0;
            state.leftHandItemState.clear();
            state.rightHandItemState.clear();
            state.headItemRenderState.clear();
            state.wearingSkullProfile = null;
            state.wearingSkullType = null;
            state.equippedHeadStack = ItemStack.EMPTY;
            state.equippedLegsStack = ItemStack.EMPTY;
            state.equippedFeetStack = ItemStack.EMPTY;
            if (!state.equippedChestStack.isOf(Items.ELYTRA)) {
                state.equippedChestStack = ItemStack.EMPTY;
            }
            return;
        }

        DisguiseData disguise = DisguiseState.getClientDisguise(player.getUuid());
        if (disguise != null) {
            state.skinTextures = ClientDisguiseCache.resolveSkinTextures(disguise);
            state.name = disguise.targetName();
            state.displayName = Team.decorateName(player.getScoreboardTeam(), Text.literal(disguise.targetName()));
            if (state.playerName != null) {
                state.playerName = Text.literal(disguise.targetName());
            }
        }
    }

    @Inject(method = "renderRightArm", at = @At("HEAD"), cancellable = true)
    private void cs4$hideFirstPersonRightArm(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            Identifier skinTexture,
            boolean sleeveVisible,
            CallbackInfo ci
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && RelicManager.isHoldingLampiao(client.player)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"), cancellable = true)
    private void cs4$hideFirstPersonLeftArm(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            Identifier skinTexture,
            boolean sleeveVisible,
            CallbackInfo ci
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && RelicManager.isHoldingLampiao(client.player)) {
            ci.cancel();
        }
    }
}
