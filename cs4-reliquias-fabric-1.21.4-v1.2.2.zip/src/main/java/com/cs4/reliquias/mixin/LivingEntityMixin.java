package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "isBlocking", at = @At("HEAD"), cancellable = true)
    private void cs4$disableEscudoLendarioBlocking(CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (RelicManager.isEscudoLendario(self.getActiveItem())) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "getNextAirUnderwater", at = @At("HEAD"), cancellable = true)
    private void cs4$infiniteAirWithTwinHelmet(int air, CallbackInfoReturnable<Integer> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof PlayerEntity player && RelicManager.isWearingCapaceteGemeos(player)) {
            cir.setReturnValue(self.getMaxAir());
        }
    }
}
