package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerLegendaryPotionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SplashPotionItem.class)
public class SplashPotionItemMixin {
    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void cs4$usePocaoLendaria(World world, PlayerEntity user, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack stack = user.getStackInHand(hand);
        if (!RelicManager.isPocaoLendaria(stack)) {
            return;
        }

        if (user.getItemCooldownManager().isCoolingDown(stack)) {
            cir.setReturnValue(ActionResult.FAIL);
            return;
        }

        if (world instanceof ServerWorld serverWorld) {
            if (!ServerLegendaryPotionManager.tryBeginThrow(user, stack)) {
                cir.setReturnValue(ActionResult.FAIL);
                return;
            }

            world.playSound(
                    null,
                    user.getX(),
                    user.getY(),
                    user.getZ(),
                    SoundEvents.ENTITY_SPLASH_POTION_THROW,
                    SoundCategory.PLAYERS,
                    0.5F,
                    0.4F / (world.getRandom().nextFloat() * 0.4F + 0.8F)
            );

            ProjectileEntity.spawnWithVelocity(
                    PotionEntity::new,
                    serverWorld,
                    stack.copyWithCount(1),
                    user,
                    -20.0F,
                    0.5F,
                    1.0F
            );

            user.incrementStat(Stats.USED.getOrCreateStat((SplashPotionItem) (Object) this));
        }

        cir.setReturnValue(ActionResult.SUCCESS);
    }
}
