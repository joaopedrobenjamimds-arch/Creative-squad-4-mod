package com.cs4.reliquias.mixin;

import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerRelicProtectionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.explosion.Explosion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "isInvisible", at = @At("HEAD"), cancellable = true)
    private void cs4$isInvisibleWithLampiao(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity player && RelicManager.isHoldingLampiao(player)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void cs4$isInvisibleToWithLampiao(PlayerEntity viewer, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity holder && RelicManager.isHoldingLampiao(holder)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "isImmuneToExplosion", at = @At("HEAD"), cancellable = true)
    private void cs4$relicExplosionImmune(Explosion explosion, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof ItemEntity itemEntity && RelicManager.isAnyRelic(itemEntity.getStack())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "tickInVoid", at = @At("HEAD"), cancellable = true)
    private void cs4$relicVoidRescueFallback(CallbackInfo ci) {
        if ((Object) this instanceof ItemEntity itemEntity && RelicManager.isAnyRelic(itemEntity.getStack())) {
            Entity ownerEntity = itemEntity.getOwner();
            UUID ownerUuid = ownerEntity != null ? ownerEntity.getUuid() : null;
            ServerRelicProtectionManager.rescueFromVoid(itemEntity, ownerUuid, null);
            ci.cancel();
        }
    }
}
