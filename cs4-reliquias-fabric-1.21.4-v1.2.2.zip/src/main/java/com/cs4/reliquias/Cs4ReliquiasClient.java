package com.cs4.reliquias;

import com.cs4.reliquias.client.BussolaScreen;
import com.cs4.reliquias.client.ClientCompassCache;
import com.cs4.reliquias.client.ClientDisguiseCache;
import com.cs4.reliquias.client.RelogioScreen;
import com.cs4.reliquias.network.OpenBussolaPayload;
import com.cs4.reliquias.network.OpenRelogioPayload;
import com.cs4.reliquias.network.SyncCompassTargetsPayload;
import com.cs4.reliquias.network.SyncDisguisesPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class Cs4ReliquiasClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(OpenRelogioPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        context.client().setScreen(new RelogioScreen(payload))
                )
        );

        ClientPlayNetworking.registerGlobalReceiver(SyncDisguisesPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        ClientDisguiseCache.setAll(payload.disguises())
                )
        );

        ClientPlayNetworking.registerGlobalReceiver(OpenBussolaPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        context.client().setScreen(new BussolaScreen(payload))
                )
        );

        ClientPlayNetworking.registerGlobalReceiver(SyncCompassTargetsPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        ClientCompassCache.setAll(payload.targets())
                )
        );

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ClientDisguiseCache.clear();
            ClientCompassCache.clear();
        });
    }
}
