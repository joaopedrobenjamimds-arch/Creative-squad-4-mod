package com.cs4.reliquias.command;

import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerRelicProtectionManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class Cs4Command {
    private Cs4Command() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                CommandManager.literal("cs4")
                        .requires(source -> source.hasPermissionLevel(2))
                        .then(CommandManager.literal("reliquias")
                                .executes(context -> {
                                    ServerCommandSource source = context.getSource();
                                    ServerPlayerEntity player = source.getPlayerOrThrow();
                                    ItemStack shulkerBox = RelicManager.createRelicsShulkerBox(source.getRegistryManager());
                                    player.giveOrDropStack(shulkerBox);
                                    source.sendFeedback(
                                            () -> Text.literal("Você recebeu a Shulker Box com as Relíquias CS4.")
                                                    .formatted(Formatting.YELLOW),
                                            false
                                    );
                                    sendCredits(source);
                                    return 1;
                                })
                                .then(CommandManager.argument("reliquia", StringArgumentType.greedyString())
                                        .suggests((context, builder) ->
                                                CommandSource.suggestMatching(RelicManager.RELIC_COMMAND_NAMES, builder)
                                        )
                                        .executes(context -> {
                                            ServerCommandSource source = context.getSource();
                                            ServerPlayerEntity player = source.getPlayerOrThrow();
                                            String name = StringArgumentType.getString(context, "reliquia");
                                            ItemStack relic = RelicManager.createRelicByName(name, source.getRegistryManager());
                                            if (relic == null) {
                                                source.sendError(Text.literal(
                                                        "Relíquia não encontrada: '" + name + "'. Opções: "
                                                                + String.join(", ", RelicManager.RELIC_COMMAND_NAMES)
                                                ));
                                                return 0;
                                            }
                                            player.giveOrDropStack(relic);
                                            source.sendFeedback(
                                                    () -> Text.literal("Você recebeu a relíquia: ")
                                                            .formatted(Formatting.YELLOW)
                                                            .append(relic.getName().copy().formatted(Formatting.GOLD)),
                                                    false
                                            );
                                            sendCredits(source);
                                            return 1;
                                        })
                                )
                        )
                        .then(CommandManager.literal("keepreliquias")
                                .executes(context -> {
                                    ServerCommandSource source = context.getSource();
                                    boolean enabled = ServerRelicProtectionManager.isKeepRelicsOnDeath();
                                    source.sendFeedback(
                                            () -> Text.literal("KeepInventory das relíquias está ")
                                                    .formatted(Formatting.YELLOW)
                                                    .append(Text.literal(enabled ? "ATIVADO" : "DESATIVADO")
                                                            .formatted(enabled ? Formatting.GREEN : Formatting.RED))
                                                    .append(Text.literal(" (use /cs4 keepreliquias true ou false).")
                                                            .formatted(Formatting.GRAY)),
                                            false
                                    );
                                    return 1;
                                })
                                .then(CommandManager.argument("ativado", BoolArgumentType.bool())
                                        .executes(context -> {
                                            ServerCommandSource source = context.getSource();
                                            boolean enabled = BoolArgumentType.getBool(context, "ativado");
                                            ServerRelicProtectionManager.setKeepRelicsOnDeath(source.getServer(), enabled);
                                            source.sendFeedback(
                                                    () -> Text.literal("KeepInventory das relíquias agora está ")
                                                            .formatted(Formatting.YELLOW)
                                                            .append(Text.literal(enabled ? "ATIVADO" : "DESATIVADO")
                                                                    .formatted(enabled ? Formatting.GREEN : Formatting.RED)),
                                                    true
                                            );
                                            return 1;
                                        })
                                )
                        )
        );
    }

    private static void sendCredits(ServerCommandSource source) {
        source.sendFeedback(
                () -> Text.literal("Créditos: ")
                        .formatted(Formatting.GRAY)
                        .append(Text.literal("@gokublackake").formatted(Formatting.GOLD))
                        .append(Text.literal(" | Feito com ajuda de ").formatted(Formatting.GRAY))
                        .append(Text.literal("aistudio.google.com").formatted(Formatting.AQUA)),
                false
        );
    }
}
