package com.cs4.reliquias.mixin;

import com.cs4.reliquias.disguise.DisguiseData;
import com.cs4.reliquias.disguise.DisguiseState;
import com.cs4.reliquias.relic.RelicManager;
import com.cs4.reliquias.relic.ServerHunterSwordManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void cs4$overrideDisguiseDisplayName(CallbackInfoReturnable<Text> cir) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        DisguiseData disguise = DisguiseState.getDisguise(self);
        if (disguise != null) {
            cir.setReturnValue(Team.decorateName(self.getScoreboardTeam(), Text.literal(disguise.targetName())));
        }
    }

    @Inject(method = "updateTurtleHelmet", at = @At("HEAD"), cancellable = true)
    private void cs4$disableVanillaTurtleTimer(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (RelicManager.isWearingCapaceteGemeos(self)) {
            ci.cancel();
        }
    }

    @Inject(method = "dropInventory", at = @At("TAIL"))
    private void cs4$forceDropInventoryOnHunterSwordKill(ServerWorld world, CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (!self.isSpectator()
                && ServerHunterSwordManager.isForcedVictim(self.getUuid())
                && world.getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) {
            self.getInventory().dropAll();
        }
    }
}
