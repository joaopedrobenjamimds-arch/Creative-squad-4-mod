# CS4 Relíquias (Minecraft 1.21.4 - Fabric)

Mod inspirado nos Itens Lendários da Creative Squad 4, utilizando exclusivamente itens vanilla modificados via Data Components e Mixins.

## Relíquias incluídas nesta versão
- **Relíquia 01 — Lampião Lendário** (`minecraft:soul_lantern`)
  - Nome amarelo: `Lampião Lendário`
  - Invisibilidade automática ao segurar na mão principal ou secundária
  - Zero partículas
  - Oculta corpo, skin, armadura, itens nas mãos (em 3ª pessoa/multiplayer) e nametag, mantendo a **Elytra visível** e a proteção da armadura intacta
  - Em 1ª pessoa: mão invisível, itens nas mãos visíveis
  - Bloqueado de ser colocado no chão, permitindo interação normal com baús, shulkers, botões e portas
- **Relíquia 02 — Escudo Lendário** (`minecraft:shield`)
  - Nome amarelo: `Escudo Lendário`
  - Não defende ataques; o botão direito dispara diretamente uma rajada sônica na direção em que o jogador estiver olhando
  - Efeito visual e sonoro do Sonic Boom do Warden
  - Causa 4 corações de dano (8 HP) em mobs e jogadores ignorando completamente a armadura do alvo
  - Recarga individual de 15 segundos por jogador
- **Relíquia da mineração** (`minecraft:iron_pickaxe`)
  - Nome amarelo: `Relíquia da mineração`, brilho de encantamento, Eficiência 1000 (tooltip oculto) e inquebrável
- **Relíquia 04 — Relógio Lendário** (`minecraft:clock`)
  - Nome amarelo: `Relógio Lendário`
  - Botão direito abre uma GUI personalizada listando todos os jogadores online com cabeça e nome
  - Permite assumir fielmente a skin e o nome visual do jogador escolhido (sincronizado no multiplayer)
  - Possui botão **Voltar ao Normal** para restaurar completamente a skin e o nome originais
- **Relíquia 05 — Bússola Lendária** (`minecraft:compass`)
  - Nome amarelo: `Bússola Lendária`
  - Botão direito abre a mesma GUI de jogadores online com cabeça e nome
  - Ao clicar em um jogador, a bússola passa a apontar continuamente para ele, atualizando dinamicamente conforme o alvo se movimenta no multiplayer
- **Relíquia 06 — Capacetes Lendários dos Gêmeos** (`2x minecraft:turtle_helmet`)
  - Nome amarelo: `Capacete Lendário dos Gêmeos`
  - Concede +5 corações de vida máxima (10 HP adicionais) apenas enquanto equipado na cabeça, sem acumular ou persistir ao remover
  - Respiração aquática infinita debaixo d'água (sem perda de oxigênio) enquanto equipado na cabeça
  - Vínculo de vida compartilhada e morte automática entre os dois portadores no multiplayer, independentemente da distância
- **Relíquia 07 — Tridente Lendário** (`minecraft:trident`)
  - Nome amarelo: `Tridente Lendário`
  - Encantamentos (tooltip oculto): **Lealdade III** (`Loyalty III`), **Empalamento VII** (`Impaling VII`) e **Afiação VII** (`Sharpness VII`)
  - Velocidade de ataque aumentada (`2.4` vs `1.1` do tridente comum)
  - Funcionamento vanilla completo para ataques corpo a corpo e arremesso com retorno pela Lealdade III
- **Relíquia 08 — Espada do Caçador** (`minecraft:golden_sword`)
  - Nome amarelo: `Espada do Caçador`
  - Encantamento (tooltip oculto): **Repulsão X** (`Knockback X`)
  - Aplica **Mau Presságio V** (`minecraft:bad_omen` nível 5) continuamente enquanto estiver em qualquer slot do inventário (sem acumular duração e removendo o efeito ao retirar a espada)
  - Ao matar outro jogador com a Espada do Caçador, os itens da vítima são dropados normalmente no chão mesmo com `keepInventory` ativo
- **Relíquia 09 — Bota Lendária** (`minecraft:diamond_boots`)
  - Nome amarelo: `Bota Lendária`
  - Concede **Velocidade V** (`Speed 5`) exclusivamente enquanto equipada no slot dos pés (não ativa no inventário)
  - Remove o efeito imediatamente ao desequipar, sem acúmulo ou bugs após morte, troca de equipamento ou relog
- **Relíquia 10 — Poção Lendária** (`minecraft:splash_potion`)
  - Nome amarelo: `Poção Lendária`
  - Líquido, item e partículas de impacto com coloração roxa personalizada
  - Infinita (não é consumida ao arremessar contra o chão ou qualquer superfície)
  - Recarga individual de 10 segundos (200 ticks) por jogador, protegida contra troca de slot e relogin
  - Ao atingir o próprio jogador: aplica **Regeneração II** e **Saturação V** (recupera bastante fome)
  - Ao atingir outros jogadores: aplica **Cegueira** (`Blindness`)
- **Relíquia 11 — Dragão Lendário** (`minecraft:dragon_head`)
  - Nome amarelo: `Dragão Lendário`
  - Não pode ser colocado no chão ou em qualquer superfície e não pode ser equipado na cabeça
  - Ao usar (no ar ou clicando em blocos), lança o **Bafo do Dragão** na direção em que o jogador estiver olhando, com partículas e efeitos visuais característicos
  - Recarga individual de 5 segundos (100 ticks) por jogador e não é consumido ao usar
- **Relíquia 12 — Pena Lendária** (`minecraft:feather`)
  - Nome amarelo: `Pena Lendária`
  - Aplica **Levitação III** (`Levitation 3`) automaticamente apenas enquanto estiver segurada na mão principal ou secundária
  - Não ativa apenas por estar no inventário e remove o efeito imediatamente ao deixar de segurar, sem acumular duração
  - Funciona individualmente para cada jogador no Survival e multiplayer
- **Relíquia 13 — Batata do Bobo** (`minecraft:poisonous_potato`)
  - Nome amarelo: `Batata do Bobo`
  - Aplica **Lentidão** (`Slowness`) continuamente enquanto estiver em qualquer slot do inventário ou segurada na mão principal/secundária
  - Não pode ser consumida ou comida em nenhuma hipótese (`CONSUMABLE` e `FOOD` removidos + bloqueio no uso)
  - Remove o efeito automaticamente quando o jogador não possuir mais a Batata do Bobo, sem acumular duração
- **Descrição personalizada e tooltips limpos**: todas as relíquias exibem na descrição (`LORE`) o que cada uma faz (ex.: `Quebra blocos instantaneamente` na picareta) e todos os encantamentos ficam ocultos do tooltip
- **Todas as relíquias são inquebráveis** (`DataComponentTypes.UNBREAKABLE`)
- Obtido via comando: `/cs4 reliquias` (entrega uma Shulker Box Preta com as relíquias)

## Como compilar o arquivo .jar

### Opção 1: Compilação local (Java 21 + Gradle)
1. Instale o **Java 21 (JDK)** e o **Gradle 8.12+** (ou abra esta pasta no **IntelliJ IDEA**, que baixa o Gradle automaticamente).
2. No terminal dentro da pasta do projeto, execute:
   ```bash
   gradle build
   ```
3. O arquivo `.jar` compilado estará em `build/libs/cs4-reliquias-1.1.1.jar`.

### Opção 2: Compilação automática via GitHub Actions (sem instalar Java)
1. Envie esta pasta para um repositório no GitHub.
2. Abra a aba **Actions** do repositório e execute o workflow **Build CS4 Relíquias Mod**.
3. Baixe o arquivo `.jar` pronto nos **Artifacts** da execução.

## Instalação no Minecraft
1. Instale o **Fabric Loader** para **Minecraft 1.21.4**.
2. Coloque na pasta `mods/`:
   - `fabric-api-0.119.2+1.21.4.jar` (ou versão compatível da Fabric API para 1.21.4)
   - `cs4-reliquias-1.1.1.jar`
3. No jogo (com OP/cheats ativados), execute `/cs4 reliquias`.
