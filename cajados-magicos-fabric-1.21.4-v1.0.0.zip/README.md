# Cajados Mágicos (Minecraft 1.21.4 - Fabric)

Mod de artefatos mágicos usando exclusivamente itens vanilla com Data Components e Mixins (sem novas texturas, IDs ou modelos).

## Artefatos incluídos
- **Cajado de Fogo** (`minecraft:blaze_rod`)
  - Nome com coloração temática de fogo e brilho encantado visual
  - **Projétil de Fogo**: botão direito lança uma bola de fogo com rastro de chamas na direção do olhar, causando dano considerável sem destruir blocos e consumindo meia barra de fome (10 pontos) por uso
  - **Proteção contra Fogo**: imunidade total a fogo e lava enquanto estiver em qualquer slot do inventário (removida imediatamente ao retirar)
  - **Voo das Chamas**: voo livre em todas as direções enquanto estiver no inventário e com fome acima de zero, drenando a fome lentamente (~5 minutos de voo com a barra cheia) como cansaço, com partículas de fogo acompanhando o jogador e queda normal ao retirar ou zerar a fome
  - **Recarga**: 6 segundos individuais por jogador, protegida contra troca de slot, drop ou relogin
- **Cajado Glacial** (`minecraft:prismarine_shard`)
  - Nome azul-claro e brilho encantado visual
  - **Projétil Glacial**: botão direito dispara esfera de gelo causando 4 corações (8 HP) de dano, Lentidão IV por 4s e partículas de gelo no impacto sem destruir blocos (recarga de 2s)
  - **Congelamento em Área**: agachar + botão direito libera onda congelante em raio de 5 blocos aplicando Lentidão VI por 5s sem afetar o portador (recarga de 12s)
  - **Aura Glacial**: enquanto estiver em qualquer slot do inventário, concede Resistência I, Velocidade II e Super Pulo II, desacelera inimigos em até 3 blocos e gera partículas discretas de gelo (removendo todos os efeitos ao retirar)
  - **Caminhar sobre a Água**: enquanto segurado na mão principal ou secundária, congela temporariamente a superfície da água (rios, lagos e oceanos) e descongela ao se afastar ou soltar o cajado
  - **Passos Glaciais**: remove aceleração e deslizamento em gelo comum, compactado e azul enquanto estiver no inventário ou mãos
- **Cajado da Cura** (`minecraft:heart_of_the_sea`)
  - Nome verde e brilho encantado visual
  - **Cura Instantânea**: botão direito recupera 4 corações (8 HP) do próprio jogador sem ultrapassar a vida máxima (recarga de 5s)
  - **Cura em Área**: agachar + botão direito cura jogadores aliados em raio de 6 blocos em 4 corações (8 HP) sem curar inimigos (recarga de 15s)
  - **Bênção Vital**: enquanto estiver em qualquer slot do inventário, concede Regeneração I por 3s renovada continuamente com partículas verdes discretas (removida ao retirar)
  - **Purificação**: ao ativar com efeitos negativos ativos (Veneno, Wither, Lentidão, Fraqueza, etc.), remove todos os efeitos prejudiciais com efeito visual verde (recarga de 12s)
  - **Última Chance**: ao ficar com 3 corações (6 HP) ou menos, cura automaticamente 5 corações (10 HP) com efeito visual intenso (recarga de 60s, sem repetir enquanto permanecer com pouca vida)
- **Cajado da Gravidade** (`minecraft:echo_shard`)
  - Nome roxo e brilho encantado visual
  - **Meteoro Gravitacional**: botão direito invoca um bloco de pedra do céu caindo como meteoro na direção mirada, causando 8 corações (16 HP) ao atingir entidades, onda de impacto com partículas de pedra/poeira e empurrão sem destruir blocos (recarga de 5s)
  - **Repulsão Gravitacional**: agachar + botão direito empurra entidades em raio de 6 blocos para longe com partículas roxas e azuis (recarga de 8s)
  - **Campo de Gravidade**: botão esquerdo cria no ponto mirado uma área gravitacional de 5 blocos que puxa entidades para o centro por 4s com partículas roxas (recarga de 15s)
  - **Voo Gravitacional**: voo livre em qualquer slot do inventário com rastro mágico de partículas azuis e roxas nos pés e corpo (removido imediatamente ao retirar)
  - **Imunidade à Queda**: imunidade total a dano de queda de qualquer altura enquanto estiver em qualquer slot do inventário (removida imediatamente ao retirar)
- **Cajado do Teleporte** (`minecraft:ender_pearl`)
  - Nome roxo e brilho encantado visual
  - **Salto Dimensional**: botão direito teleporta até 25 blocos na direção mirada (sem precisar acertar entidade e sem entrar em blocos sólidos) com partículas roxas e azuis (recarga de 3s)
  - **Troca Dimensional**: agachar + botão direito mirando em outro jogador troca instantaneamente a posição entre os dois com distorção dimensional (recarga de 10s; bloqueada se destino obstruído)
  - **Retorno (Save Point)**: agachar + botão esquerdo salva posição exata (X, Y, Z, dimensão e orientação) permanentemente por jogador; botão esquerdo teleporta de volta a qualquer momento e entre dimensões com checagem de segurança
  - **Passagem Etérea**: enquanto estiver em qualquer slot do inventário, concede Velocidade II com partículas roxas discretas (removida imediatamente ao retirar)
  - **Fenda Dimensional**: agachar + botão direito (sem mirar em outro jogador) cria um portal pessoal de 30 segundos (recarga de 45s) e permite retornar ao portal enquanto estiver ativo
- **Cajado das Sombras** (`minecraft:amethyst_shard`)
  - Nome roxo-escuro e brilho encantado visual
  - **Projétil Sombrio**: botão esquerdo dispara energia negra na direção mirada causando 3 corações (6 HP) ao acertar jogador ou mob, com rastro de partículas pretas e pequena explosão de fumaça negra sem destruir blocos (recarga de 1,5s)
  - **Teleporte Sombrio**: botão direito teleporta até 10 blocos à frente evitando blocos sólidos ou locais onde ficaria preso, com nuvem de fumaça negra na partida e na chegada (recarga de 3s)
  - **Forma Sombria**: agachar (Shift) + botão esquerdo transforma o jogador em sombra por 5 segundos com invulnerabilidade total, super velocidade, salto de ~3 blocos e corpo completamente encoberto por partículas negras e aura de fumaça preta (recarga de 25s)
  - **Voo das Sombras**: voo livre em todas as direções enquanto estiver em qualquer slot do inventário, com partículas pretas e roxas acompanhando o jogador (removido imediatamente ao retirar)
- **⚡ Cajado do Thor** (`minecraft:mace`)
  - Nome em azul elétrico e dourado com brilho encantado visual; inquebrável e com ataques/dano/esmagamento originais da Maça desativados
  - **Voo Divino**: voo livre responsivo em qualquer slot do inventário com partículas azuis e douradas + rastro elétrico (removido imediatamente ao retirar)
  - **Projétil Elétrico**: botão direito dispara esfera de energia elétrica com partículas azuis, cinzas e brancas causando dano e explosão elétrica no impacto sem destruir blocos nem causar incêndio (recarga de 1s)
  - **Raio Divino**: botão esquerdo invoca um raio no ponto mirado causando 6 corações (12 HP) com partículas azuis e brancas e trovão, sem fogo ou destruição de blocos (recarga de 3s)
  - **Ira de Thor**: agachar (Shift) + botão esquerdo cria uma tempestade elétrica de 5s em raio de 8 blocos lançando raios aleatórios contra inimigos (3 corações cada, sem atingir o usuário, recarga de 20s)
  - **Impacto Divino**: agachar (Shift) + botão direito impulsiona o jogador para o alto e o faz descer golpeando o chão com onda de energia de 6 blocos causando 4 corações (8 HP) e knockback sem destruir blocos (recarga de 10s)
  - **Resistência a Raios**: imunidade total a raios naturais e invocados enquanto estiver em qualquer slot do inventário, sem conceder imunidade a fogo ou lava
- **Obtidos exclusivamente por comando**: `/cajados` ou `/cajados todos` (todos os cajados) e `/cajados <nome>` (individual, sem receita de crafting)

## Como compilar o arquivo .jar

### Opção 1: Compilação automática via GitHub Actions
1. Envie o arquivo `cajados-magicos-fabric-1.21.4-v1.0.0.zip` para o seu repositório no GitHub.
2. Abra a aba **Actions** e execute **Build Cajados Magicos Mod**.
3. Baixe o arquivo `.jar` nos **Artifacts** (`cajados-magicos-1.21.4-jar`).

### Opção 2: Compilação local (Java 21 + Gradle)
```bash
gradle build
```
Gera `build/libs/cajados-magicos-1.0.0.jar`.
