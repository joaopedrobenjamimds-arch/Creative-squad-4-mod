package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.PersistentState;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerTeleportStaffManager {
    public static final int SALTO_COOLDOWN_TICKS = 60;
    public static final long SALTO_COOLDOWN_MS = 3_000L;
    public static final double SALTO_MAX_DISTANCE = 25.0;

    public static final long TROCA_COOLDOWN_MS = 10_000L;
    public static final double TROCA_MAX_DISTANCE = 40.0;

    public static final int RIFT_DURATION_TICKS = 600;
    public static final long RIFT_COOLDOWN_MS = 45_000L;
    public static final long RIFT_RETURN_DEBOUNCE_MS = 500L;

    public static final int ETHEREAL_SPEED_TICKS = 60;
    public static final String SAVE_STATE_NAME = "cajados_teleporte_save_points";

    public static final Identifier SALTO_COOLDOWN_GROUP_ID =
            Identifier.of(CajadosMagicosMod.MOD_ID, StaffManager.CAJADO_TELEPORTE_ID + "_salto");

    private static final DustParticleEffect PURPLE_DUST = new DustParticleEffect(0xA855F7, 1.3F);
    private static final DustParticleEffect DISCREET_PURPLE_DUST = new DustParticleEffect(0xC084FC, 0.9F);
    private static final DustParticleEffect BLUE_DUST = new DustParticleEffect(0x38BDF8, 1.25F);

    private static final Map<UUID, Long> SALTO_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> TROCA_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> RIFT_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> RIFT_LAST_RETURN_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_RIGHT_CLICK_TICK = new ConcurrentHashMap<>();
    private static final Map<UUID, PersonalRift> ACTIVE_RIFTS = new ConcurrentHashMap<>();
    private static final Set<UUID> ETHEREAL_ACTIVE_HOLDERS = ConcurrentHashMap.newKeySet();

    private static long serverTickCounter = 0L;

    private ServerTeleportStaffManager() {
    }

    public record SavedPoint(RegistryKey<World> worldKey, double x, double y, double z, float yaw, float pitch) {
    }

    private static final class PersonalRift {
        final RegistryKey<World> worldKey;
        final double x;
        final double y;
        final double z;
        final float yaw;
        final float pitch;
        int remainingTicks;

        PersonalRift(RegistryKey<World> worldKey, double x, double y, double z, float yaw, float pitch, int remainingTicks) {
            this.worldKey = worldKey;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
            this.remainingTicks = remainingTicks;
        }
    }

    private static final class TeleportSavePointState extends PersistentState {
        private static final Type<TeleportSavePointState> TYPE = new Type<>(
                TeleportSavePointState::new,
                TeleportSavePointState::fromNbt,
                null
        );

        private final Map<UUID, SavedPoint> points = new ConcurrentHashMap<>();

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
            NbtCompound root = new NbtCompound();
            for (Map.Entry<UUID, SavedPoint> entry : points.entrySet()) {
                SavedPoint p = entry.getValue();
                NbtCompound tag = new NbtCompound();
                tag.putString("dim", p.worldKey().getValue().toString());
                tag.putDouble("x", p.x());
                tag.putDouble("y", p.y());
                tag.putDouble("z", p.z());
                tag.putFloat("yaw", p.yaw());
                tag.putFloat("pitch", p.pitch());
                root.put(entry.getKey().toString(), tag);
            }
            nbt.put("save_points", root);
            return nbt;
        }

        private static TeleportSavePointState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
            TeleportSavePointState state = new TeleportSavePointState();
            NbtCompound root = nbt.getCompound("save_points");
            for (String key : root.getKeys()) {
                try {
                    UUID uuid = UUID.fromString(key);
                    NbtCompound tag = root.getCompound(key);
                    Identifier dimId = Identifier.tryParse(tag.getString("dim"));
                    if (dimId == null) {
                        continue;
                    }
                    RegistryKey<World> worldKey = RegistryKey.of(RegistryKeys.WORLD, dimId);
                    SavedPoint point = new SavedPoint(
                            worldKey,
                            tag.getDouble("x"),
                            tag.getDouble("y"),
                            tag.getDouble("z"),
                            tag.getFloat("yaw"),
                            tag.getFloat("pitch")
                    );
                    state.points.put(uuid, point);
                } catch (IllegalArgumentException ignored) {
                }
            }
            return state;
        }

        @Nullable
        SavedPoint getPoint(UUID uuid) {
            return points.get(uuid);
        }

        void setPoint(UUID uuid, SavedPoint point) {
            points.put(uuid, point);
            markDirty();
        }
    }

    private static TeleportSavePointState getSaveState(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(
                TeleportSavePointState.TYPE,
                SAVE_STATE_NAME
        );
    }

    public static void markRightClick(UUID playerUuid) {
        if (playerUuid != null) {
            LAST_RIGHT_CLICK_TICK.put(playerUuid, serverTickCounter);
        }
    }

    public static boolean tryUseTeleportStaff(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        if (player.isSneaking()) {
            ServerPlayerEntity target = findTargetPlayer(player, TROCA_MAX_DISTANCE);
            if (target != null) {
                return tryDimensionalSwap(player, target);
            }
            return tryUseDimensionalRift(player);
        }
        return tryDimensionalJump(player);
    }

    public static boolean tryDimensionalJump(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = SALTO_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            return false;
        }

        ServerWorld world = player.getServerWorld();
        Vec3d eyePos = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d maxEnd = eyePos.add(look.multiply(SALTO_MAX_DISTANCE));

        BlockHitResult hit = world.raycast(new RaycastContext(
                eyePos,
                maxEnd,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));

        Vec3d candidate;
        if (hit.getType() != HitResult.Type.MISS) {
            Vec3d faceOffset = Vec3d.of(hit.getSide().getVector()).multiply(0.65);
            candidate = hit.getPos().add(faceOffset);
        } else {
            candidate = maxEnd;
        }

        Vec3d safeDest = findSafeTeleportPos(world, candidate, look.multiply(-1.0), player);
        if (safeDest == null) {
            player.sendMessage(
                    Text.literal("Destino obstruído para o Salto Dimensional.")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        SALTO_COOLDOWN_UNTIL_MS.put(uuid, now + SALTO_COOLDOWN_MS);
        player.getItemCooldownManager().set(SALTO_COOLDOWN_GROUP_ID, SALTO_COOLDOWN_TICKS);

        Vec3d departure = player.getPos();
        spawnTeleportBurst(world, departure);

        player.fallDistance = 0.0F;
        player.teleport(world, safeDest.x, safeDest.y, safeDest.z, Set.of(), player.getYaw(), player.getPitch(), false);
        player.setVelocity(Vec3d.ZERO);
        player.velocityModified = true;

        spawnTeleportBurst(world, safeDest);
        world.playSound(
                null,
                safeDest.x,
                safeDest.y,
                safeDest.z,
                SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                SoundCategory.PLAYERS,
                1.0F,
                1.1F
        );
        return true;
    }

    private static boolean tryDimensionalSwap(ServerPlayerEntity player, ServerPlayerEntity target) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = TROCA_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            long sec = Math.max(1L, (until - now + 999L) / 1000L);
            player.sendMessage(
                    Text.literal("Troca Dimensional em recarga (" + sec + "s).")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        ServerWorld worldA = player.getServerWorld();
        ServerWorld worldB = target.getServerWorld();
        if (worldA != worldB) {
            player.sendMessage(
                    Text.literal("Destino inválido para Troca Dimensional.")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        Vec3d posA = player.getPos();
        float yawA = player.getYaw();
        float pitchA = player.getPitch();

        Vec3d posB = target.getPos();
        float yawB = target.getYaw();
        float pitchB = target.getPitch();

        if (!isSafeStandPos(worldA, posB, player) || !isSafeStandPos(worldA, posA, target)) {
            player.sendMessage(
                    Text.literal("Destino inválido ou obstruído para Troca Dimensional.")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        TROCA_COOLDOWN_UNTIL_MS.put(uuid, now + TROCA_COOLDOWN_MS);

        spawnDimensionalDistortion(worldA, posA);
        spawnDimensionalDistortion(worldA, posB);

        player.fallDistance = 0.0F;
        target.fallDistance = 0.0F;
        player.teleport(worldA, posB.x, posB.y, posB.z, Set.of(), yawB, pitchB, false);
        target.teleport(worldA, posA.x, posA.y, posA.z, Set.of(), yawA, pitchA, false);

        spawnDimensionalDistortion(worldA, posA);
        spawnDimensionalDistortion(worldA, posB);

        worldA.playSound(null, posA.x, posA.y, posA.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 0.85F);
        worldA.playSound(null, posB.x, posB.y, posB.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 0.85F);
        return true;
    }

    private static boolean tryUseDimensionalRift(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        PersonalRift activeRift = ACTIVE_RIFTS.get(uuid);

        if (activeRift != null && activeRift.remainingTicks > 0) {
            Long lastReturn = RIFT_LAST_RETURN_MS.get(uuid);
            if (lastReturn != null && (now - lastReturn) < RIFT_RETURN_DEBOUNCE_MS) {
                return false;
            }
            MinecraftServer server = player.getServer();
            if (server == null) {
                return false;
            }
            ServerWorld targetWorld = server.getWorld(activeRift.worldKey);
            if (targetWorld == null) {
                ACTIVE_RIFTS.remove(uuid);
                return false;
            }
            targetWorld.getChunk(BlockPos.ofFloored(activeRift.x, activeRift.y, activeRift.z));
            Vec3d riftPos = new Vec3d(activeRift.x, activeRift.y, activeRift.z);
            Vec3d safeDest = findSafeTeleportPos(targetWorld, riftPos, Vec3d.ZERO, player);
            if (safeDest == null) {
                player.sendMessage(
                        Text.literal("A Fenda Dimensional está obstruída no destino.")
                                .formatted(Formatting.LIGHT_PURPLE),
                        true
                );
                return false;
            }

            RIFT_LAST_RETURN_MS.put(uuid, now);
            spawnTeleportBurst(player.getServerWorld(), player.getPos());
            player.fallDistance = 0.0F;
            player.teleport(targetWorld, safeDest.x, safeDest.y, safeDest.z, Set.of(), activeRift.yaw, activeRift.pitch, false);
            player.setVelocity(Vec3d.ZERO);
            player.velocityModified = true;
            spawnTeleportBurst(targetWorld, safeDest);
            targetWorld.playSound(null, safeDest.x, safeDest.y, safeDest.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.25F);
            return true;
        }

        Long until = RIFT_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            long sec = Math.max(1L, (until - now + 999L) / 1000L);
            player.sendMessage(
                    Text.literal("Fenda Dimensional em recarga (" + sec + "s).")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        RIFT_COOLDOWN_UNTIL_MS.put(uuid, now + RIFT_COOLDOWN_MS);
        RIFT_LAST_RETURN_MS.put(uuid, now);
        ServerWorld world = player.getServerWorld();
        Vec3d pos = player.getPos();
        ACTIVE_RIFTS.put(uuid, new PersonalRift(
                world.getRegistryKey(),
                pos.x,
                pos.y,
                pos.z,
                player.getYaw(),
                player.getPitch(),
                RIFT_DURATION_TICKS
        ));

        spawnTeleportBurst(world, pos);
        world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_PORTAL_TRIGGER, SoundCategory.PLAYERS, 0.85F, 1.3F);
        player.sendMessage(
                Text.literal("Fenda Dimensional aberta por 30s! Use Agachar + Botão Direito novamente para retornar.")
                        .formatted(Formatting.LIGHT_PURPLE),
                true
        );
        return true;
    }

    public static void tryHandleLeftClickSwing(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return;
        }
        if (!StaffManager.isCajadoTeleporte(player.getMainHandStack())) {
            return;
        }
        Long lastRightClick = LAST_RIGHT_CLICK_TICK.get(player.getUuid());
        if (lastRightClick != null && (serverTickCounter - lastRightClick) <= 3L) {
            return;
        }

        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        TeleportSavePointState state = getSaveState(server);
        UUID uuid = player.getUuid();

        if (player.isSneaking()) {
            ServerWorld world = player.getServerWorld();
            Vec3d pos = player.getPos();
            SavedPoint point = new SavedPoint(
                    world.getRegistryKey(),
                    pos.x,
                    pos.y,
                    pos.z,
                    player.getYaw(),
                    player.getPitch()
            );
            state.setPoint(uuid, point);

            spawnSaveOrReturnEffect(world, pos);
            world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_RESPAWN_ANCHOR_SET_SPAWN, SoundCategory.PLAYERS, 1.0F, 1.2F);
            player.sendMessage(
                    Text.literal(String.format("Ponto de retorno salvo (%.1f, %.1f, %.1f).", pos.x, pos.y, pos.z))
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return;
        }

        SavedPoint saved = state.getPoint(uuid);
        if (saved == null) {
            player.sendMessage(
                    Text.literal("Nenhum ponto salvo. Use Agachar + Botão Esquerdo para salvar sua posição.")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return;
        }

        ServerWorld targetWorld = server.getWorld(saved.worldKey());
        if (targetWorld == null) {
            player.sendMessage(
                    Text.literal("Dimensão do ponto salvo indisponível.")
                            .formatted(Formatting.RED),
                    true
            );
            return;
        }

        targetWorld.getChunk(BlockPos.ofFloored(saved.x(), saved.y(), saved.z()));
        Vec3d savedVec = new Vec3d(saved.x(), saved.y(), saved.z());
        Vec3d safeDest = findSafeTeleportPos(targetWorld, savedVec, Vec3d.ZERO, player);
        if (safeDest == null) {
            player.sendMessage(
                    Text.literal("O ponto de retorno salvo está completamente obstruído.")
                            .formatted(Formatting.RED),
                    true
            );
            return;
        }

        ServerWorld originWorld = player.getServerWorld();
        spawnSaveOrReturnEffect(originWorld, player.getPos());

        player.fallDistance = 0.0F;
        player.teleport(targetWorld, safeDest.x, safeDest.y, safeDest.z, Set.of(), saved.yaw(), saved.pitch(), false);
        player.setVelocity(Vec3d.ZERO);
        player.velocityModified = true;

        spawnSaveOrReturnEffect(targetWorld, safeDest);
        targetWorld.playSound(null, safeDest.x, safeDest.y, safeDest.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    @Nullable
    private static ServerPlayerEntity findTargetPlayer(ServerPlayerEntity player, double maxDistance) {
        ServerWorld world = player.getServerWorld();
        Vec3d eyePos = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d maxEnd = eyePos.add(look.multiply(maxDistance));

        BlockHitResult blockHit = world.raycast(new RaycastContext(
                eyePos,
                maxEnd,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));
        double maxDistSq = blockHit.getType() != HitResult.Type.MISS
                ? blockHit.getPos().squaredDistanceTo(eyePos)
                : maxDistance * maxDistance;

        EntityHitResult entityHit = ProjectileUtil.raycast(
                player,
                eyePos,
                maxEnd,
                player.getBoundingBox().stretch(look.multiply(maxDistance)).expand(0.75),
                target -> target instanceof ServerPlayerEntity other
                        && other.isAlive()
                        && !other.isSpectator()
                        && other != player,
                maxDistSq
        );

        if (entityHit != null && entityHit.getEntity() instanceof ServerPlayerEntity targetPlayer) {
            return targetPlayer;
        }
        return null;
    }

    @Nullable
    private static Vec3d findSafeTeleportPos(ServerWorld world, Vec3d candidate, Vec3d stepBackDir, Entity entity) {
        Vec3d[] verticalOffsets = new Vec3d[] {
                Vec3d.ZERO,
                new Vec3d(0.0, 0.5, 0.0),
                new Vec3d(0.0, 1.0, 0.0),
                new Vec3d(0.0, 1.5, 0.0),
                new Vec3d(0.0, 2.0, 0.0),
                new Vec3d(0.0, -0.5, 0.0),
                new Vec3d(0.0, -1.0, 0.0)
        };

        for (Vec3d vOff : verticalOffsets) {
            Vec3d test = candidate.add(vOff);
            if (isSafeStandPos(world, test, entity)) {
                return test;
            }
        }

        if (stepBackDir.lengthSquared() > 1.0E-4) {
            Vec3d normBack = stepBackDir.normalize();
            for (int step = 1; step <= 10; step++) {
                Vec3d base = candidate.add(normBack.multiply(step * 0.5));
                for (Vec3d vOff : verticalOffsets) {
                    Vec3d test = base.add(vOff);
                    if (isSafeStandPos(world, test, entity)) {
                        return test;
                    }
                }
            }
        }

        double[][] sideOffsets = new double[][] {
                {0.6, 0.0}, {-0.6, 0.0}, {0.0, 0.6}, {0.0, -0.6},
                {1.0, 0.0}, {-1.0, 0.0}, {0.0, 1.0}, {0.0, -1.0}
        };
        for (double[] sOff : sideOffsets) {
            for (Vec3d vOff : verticalOffsets) {
                Vec3d test = candidate.add(sOff[0], vOff.y, sOff[1]);
                if (isSafeStandPos(world, test, entity)) {
                    return test;
                }
            }
        }
        return null;
    }

    private static boolean isSafeStandPos(ServerWorld world, Vec3d pos, Entity entity) {
        if (!world.getWorldBorder().contains(pos.x, pos.z)) {
            return false;
        }
        if (pos.y < world.getBottomY() || pos.y > world.getTopYInclusive() - 1) {
            return false;
        }
        double halfWidth = entity.getWidth() * 0.5;
        double height = entity.getHeight();
        Box box = new Box(
                pos.x - halfWidth,
                pos.y,
                pos.z - halfWidth,
                pos.x + halfWidth,
                pos.y + height,
                pos.z + halfWidth
        );
        return world.isSpaceEmpty(entity, box);
    }

    private static void spawnTeleportBurst(ServerWorld world, Vec3d pos) {
        world.spawnParticles(PURPLE_DUST, pos.x, pos.y + 0.9, pos.z, 22, 0.45, 0.7, 0.45, 0.04);
        world.spawnParticles(BLUE_DUST, pos.x, pos.y + 0.9, pos.z, 20, 0.45, 0.7, 0.45, 0.04);
        world.spawnParticles(ParticleTypes.PORTAL, pos.x, pos.y + 0.9, pos.z, 28, 0.45, 0.65, 0.45, 0.35);
    }

    private static void spawnDimensionalDistortion(ServerWorld world, Vec3d pos) {
        world.spawnParticles(PURPLE_DUST, pos.x, pos.y + 0.9, pos.z, 28, 0.6, 0.8, 0.6, 0.06);
        world.spawnParticles(BLUE_DUST, pos.x, pos.y + 0.9, pos.z, 24, 0.6, 0.8, 0.6, 0.06);
        world.spawnParticles(ParticleTypes.REVERSE_PORTAL, pos.x, pos.y + 1.0, pos.z, 36, 0.45, 0.7, 0.45, 0.12);
        world.spawnParticles(ParticleTypes.PORTAL, pos.x, pos.y + 1.0, pos.z, 24, 0.5, 0.6, 0.5, 0.4);
    }

    private static void spawnSaveOrReturnEffect(ServerWorld world, Vec3d pos) {
        world.spawnParticles(PURPLE_DUST, pos.x, pos.y + 0.9, pos.z, 24, 0.55, 0.75, 0.55, 0.05);
        world.spawnParticles(BLUE_DUST, pos.x, pos.y + 0.9, pos.z, 20, 0.55, 0.75, 0.55, 0.05);
        world.spawnParticles(ParticleTypes.PORTAL, pos.x, pos.y + 1.0, pos.z, 36, 0.5, 0.8, 0.5, 0.45);
        world.spawnParticles(ParticleTypes.REVERSE_PORTAL, pos.x, pos.y + 0.9, pos.z, 24, 0.4, 0.6, 0.4, 0.1);
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        Long saltoUntil = SALTO_COOLDOWN_UNTIL_MS.get(uuid);
        if (saltoUntil != null) {
            long remainingMs = saltoUntil - System.currentTimeMillis();
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(
                        SALTO_COOLDOWN_TICKS,
                        Math.max(1, (int) Math.ceil(remainingMs / 50.0))
                );
                player.getItemCooldownManager().set(SALTO_COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                SALTO_COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }
    }

    public static void onDisconnect(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        removeEtherealPassageIfPresent(player);
        LAST_RIGHT_CLICK_TICK.remove(player.getUuid());
    }

    public static void tick(MinecraftServer server) {
        serverTickCounter++;

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            boolean hasStaff = player.isAlive() && !player.isSpectator() && StaffManager.hasCajadoTeleporte(player);

            if (hasStaff) {
                ETHEREAL_ACTIVE_HOLDERS.add(uuid);
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.SPEED,
                        ETHEREAL_SPEED_TICKS,
                        1,
                        true,
                        false,
                        true
                ));

                if (serverTickCounter % 4L == 0L) {
                    player.getServerWorld().spawnParticles(
                            DISCREET_PURPLE_DUST,
                            player.getX(),
                            player.getY() + 0.85,
                            player.getZ(),
                            2,
                            0.4,
                            0.45,
                            0.4,
                            0.01
                    );
                }
            } else {
                removeEtherealPassageIfPresent(player);
            }
        }

        tickRifts(server);
    }

    private static void tickRifts(MinecraftServer server) {
        if (ACTIVE_RIFTS.isEmpty()) {
            return;
        }

        Iterator<Map.Entry<UUID, PersonalRift>> iterator = ACTIVE_RIFTS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, PersonalRift> entry = iterator.next();
            PersonalRift rift = entry.getValue();
            ServerWorld world = server.getWorld(rift.worldKey);
            if (world == null || rift.remainingTicks <= 0) {
                iterator.remove();
                continue;
            }
            rift.remainingTicks--;

            if (rift.remainingTicks % 2 == 0) {
                double angle = (RIFT_DURATION_TICKS - rift.remainingTicks) * 0.25;
                for (int i = 0; i < 4; i++) {
                    double a = angle + (Math.PI * 0.5 * i);
                    double px = rift.x + Math.cos(a) * 0.85;
                    double py = rift.y + 0.35 + ((i % 2) * 0.65);
                    double pz = rift.z + Math.sin(a) * 0.85;
                    world.spawnParticles(i % 2 == 0 ? PURPLE_DUST : BLUE_DUST, px, py, pz, 1, 0.04, 0.06, 0.04, 0.01);
                }
                world.spawnParticles(ParticleTypes.PORTAL, rift.x, rift.y + 0.9, rift.z, 3, 0.28, 0.55, 0.28, 0.18);
            }
        }
    }

    private static void removeEtherealPassageIfPresent(ServerPlayerEntity player) {
        if (ETHEREAL_ACTIVE_HOLDERS.remove(player.getUuid()) && !StaffManager.hasCajadoGlacial(player)) {
            StatusEffectInstance speed = player.getStatusEffect(StatusEffects.SPEED);
            if (speed != null && speed.getAmplifier() == 1 && speed.getDuration() <= ETHEREAL_SPEED_TICKS + 5) {
                player.removeStatusEffect(StatusEffects.SPEED);
            }
        }
    }

    public static void clearServer() {
        SALTO_COOLDOWN_UNTIL_MS.clear();
        TROCA_COOLDOWN_UNTIL_MS.clear();
        RIFT_COOLDOWN_UNTIL_MS.clear();
        RIFT_LAST_RETURN_MS.clear();
        LAST_RIGHT_CLICK_TICK.clear();
        ACTIVE_RIFTS.clear();
        ETHEREAL_ACTIVE_HOLDERS.clear();
        serverTickCounter = 0L;
    }
}
