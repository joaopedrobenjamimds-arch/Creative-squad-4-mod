package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.component.type.UseCooldownComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public final class StaffManager {
    public static final String STAFF_NBT_KEY = "cajado_id";
    public static final String CAJADO_FOGO_ID = "cajado_de_fogo";
    public static final String CAJADO_GLACIAL_ID = "cajado_glacial";
    public static final String CAJADO_CURA_ID = "cajado_da_cura";
    public static final String CAJADO_GRAVIDADE_ID = "cajado_da_gravidade";
    public static final String CAJADO_TELEPORTE_ID = "cajado_do_teleporte";
    public static final String CAJADO_SOMBRAS_ID = "cajado_das_sombras";
    public static final String CAJADO_THOR_ID = "cajado_do_thor";
    public static final List<String> STAFF_COMMAND_NAMES = List.of(
            CAJADO_FOGO_ID,
            CAJADO_GLACIAL_ID,
            CAJADO_CURA_ID,
            CAJADO_GRAVIDADE_ID,
            CAJADO_TELEPORTE_ID,
            CAJADO_SOMBRAS_ID,
            CAJADO_THOR_ID
    );

    private StaffManager() {
    }

    public static List<ItemStack> createAllStaffs() {
        return List.of(
                createCajadoFogo(),
                createCajadoGlacial(),
                createCajadoCura(),
                createCajadoGravidade(),
                createCajadoTeleporte(),
                createCajadoSombras(),
                createCajadoThor()
        );
    }

    public static ItemStack createCajadoFogo() {
        ItemStack stack = new ItemStack(Items.BLAZE_ROD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_FOGO_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText fireName = Text.literal("Cajado ").styled(style -> style.withColor(0xFFAA00).withItalic(false))
                .append(Text.literal("de ").styled(style -> style.withColor(0xFF7700).withItalic(false)))
                .append(Text.literal("Fogo").styled(style -> style.withColor(0xFF3300).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, fireName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(6.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_FOGO_ID)))
        );
        return stack;
    }

    public static ItemStack createCajadoGlacial() {
        ItemStack stack = new ItemStack(Items.PRISMARINE_SHARD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_GLACIAL_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText glacialName = Text.literal("Cajado ").styled(style -> style.withColor(0xBAE6FD).withItalic(false))
                .append(Text.literal("Glacial").styled(style -> style.withColor(0x38BDF8).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, glacialName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(2.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_GLACIAL_ID + "_projetil")))
        );
        return stack;
    }

    public static ItemStack createCajadoCura() {
        ItemStack stack = new ItemStack(Items.HEART_OF_THE_SEA, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_CURA_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText healName = Text.literal("Cajado ").styled(style -> style.withColor(0x86EFAC).withItalic(false))
                .append(Text.literal("da ").styled(style -> style.withColor(0x4ADE80).withItalic(false)))
                .append(Text.literal("Cura").styled(style -> style.withColor(0x22C55E).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, healName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(5.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_CURA_ID + "_instantanea")))
        );
        return stack;
    }

    public static ItemStack createCajadoGravidade() {
        ItemStack stack = new ItemStack(Items.ECHO_SHARD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_GRAVIDADE_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText gravityName = Text.literal("Cajado ").styled(style -> style.withColor(0xD8B4FE).withItalic(false))
                .append(Text.literal("da ").styled(style -> style.withColor(0xC084FC).withItalic(false)))
                .append(Text.literal("Gravidade").styled(style -> style.withColor(0xA855F7).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, gravityName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(5.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_GRAVIDADE_ID + "_meteoro")))
        );
        return stack;
    }

    public static ItemStack createCajadoTeleporte() {
        ItemStack stack = new ItemStack(Items.ENDER_PEARL, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_TELEPORTE_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText teleportName = Text.literal("Cajado ").styled(style -> style.withColor(0xE9D5FF).withItalic(false))
                .append(Text.literal("do ").styled(style -> style.withColor(0xC084FC).withItalic(false)))
                .append(Text.literal("Teleporte").styled(style -> style.withColor(0x9333EA).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, teleportName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(3.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_TELEPORTE_ID + "_salto")))
        );
        return stack;
    }

    public static ItemStack createCajadoSombras() {
        ItemStack stack = new ItemStack(Items.AMETHYST_SHARD, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_SOMBRAS_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText shadowName = Text.literal("Cajado ").styled(style -> style.withColor(0x9333EA).withItalic(false))
                .append(Text.literal("das ").styled(style -> style.withColor(0x7E22CE).withItalic(false)))
                .append(Text.literal("Sombras").styled(style -> style.withColor(0x581C87).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, shadowName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(3.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_SOMBRAS_ID + "_teleporte")))
        );
        return stack;
    }

    public static ItemStack createCajadoThor() {
        ItemStack stack = new ItemStack(Items.MACE, 1);
        NbtCompound nbt = new NbtCompound();
        nbt.putString(STAFF_NBT_KEY, CAJADO_THOR_ID);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        MutableText thorName = Text.literal("⚡ ").styled(style -> style.withColor(0xFACC15).withItalic(false))
                .append(Text.literal("Cajado ").styled(style -> style.withColor(0x38BDF8).withItalic(false)))
                .append(Text.literal("do ").styled(style -> style.withColor(0x7DD3FC).withItalic(false)))
                .append(Text.literal("Thor").styled(style -> style.withColor(0xFACC15).withItalic(false)));
        stack.set(DataComponentTypes.CUSTOM_NAME, thorName);

        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        stack.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        stack.set(
                DataComponentTypes.USE_COOLDOWN,
                new UseCooldownComponent(1.0F, Optional.of(Identifier.of(CajadosMagicosMod.MOD_ID, CAJADO_THOR_ID + "_projetil")))
        );
        return stack;
    }

    private static boolean isStaff(ItemStack stack, Item expectedItem, String expectedId) {
        if (stack == null || stack.isEmpty() || !stack.isOf(expectedItem)) {
            return false;
        }
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) {
            return false;
        }
        return expectedId.equals(customData.copyNbt().getString(STAFF_NBT_KEY));
    }

    public static boolean isCajadoFogo(ItemStack stack) {
        return isStaff(stack, Items.BLAZE_ROD, CAJADO_FOGO_ID);
    }

    public static boolean isCajadoGlacial(ItemStack stack) {
        return isStaff(stack, Items.PRISMARINE_SHARD, CAJADO_GLACIAL_ID);
    }

    public static boolean isCajadoCura(ItemStack stack) {
        return isStaff(stack, Items.HEART_OF_THE_SEA, CAJADO_CURA_ID);
    }

    public static boolean isCajadoGravidade(ItemStack stack) {
        return isStaff(stack, Items.ECHO_SHARD, CAJADO_GRAVIDADE_ID);
    }

    public static boolean isCajadoTeleporte(ItemStack stack) {
        return isStaff(stack, Items.ENDER_PEARL, CAJADO_TELEPORTE_ID);
    }

    public static boolean isCajadoSombras(ItemStack stack) {
        return isStaff(stack, Items.AMETHYST_SHARD, CAJADO_SOMBRAS_ID);
    }

    public static boolean isCajadoThor(ItemStack stack) {
        return isStaff(stack, Items.MACE, CAJADO_THOR_ID);
    }

    public static boolean hasCajadoFogo(PlayerEntity player) {
        return hasStaffInInventory(player, Items.BLAZE_ROD, CAJADO_FOGO_ID);
    }

    public static boolean hasCajadoGlacial(PlayerEntity player) {
        return hasStaffInInventory(player, Items.PRISMARINE_SHARD, CAJADO_GLACIAL_ID);
    }

    public static boolean hasCajadoCura(PlayerEntity player) {
        return hasStaffInInventory(player, Items.HEART_OF_THE_SEA, CAJADO_CURA_ID);
    }

    public static boolean hasCajadoGravidade(PlayerEntity player) {
        return hasStaffInInventory(player, Items.ECHO_SHARD, CAJADO_GRAVIDADE_ID);
    }

    public static boolean hasCajadoTeleporte(PlayerEntity player) {
        return hasStaffInInventory(player, Items.ENDER_PEARL, CAJADO_TELEPORTE_ID);
    }

    public static boolean hasCajadoSombras(PlayerEntity player) {
        return hasStaffInInventory(player, Items.AMETHYST_SHARD, CAJADO_SOMBRAS_ID);
    }

    public static boolean hasCajadoThor(PlayerEntity player) {
        return hasStaffInInventory(player, Items.MACE, CAJADO_THOR_ID);
    }

    public static boolean hasAnyFreeFlightStaff(PlayerEntity player) {
        return hasCajadoGravidade(player) || hasCajadoSombras(player) || hasCajadoThor(player);
    }

    public static boolean isHoldingCajadoGlacial(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        return isCajadoGlacial(player.getMainHandStack()) || isCajadoGlacial(player.getOffHandStack());
    }

    private static boolean hasStaffInInventory(PlayerEntity player, Item expectedItem, String expectedId) {
        if (player == null) {
            return false;
        }
        if (isStaff(player.getMainHandStack(), expectedItem, expectedId)
                || isStaff(player.getOffHandStack(), expectedItem, expectedId)) {
            return true;
        }
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            if (isStaff(inventory.getStack(i), expectedItem, expectedId)) {
                return true;
            }
        }
        if (player.currentScreenHandler != null
                && isStaff(player.currentScreenHandler.getCursorStack(), expectedItem, expectedId)) {
            return true;
        }
        return false;
    }

    @Nullable
    public static ItemStack createStaffByName(String rawName) {
        if (rawName == null || rawName.isBlank()) {
            return null;
        }
        String decomposed = Normalizer.normalize(rawName.trim().toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        StringBuilder sb = new StringBuilder(decomposed.length());
        boolean lastWasSep = false;
        for (int i = 0; i < decomposed.length(); i++) {
            char c = decomposed.charAt(i);
            if (Character.getType(c) == Character.NON_SPACING_MARK) {
                continue;
            }
            if (Character.isWhitespace(c) || c == '-' || c == '_') {
                if (!lastWasSep && sb.length() > 0) {
                    sb.append('_');
                    lastWasSep = true;
                }
            } else {
                sb.append(c);
                lastWasSep = false;
            }
        }
        String normalized = sb.toString();
        if (normalized.endsWith("_")) {
            normalized = normalized.substring(0, normalized.length() - 1);
        }

        return switch (normalized) {
            case CAJADO_FOGO_ID, "cajado_fogo", "fogo", "blaze_rod" -> createCajadoFogo();
            case CAJADO_GLACIAL_ID, "glacial", "gelo", "cajado_gelo", "prismarine_shard" -> createCajadoGlacial();
            case CAJADO_CURA_ID, "cajado_cura", "cura", "heart_of_the_sea" -> createCajadoCura();
            case CAJADO_GRAVIDADE_ID, "cajado_gravidade", "gravidade", "echo_shard" -> createCajadoGravidade();
            case CAJADO_TELEPORTE_ID, "cajado_teleporte", "teleporte", "ender_pearl" -> createCajadoTeleporte();
            case CAJADO_SOMBRAS_ID, "cajado_sombras", "sombras", "sombra", "amethyst_shard" -> createCajadoSombras();
            case CAJADO_THOR_ID, "cajado_thor", "thor", "mjolnir", "mace" -> createCajadoThor();
            default -> null;
        };
    }
}
