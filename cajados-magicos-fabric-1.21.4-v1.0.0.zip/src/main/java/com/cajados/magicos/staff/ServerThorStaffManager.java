package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class ServerThorStaffManager {
    public static final String PROJECTILE_TAG = "cajado_do_thor_projetil";

    private static final float PROJECTILE_DAMAGE = 8.0F;
    private static final float PROJECTILE_SPEED = 2.25F;
    private static final long PROJECTILE_COOLDOWN_MS = 1_000L;
    private static final int PROJECTILE_COOLDOWN_TICKS = 20;
    private static final Identifier PROJECTILE_COOLDOWN_GROUP_ID =
            Identifier.of(CajadosMagicosMod.MOD_ID, StaffManager.CAJADO_THOR_ID + "_projetil");

    private static final double DIVINE_BOLT_MAX_DISTANCE = 45.0;
    private static final double DIVINE_BOLT_HIT_RADIUS = 2.6;
    private static final float DIVINE_BOLT_DAMAGE = 12.0F;
    private static final long DIVINE_BOLT_COOLDOWN_MS = 3_000L;

    private static final long WRATH_DURATION_MS = 5_000L;
    private static final long WRATH_COOLDOWN_MS = 20_000L;
    private static final double WRATH_RADIUS = 8.0;
    private static final float WRATH_BOLT_DAMAGE = 6.0F;
    private static final int WRATH_STRIKE_INTERVAL_TICKS = 8;

    private static final long IMPACT_COOLDOWN_MS = 10_000L;
    private static final double IMPACT_RADIUS = 6.0;
    private static final float IMPACT_DAMAGE = 8.0F;
    private static final int IMPACT_RISE_TICKS = 7;
    private static final int IMPACT_MAX_TICKS = 55;
    private static final int IMPACT_FALL_GRACE_TICKS = 15;

    private static final DustParticleEffect ELECTRIC_BLUE_DUST = new DustParticleEffect(0x38BDF8, 1.45F);
    private static final DustParticleEffect GOLD_DUST = new DustParticleEffect(0xFACC15, 1.35F);
    private static final DustParticleEffect WHITE_DUST = new DustParticleEffect(0xF8FAFC, 1.35F);
    private static final DustParticleEffect GRAY_DUST = new DustParticleEffect(0x94A3B8, 1.35F);

    private static final Map<UUID, Long> PROJECTILE_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, Long> DIVINE_BOLT_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, Long> WRATH_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, Long> IMPACT_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, WrathStorm> ACTIVE_WRATHS = new HashMap<>();
    private static final Map<UUID, ImpactState> ACTIVE_IMPACTS = new HashMap<>();
    private static final Map<UUID, Long> IMPACT_FALL_IMMUNE_UNTIL_TICK = new HashMap<>();
    private static final Set<UUID> FLIGHT_GRANTED_PLAYERS = new HashSet<>();
    private static final Map<UUID, Vec3d> LAST_POSITIONS = new HashMap<>();
    private static final Map<UUID, Long> LAST_RIGHT_CLICK_TICK = new HashMap<>();
    private static long serverTickCounter = 0L;

    private static final class WrathStorm {
        final long endTimeMs;
        int tickCount;

        WrathStorm(long endTimeMs) {
            this.endTimeMs = endTimeMs;
            this.tickCount = 0;
        }
    }

    private static final class ImpactState {
        final Vec3d horizDir;
        boolean slamming;
        int ticks;

        ImpactState(Vec3d horizDir) {
            this.horizDir = horizDir;
            this.slamming = false;
            this.ticks = 0;
        }
    }

    private ServerThorStaffManager() {
    }

    public static void markRightClick(UUID playerUuid) {
        if (playerUuid != null) {
            LAST_RIGHT_CLICK_TICK.put(playerUuid, serverTickCounter);
        }
    }

    public static boolean isPerformingDivineImpact(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        UUID uuid = player.getUuid();
        if (ACTIVE_IMPACTS.containsKey(uuid)) {
            return true;
        }
        Long graceUntil = IMPACT_FALL_IMMUNE_UNTIL_TICK.get(uuid);
        return graceUntil != null && serverTickCounter <= graceUntil;
    }

    public static boolean tryUseThorStaff(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        if (player.isSneaking()) {
            return tryActivateDivineImpact(player);
        }
        return tryCastElectricProjectile(player);
    }

    public static void tryHandleLeftClickSwing(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return;
        }
        if (!StaffManager.isCajadoThor(player.getMainHandStack())) {
            return;
        }
        Long lastRightClick = LAST_RIGHT_CLICK_TICK.get(player.getUuid());
        if (lastRightClick != null && (serverTickCounter - lastRightClick) <= 3L) {
            return;
        }

        if (player.isSneaking()) {
            tryActivateThorWrath(player);
        } else {
            tryCastDivineBolt(player);
        }
    }

    public static boolean tryCastElectricProjectile(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = PROJECTILE_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            int remainingTicks = Math.min(
                    PROJECTILE_COOLDOWN_TICKS,
                    Math.max(1, (int) Math.ceil((until - now) / 50.0))
            );
            player.getItemCooldownManager().set(PROJECTILE_COOLDOWN_GROUP_ID, remainingTicks);
            return false;
        }

        PROJECTILE_COOLDOWN_UNTIL_MS.put(uuid, now + PROJECTILE_COOLDOWN_MS);
        player.getItemCooldownManager().set(PROJECTILE_COOLDOWN_GROUP_ID, PROJECTILE_COOLDOWN_TICKS);

        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d spawnPos = player.getEyePos().add(look.multiply(0.95));

        SnowballEntity projectile = new SnowballEntity(world, player, new ItemStack(Items.PRISMARINE_CRYSTALS));
        projectile.setPosition(spawnPos.x, spawnPos.y, spawnPos.z);
        projectile.setNoGravity(true);
        projectile.setVelocity(look.x, look.y, look.z, PROJECTILE_SPEED, 0.0F);
        projectile.addCommandTag(PROJECTILE_TAG);
        world.spawnEntity(projectile);

        world.spawnParticles(ELECTRIC_BLUE_DUST, spawnPos.x, spawnPos.y, spawnPos.z, 8, 0.16, 0.16, 0.16, 0.03);
        world.spawnParticles(WHITE_DUST, spawnPos.x, spawnPos.y, spawnPos.z, 5, 0.12, 0.12, 0.12, 0.02);
        world.spawnParticles(GRAY_DUST, spawnPos.x, spawnPos.y, spawnPos.z, 4, 0.12, 0.12, 0.12, 0.02);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, spawnPos.x, spawnPos.y, spawnPos.z, 8, 0.14, 0.14, 0.14, 0.06);
        world.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENTITY_BREEZE_SHOOT,
                SoundCategory.PLAYERS,
                0.75F,
                1.55F
        );
        return true;
    }

    public static void handleProjectileCollision(SnowballEntity snowball, HitResult hitResult) {
        if (!(snowball.getWorld() instanceof ServerWorld world)) {
            return;
        }

        if (hitResult.getType() == HitResult.Type.ENTITY && hitResult instanceof EntityHitResult entityHit) {
            Entity target = entityHit.getEntity();
            Entity owner = snowball.getOwner();
            if (target != owner && target instanceof LivingEntity living && living.isAlive()) {
                target.damage(world, world.getDamageSources().lightningBolt(), PROJECTILE_DAMAGE);
            }
        }

        Vec3d pos = snowball.getPos();
        world.spawnParticles(ELECTRIC_BLUE_DUST, pos.x, pos.y, pos.z, 22, 0.4, 0.4, 0.4, 0.05);
        world.spawnParticles(WHITE_DUST, pos.x, pos.y, pos.z, 16, 0.35, 0.35, 0.35, 0.05);
        world.spawnParticles(GRAY_DUST, pos.x, pos.y, pos.z, 14, 0.35, 0.35, 0.35, 0.04);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 26, 0.42, 0.42, 0.42, 0.12);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT,
                SoundCategory.PLAYERS,
                0.85F,
                1.45F
        );
        snowball.discard();
    }

    public static boolean tryCastDivineBolt(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = DIVINE_BOLT_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            double remainingSec = Math.max(0.1, (until - now) / 1000.0);
            player.sendMessage(
                    Text.literal(String.format("Raio Divino em recarga (%.1fs).", remainingSec))
                            .formatted(Formatting.AQUA),
                    true
            );
            return false;
        }

        DIVINE_BOLT_COOLDOWN_UNTIL_MS.put(uuid, now + DIVINE_BOLT_COOLDOWN_MS);

        ServerWorld world = player.getServerWorld();
        Vec3d eyePos = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d maxEnd = eyePos.add(look.multiply(DIVINE_BOLT_MAX_DISTANCE));

        BlockHitResult blockHit = world.raycast(new RaycastContext(
                eyePos,
                maxEnd,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                player
        ));
        double maxEntityDistSq = blockHit.getType() != HitResult.Type.MISS
                ? blockHit.getPos().squaredDistanceTo(eyePos)
                : DIVINE_BOLT_MAX_DISTANCE * DIVINE_BOLT_MAX_DISTANCE;

        EntityHitResult entityHit = ProjectileUtil.raycast(
                player,
                eyePos,
                maxEnd,
                player.getBoundingBox().stretch(look.multiply(DIVINE_BOLT_MAX_DISTANCE)).expand(1.1),
                target -> target.isAlive()
                        && !target.isSpectator()
                        && target.canHit()
                        && target != player,
                maxEntityDistSq
        );

        Vec3d strikePos;
        Entity directTarget = null;
        if (entityHit != null) {
            directTarget = entityHit.getEntity();
            strikePos = directTarget.getPos();
        } else if (blockHit.getType() != HitResult.Type.MISS) {
            strikePos = blockHit.getPos();
        } else {
            Vec3d farPoint = eyePos.add(look.multiply(30.0));
            BlockHitResult groundCheck = world.raycast(new RaycastContext(
                    farPoint,
                    farPoint.add(0.0, -24.0, 0.0),
                    RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE,
                    player
            ));
            strikePos = groundCheck.getType() != HitResult.Type.MISS ? groundCheck.getPos() : farPoint;
        }

        spawnCosmeticLightning(world, strikePos);

        if (directTarget != null && directTarget instanceof LivingEntity living && living.isAlive()) {
            directTarget.damage(world, world.getDamageSources().lightningBolt(), DIVINE_BOLT_DAMAGE);
        }

        Box strikeBox = Box.of(
                strikePos.add(0.0, 1.0, 0.0),
                DIVINE_BOLT_HIT_RADIUS * 2.0,
                4.0,
                DIVINE_BOLT_HIT_RADIUS * 2.0
        );
        List<Entity> nearby = world.getOtherEntities(
                player,
                strikeBox,
                entity -> entity.isAlive()
                        && !entity.isSpectator()
                        && entity instanceof LivingEntity
                        && entity != directTarget
        );
        double maxDistSq = DIVINE_BOLT_HIT_RADIUS * DIVINE_BOLT_HIT_RADIUS;
        for (Entity entity : nearby) {
            if (entity.getPos().squaredDistanceTo(strikePos) <= maxDistSq) {
                entity.damage(world, world.getDamageSources().lightningBolt(), DIVINE_BOLT_DAMAGE);
            }
        }

        world.spawnParticles(ELECTRIC_BLUE_DUST, strikePos.x, strikePos.y + 0.6, strikePos.z, 26, 0.6, 0.85, 0.6, 0.06);
        world.spawnParticles(WHITE_DUST, strikePos.x, strikePos.y + 0.6, strikePos.z, 20, 0.55, 0.8, 0.55, 0.06);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, strikePos.x, strikePos.y + 0.8, strikePos.z, 34, 0.7, 0.95, 0.7, 0.14);

        world.playSound(
                null,
                strikePos.x,
                strikePos.y,
                strikePos.z,
                SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                SoundCategory.WEATHER,
                1.35F,
                1.05F
        );
        world.playSound(
                null,
                strikePos.x,
                strikePos.y,
                strikePos.z,
                SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT,
                SoundCategory.WEATHER,
                1.1F,
                1.15F
        );
        return true;
    }

    public static boolean tryActivateThorWrath(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long cdUntil = WRATH_COOLDOWN_UNTIL_MS.get(uuid);
        if (cdUntil != null && cdUntil > now) {
            double remainingSec = Math.max(0.1, (cdUntil - now) / 1000.0);
            player.sendMessage(
                    Text.literal(String.format("Ira de Thor em recarga (%.1fs).", remainingSec))
                            .formatted(Formatting.AQUA),
                    true
            );
            return false;
        }

        WRATH_COOLDOWN_UNTIL_MS.put(uuid, now + WRATH_COOLDOWN_MS);
        ACTIVE_WRATHS.put(uuid, new WrathStorm(now + WRATH_DURATION_MS));

        ServerWorld world = player.getServerWorld();
        Vec3d pos = player.getPos();
        world.spawnParticles(ELECTRIC_BLUE_DUST, pos.x, pos.y + 1.4, pos.z, 28, 2.5, 1.0, 2.5, 0.05);
        world.spawnParticles(WHITE_DUST, pos.x, pos.y + 1.4, pos.z, 18, 2.5, 1.0, 2.5, 0.05);
        world.spawnParticles(GRAY_DUST, pos.x, pos.y + 2.4, pos.z, 22, 3.0, 0.8, 3.0, 0.04);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                SoundCategory.PLAYERS,
                1.4F,
                0.85F
        );
        player.sendMessage(
                Text.literal("Ira de Thor ativada (5s)!")
                        .formatted(Formatting.GOLD),
                true
        );
        return true;
    }

    public static boolean tryActivateDivineImpact(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long cdUntil = IMPACT_COOLDOWN_UNTIL_MS.get(uuid);
        if (cdUntil != null && cdUntil > now) {
            double remainingSec = Math.max(0.1, (cdUntil - now) / 1000.0);
            player.sendMessage(
                    Text.literal(String.format("Impacto Divino em recarga (%.1fs).", remainingSec))
                            .formatted(Formatting.GOLD),
                    true
            );
            return false;
        }

        IMPACT_COOLDOWN_UNTIL_MS.put(uuid, now + IMPACT_COOLDOWN_MS);
        IMPACT_FALL_IMMUNE_UNTIL_TICK.put(uuid, serverTickCounter + IMPACT_MAX_TICKS + IMPACT_FALL_GRACE_TICKS);

        if (player.getAbilities().flying) {
            player.getAbilities().flying = false;
            player.sendAbilitiesUpdate();
        }

        Vec3d look = player.getRotationVec(1.0F);
        Vec3d horiz = new Vec3d(look.x, 0.0, look.z);
        Vec3d horizDir = horiz.lengthSquared() > 1.0E-4 ? horiz.normalize() : Vec3d.ZERO;

        ACTIVE_IMPACTS.put(uuid, new ImpactState(horizDir));
        player.fallDistance = 0.0F;
        player.setVelocity(horizDir.x * 0.45, 1.32, horizDir.z * 0.45);
        player.velocityModified = true;

        ServerWorld world = player.getServerWorld();
        Vec3d pos = player.getPos();
        world.spawnParticles(ELECTRIC_BLUE_DUST, pos.x, pos.y + 0.4, pos.z, 20, 0.5, 0.3, 0.5, 0.04);
        world.spawnParticles(WHITE_DUST, pos.x, pos.y + 0.4, pos.z, 14, 0.45, 0.3, 0.45, 0.04);
        world.spawnParticles(GRAY_DUST, pos.x, pos.y + 0.4, pos.z, 12, 0.45, 0.3, 0.45, 0.03);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 0.5, pos.z, 24, 0.5, 0.4, 0.5, 0.14);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.ITEM_MACE_SMASH_AIR,
                SoundCategory.PLAYERS,
                1.0F,
                1.1F
        );
        return true;
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();

        Long projUntil = PROJECTILE_COOLDOWN_UNTIL_MS.get(uuid);
        if (projUntil != null) {
            long remainingMs = projUntil - now;
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(
                        PROJECTILE_COOLDOWN_TICKS,
                        Math.max(1, (int) Math.ceil(remainingMs / 50.0))
                );
                player.getItemCooldownManager().set(PROJECTILE_COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                PROJECTILE_COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }

        if (!player.isCreative() && !player.isSpectator()) {
            if (player.isAlive() && StaffManager.hasCajadoThor(player)) {
                player.getAbilities().allowFlying = true;
                player.sendAbilitiesUpdate();
                FLIGHT_GRANTED_PLAYERS.add(uuid);
            } else if (player.getAbilities().allowFlying
                    && !StaffManager.hasCajadoGravidade(player)
                    && !StaffManager.hasCajadoSombras(player)
                    && !ServerFireStaffManager.canFlyWithFireStaff(player)) {
                player.getAbilities().allowFlying = false;
                player.getAbilities().flying = false;
                player.sendAbilitiesUpdate();
            }
        }
    }

    public static void onDisconnect(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        ACTIVE_WRATHS.remove(uuid);
        ACTIVE_IMPACTS.remove(uuid);
        IMPACT_FALL_IMMUNE_UNTIL_TICK.remove(uuid);
        FLIGHT_GRANTED_PLAYERS.remove(uuid);
        LAST_POSITIONS.remove(uuid);
        LAST_RIGHT_CLICK_TICK.remove(uuid);
    }

    public static void tick(MinecraftServer server) {
        serverTickCounter++;
        long now = System.currentTimeMillis();

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            Vec3d currentPos = player.getPos();
            Vec3d prevPos = LAST_POSITIONS.put(uuid, currentPos);

            tickDivineImpactForPlayer(player, currentPos);

            Long graceUntil = IMPACT_FALL_IMMUNE_UNTIL_TICK.get(uuid);
            if (graceUntil != null) {
                if (serverTickCounter <= graceUntil) {
                    player.fallDistance = 0.0F;
                } else {
                    IMPACT_FALL_IMMUNE_UNTIL_TICK.remove(uuid);
                }
            }

            if (player.isCreative() || player.isSpectator()) {
                FLIGHT_GRANTED_PLAYERS.remove(uuid);
                continue;
            }

            boolean hasStaff = player.isAlive() && StaffManager.hasCajadoThor(player);
            if (hasStaff) {
                if (!player.getAbilities().allowFlying || !FLIGHT_GRANTED_PLAYERS.contains(uuid)) {
                    player.getAbilities().allowFlying = true;
                    player.sendAbilitiesUpdate();
                    FLIGHT_GRANTED_PLAYERS.add(uuid);
                }
                if (player.getAbilities().flying && !ACTIVE_IMPACTS.containsKey(uuid)) {
                    spawnMovingThorFlightParticles(player, currentPos, prevPos);
                }
            } else if (FLIGHT_GRANTED_PLAYERS.remove(uuid)) {
                if (!StaffManager.hasCajadoGravidade(player)
                        && !StaffManager.hasCajadoSombras(player)
                        && !ServerFireStaffManager.canFlyWithFireStaff(player)) {
                    player.getAbilities().allowFlying = false;
                    player.getAbilities().flying = false;
                    player.sendAbilitiesUpdate();
                }
            }
        }

        tickWrathStorms(server, now);
    }

    private static void tickDivineImpactForPlayer(ServerPlayerEntity player, Vec3d currentPos) {
        UUID uuid = player.getUuid();
        ImpactState state = ACTIVE_IMPACTS.get(uuid);
        if (state == null) {
            return;
        }
        if (!player.isAlive() || player.isSpectator()) {
            ACTIVE_IMPACTS.remove(uuid);
            return;
        }

        state.ticks++;
        player.fallDistance = 0.0F;
        if (player.getAbilities().flying) {
            player.getAbilities().flying = false;
            player.sendAbilitiesUpdate();
        }

        ServerWorld world = player.getServerWorld();
        if (!state.slamming) {
            world.spawnParticles(ELECTRIC_BLUE_DUST, currentPos.x, currentPos.y + 0.7, currentPos.z, 5, 0.35, 0.4, 0.35, 0.02);
            world.spawnParticles(WHITE_DUST, currentPos.x, currentPos.y + 0.7, currentPos.z, 3, 0.3, 0.35, 0.3, 0.02);
            world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, currentPos.x, currentPos.y + 0.8, currentPos.z, 4, 0.35, 0.35, 0.35, 0.08);
            if (state.ticks >= IMPACT_RISE_TICKS) {
                state.slamming = true;
                player.setVelocity(state.horizDir.x * 0.5, -1.9, state.horizDir.z * 0.5);
                player.velocityModified = true;
            }
            return;
        }

        if ((state.ticks >= IMPACT_RISE_TICKS + 2 && (player.isOnGround() || player.isTouchingWater()))
                || state.ticks >= IMPACT_MAX_TICKS) {
            ACTIVE_IMPACTS.remove(uuid);
            IMPACT_FALL_IMMUNE_UNTIL_TICK.put(uuid, serverTickCounter + IMPACT_FALL_GRACE_TICKS);
            triggerDivineImpactShockwave(player, currentPos);
            return;
        }

        player.setVelocity(state.horizDir.x * 0.45, -1.9, state.horizDir.z * 0.45);
        player.velocityModified = true;
        world.spawnParticles(ELECTRIC_BLUE_DUST, currentPos.x, currentPos.y + 0.9, currentPos.z, 7, 0.35, 0.45, 0.35, 0.03);
        world.spawnParticles(WHITE_DUST, currentPos.x, currentPos.y + 0.9, currentPos.z, 5, 0.3, 0.4, 0.3, 0.03);
        world.spawnParticles(GRAY_DUST, currentPos.x, currentPos.y + 0.9, currentPos.z, 4, 0.3, 0.4, 0.3, 0.02);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, currentPos.x, currentPos.y + 0.8, currentPos.z, 8, 0.4, 0.4, 0.4, 0.12);
    }

    private static void triggerDivineImpactShockwave(ServerPlayerEntity player, Vec3d impactPos) {
        ServerWorld world = player.getServerWorld();
        Box area = Box.of(impactPos.add(0.0, 1.0, 0.0), IMPACT_RADIUS * 2.0, 6.0, IMPACT_RADIUS * 2.0);
        List<Entity> targets = world.getOtherEntities(
                player,
                area,
                entity -> entity.isAlive()
                        && !entity.isSpectator()
                        && entity instanceof LivingEntity
        );

        double maxDistSq = IMPACT_RADIUS * IMPACT_RADIUS;
        for (Entity entity : targets) {
            Vec3d targetPos = entity.getPos().add(0.0, entity.getHeight() * 0.4, 0.0);
            double distSq = targetPos.squaredDistanceTo(impactPos);
            if (distSq > maxDistSq) {
                continue;
            }
            entity.damage(world, world.getDamageSources().lightningBolt(), IMPACT_DAMAGE);
            Vec3d delta = targetPos.subtract(impactPos);
            Vec3d horiz = new Vec3d(delta.x, 0.0, delta.z);
            Vec3d dir = horiz.lengthSquared() > 1.0E-4 ? horiz.normalize() : new Vec3d(0.0, 0.0, 1.0);
            double falloff = 1.0 - Math.min(0.6, Math.sqrt(distSq) / (IMPACT_RADIUS * 1.4));
            double strength = 1.45 * falloff;
            entity.addVelocity(dir.x * strength, 0.58, dir.z * strength);
            entity.velocityModified = true;
        }

        world.spawnParticles(ELECTRIC_BLUE_DUST, impactPos.x, impactPos.y + 0.35, impactPos.z, 40, 2.2, 0.45, 2.2, 0.06);
        world.spawnParticles(WHITE_DUST, impactPos.x, impactPos.y + 0.35, impactPos.z, 30, 2.0, 0.4, 2.0, 0.06);
        world.spawnParticles(GRAY_DUST, impactPos.x, impactPos.y + 0.35, impactPos.z, 26, 2.2, 0.4, 2.2, 0.05);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, impactPos.x, impactPos.y + 0.5, impactPos.z, 55, 2.4, 0.6, 2.4, 0.16);

        for (double ringRadius : new double[]{2.5, 4.2, IMPACT_RADIUS}) {
            int points = (int) Math.round(ringRadius * 7.0);
            for (int i = 0; i < points; i++) {
                double angle = (Math.PI * 2.0 * i) / points;
                double rx = impactPos.x + Math.cos(angle) * ringRadius;
                double rz = impactPos.z + Math.sin(angle) * ringRadius;
                DustParticleEffect dust = (i % 3 == 0) ? WHITE_DUST : (i % 3 == 1 ? ELECTRIC_BLUE_DUST : GRAY_DUST);
                world.spawnParticles(dust, rx, impactPos.y + 0.2, rz, 1, 0.08, 0.08, 0.08, 0.01);
            }
        }

        world.playSound(
                null,
                impactPos.x,
                impactPos.y,
                impactPos.z,
                SoundEvents.ITEM_MACE_SMASH_GROUND_HEAVY,
                SoundCategory.PLAYERS,
                1.35F,
                0.95F
        );
        world.playSound(
                null,
                impactPos.x,
                impactPos.y,
                impactPos.z,
                SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT,
                SoundCategory.PLAYERS,
                1.1F,
                1.1F
        );
    }

    private static void tickWrathStorms(MinecraftServer server, long now) {
        if (ACTIVE_WRATHS.isEmpty()) {
            return;
        }

        ThreadLocalRandom random = ThreadLocalRandom.current();
        Iterator<Map.Entry<UUID, WrathStorm>> iterator = ACTIVE_WRATHS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, WrathStorm> entry = iterator.next();
            UUID ownerUuid = entry.getKey();
            WrathStorm storm = entry.getValue();
            ServerPlayerEntity owner = server.getPlayerManager().getPlayer(ownerUuid);
            if (owner == null || !owner.isAlive() || owner.isSpectator() || now >= storm.endTimeMs) {
                iterator.remove();
                continue;
            }

            ServerWorld world = owner.getServerWorld();
            Vec3d center = owner.getPos();
            int currentTick = storm.tickCount++;

            if (currentTick % 2 == 0) {
                for (int i = 0; i < 6; i++) {
                    double angle = random.nextDouble() * Math.PI * 2.0;
                    double r = 1.5 + random.nextDouble() * (WRATH_RADIUS - 1.5);
                    double px = center.x + Math.cos(angle) * r;
                    double pz = center.z + Math.sin(angle) * r;
                    double py = center.y + 0.4 + random.nextDouble() * 3.4;
                    DustParticleEffect dust = (i % 3 == 0) ? ELECTRIC_BLUE_DUST : (i % 3 == 1 ? WHITE_DUST : GRAY_DUST);
                    world.spawnParticles(dust, px, py, pz, 1, 0.25, 0.25, 0.25, 0.02);
                }
                world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y + 2.4, center.z, 8, 3.4, 0.8, 3.4, 0.08);
            }

            if (currentTick % WRATH_STRIKE_INTERVAL_TICKS == 0) {
                Box area = Box.of(center.add(0.0, 1.0, 0.0), WRATH_RADIUS * 2.0, 10.0, WRATH_RADIUS * 2.0);
                double maxDistSq = WRATH_RADIUS * WRATH_RADIUS;
                List<LivingEntity> enemies = new ArrayList<>();
                for (Entity entity : world.getOtherEntities(
                        owner,
                        area,
                        target -> isEnemy(owner, target)
                )) {
                    if (entity instanceof LivingEntity living
                            && entity.getPos().squaredDistanceTo(center) <= maxDistSq) {
                        enemies.add(living);
                    }
                }

                if (!enemies.isEmpty()) {
                    LivingEntity picked = enemies.get(random.nextInt(enemies.size()));
                    Vec3d strikePos = picked.getPos();
                    spawnCosmeticLightning(world, strikePos);
                    picked.damage(world, world.getDamageSources().lightningBolt(), WRATH_BOLT_DAMAGE);
                    world.spawnParticles(ELECTRIC_BLUE_DUST, strikePos.x, strikePos.y + 0.6, strikePos.z, 16, 0.45, 0.65, 0.45, 0.04);
                    world.spawnParticles(WHITE_DUST, strikePos.x, strikePos.y + 0.6, strikePos.z, 12, 0.4, 0.6, 0.4, 0.04);
                    world.spawnParticles(GRAY_DUST, strikePos.x, strikePos.y + 0.6, strikePos.z, 10, 0.4, 0.6, 0.4, 0.03);
                    world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, strikePos.x, strikePos.y + 0.8, strikePos.z, 20, 0.5, 0.7, 0.5, 0.1);
                    world.playSound(
                            null,
                            strikePos.x,
                            strikePos.y,
                            strikePos.z,
                            SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                            SoundCategory.WEATHER,
                            0.9F,
                            1.15F
                    );
                } else if (currentTick % (WRATH_STRIKE_INTERVAL_TICKS * 2) == 0) {
                    double angle = random.nextDouble() * Math.PI * 2.0;
                    double r = 3.0 + random.nextDouble() * (WRATH_RADIUS - 3.2);
                    Vec3d ambientPos = new Vec3d(
                            center.x + Math.cos(angle) * r,
                            center.y,
                            center.z + Math.sin(angle) * r
                    );
                    spawnCosmeticLightning(world, ambientPos);
                    world.spawnParticles(ELECTRIC_BLUE_DUST, ambientPos.x, ambientPos.y + 0.5, ambientPos.z, 10, 0.4, 0.6, 0.4, 0.03);
                    world.spawnParticles(GRAY_DUST, ambientPos.x, ambientPos.y + 0.5, ambientPos.z, 8, 0.4, 0.6, 0.4, 0.03);
                    world.playSound(
                            null,
                            ambientPos.x,
                            ambientPos.y,
                            ambientPos.z,
                            SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                            SoundCategory.WEATHER,
                            0.75F,
                            1.1F
                    );
                }
            }
        }
    }

    private static void spawnCosmeticLightning(ServerWorld world, Vec3d pos) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world, SpawnReason.TRIGGERED);
        if (bolt != null) {
            bolt.setCosmetic(true);
            bolt.setPosition(pos.x, pos.y, pos.z);
            world.spawnEntity(bolt);
        }
    }

    private static boolean isEnemy(ServerPlayerEntity holder, Entity entity) {
        if (entity == null || entity == holder || !entity.isAlive() || entity.isSpectator()) {
            return false;
        }
        if (entity instanceof ServerPlayerEntity otherPlayer) {
            return !otherPlayer.isCreative();
        }
        if (entity instanceof Monster) {
            return true;
        }
        return entity instanceof MobEntity mob && mob.getTarget() == holder;
    }

    private static void spawnMovingThorFlightParticles(ServerPlayerEntity player, Vec3d currentPos, Vec3d prevPos) {
        Vec3d moveDelta = prevPos != null ? currentPos.subtract(prevPos) : Vec3d.ZERO;
        if (moveDelta.lengthSquared() > 9.0) {
            moveDelta = Vec3d.ZERO;
        }
        ServerWorld world = player.getServerWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        double baseVx = moveDelta.x * 0.85;
        double baseVy = moveDelta.y * 0.85 - 0.03;
        double baseVz = moveDelta.z * 0.85;

        for (int i = 0; i < 3; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.65;
            double py = currentPos.y + 0.05 + random.nextDouble() * 0.85;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.65;
            world.spawnParticles(ELECTRIC_BLUE_DUST, px, py, pz, 1, 0.05, 0.05, 0.05, 0.01);
        }
        for (int i = 0; i < 2; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.6;
            double py = currentPos.y + 0.08 + random.nextDouble() * 0.8;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.6;
            world.spawnParticles(GOLD_DUST, px, py, pz, 1, 0.05, 0.05, 0.05, 0.01);
        }
        for (int i = 0; i < 2; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.55;
            double py = currentPos.y + 0.1 + random.nextDouble() * 0.75;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.55;
            world.spawnParticles(
                    ParticleTypes.ELECTRIC_SPARK,
                    px,
                    py,
                    pz,
                    0,
                    baseVx + (random.nextDouble() - 0.5) * 0.04,
                    baseVy - random.nextDouble() * 0.02,
                    baseVz + (random.nextDouble() - 0.5) * 0.04,
                    1.0
            );
        }
    }

    public static void clearServer() {
        PROJECTILE_COOLDOWN_UNTIL_MS.clear();
        DIVINE_BOLT_COOLDOWN_UNTIL_MS.clear();
        WRATH_COOLDOWN_UNTIL_MS.clear();
        IMPACT_COOLDOWN_UNTIL_MS.clear();
        ACTIVE_WRATHS.clear();
        ACTIVE_IMPACTS.clear();
        IMPACT_FALL_IMMUNE_UNTIL_TICK.clear();
        FLIGHT_GRANTED_PLAYERS.clear();
        LAST_POSITIONS.clear();
        LAST_RIGHT_CLICK_TICK.clear();
        serverTickCounter = 0L;
    }
}
