package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class ServerShadowStaffManager {
    public static final String PROJECTILE_TAG = "cajado_das_sombras_projetil";

    private static final float PROJECTILE_DAMAGE = 6.0F;
    private static final float PROJECTILE_SPEED = 2.15F;
    private static final long PROJECTILE_COOLDOWN_MS = 1_500L;

    private static final double TELEPORT_MAX_DISTANCE = 10.0;
    private static final long TELEPORT_COOLDOWN_MS = 3_000L;
    private static final int TELEPORT_COOLDOWN_TICKS = 60;
    private static final Identifier TELEPORT_COOLDOWN_GROUP_ID =
            Identifier.of(CajadosMagicosMod.MOD_ID, StaffManager.CAJADO_SOMBRAS_ID + "_teleporte");

    private static final long SHADOW_FORM_DURATION_MS = 5_000L;
    private static final long SHADOW_FORM_COOLDOWN_MS = 25_000L;
    private static final int SHADOW_EFFECT_TICKS = 30;
    private static final int SHADOW_SPEED_AMPLIFIER = 3;
    private static final int SHADOW_JUMP_AMPLIFIER = 2;

    private static final DustParticleEffect BLACK_DUST = new DustParticleEffect(0x09090B, 1.5F);
    private static final DustParticleEffect SHROUD_BLACK_DUST = new DustParticleEffect(0x050507, 2.6F);
    private static final DustParticleEffect DARK_PURPLE_DUST = new DustParticleEffect(0x6B21A8, 1.15F);

    private static final Map<UUID, Long> PROJECTILE_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, Long> TELEPORT_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, Long> SHADOW_FORM_COOLDOWN_UNTIL_MS = new HashMap<>();
    private static final Map<UUID, Long> SHADOW_FORM_UNTIL_MS = new HashMap<>();
    private static final Set<UUID> SHADOW_FORM_ACTIVE_PLAYERS = new HashSet<>();
    private static final Set<UUID> FLIGHT_GRANTED_PLAYERS = new HashSet<>();
    private static final Map<UUID, Vec3d> LAST_POSITIONS = new HashMap<>();
    private static final Map<UUID, Long> LAST_RIGHT_CLICK_TICK = new HashMap<>();
    private static long serverTickCounter = 0L;

    private ServerShadowStaffManager() {
    }

    public static void markRightClick(UUID playerUuid) {
        if (playerUuid != null) {
            LAST_RIGHT_CLICK_TICK.put(playerUuid, serverTickCounter);
        }
    }

    public static void tryHandleLeftClickSwing(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return;
        }
        if (!StaffManager.isCajadoSombras(player.getMainHandStack())) {
            return;
        }
        Long lastRightClick = LAST_RIGHT_CLICK_TICK.get(player.getUuid());
        if (lastRightClick != null && (serverTickCounter - lastRightClick) <= 3L) {
            return;
        }

        if (player.isSneaking()) {
            tryActivateShadowForm(player);
        } else {
            tryCastShadowProjectile(player);
        }
    }

    public static boolean tryCastShadowProjectile(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = PROJECTILE_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            double remainingSec = Math.max(0.1, (until - now) / 1000.0);
            player.sendMessage(
                    Text.literal(String.format("Projétil Sombrio em recarga (%.1fs).", remainingSec))
                            .formatted(Formatting.DARK_PURPLE),
                    true
            );
            return false;
        }

        PROJECTILE_COOLDOWN_UNTIL_MS.put(uuid, now + PROJECTILE_COOLDOWN_MS);

        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d spawnPos = player.getEyePos().add(look.multiply(0.95));

        SnowballEntity projectile = new SnowballEntity(world, player, new ItemStack(Items.COAL));
        projectile.setPosition(spawnPos.x, spawnPos.y, spawnPos.z);
        projectile.setNoGravity(true);
        projectile.setVelocity(look.x, look.y, look.z, PROJECTILE_SPEED, 0.0F);
        projectile.addCommandTag(PROJECTILE_TAG);
        world.spawnEntity(projectile);

        world.spawnParticles(BLACK_DUST, spawnPos.x, spawnPos.y, spawnPos.z, 8, 0.14, 0.14, 0.14, 0.02);
        world.spawnParticles(ParticleTypes.SMOKE, spawnPos.x, spawnPos.y, spawnPos.z, 5, 0.1, 0.1, 0.1, 0.02);
        world.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENTITY_WITHER_SHOOT,
                SoundCategory.PLAYERS,
                0.5F,
                1.4F
        );
        return true;
    }

    public static void handleProjectileCollision(SnowballEntity snowball, HitResult hitResult) {
        if (!(snowball.getWorld() instanceof ServerWorld world)) {
            return;
        }

        if (hitResult.getType() == HitResult.Type.ENTITY && hitResult instanceof EntityHitResult entityHit) {
            Entity target = entityHit.getEntity();
            Entity owner = snowball.getOwner();
            if (target != owner && target instanceof LivingEntity living && living.isAlive()) {
                if (owner != null) {
                    target.damage(world, world.getDamageSources().indirectMagic(snowball, owner), PROJECTILE_DAMAGE);
                } else {
                    target.damage(world, world.getDamageSources().magic(), PROJECTILE_DAMAGE);
                }
            }
        }

        Vec3d pos = snowball.getPos();
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y, pos.z, 14, 0.35, 0.35, 0.35, 0.05);
        world.spawnParticles(ParticleTypes.SQUID_INK, pos.x, pos.y, pos.z, 8, 0.25, 0.25, 0.25, 0.04);
        world.spawnParticles(BLACK_DUST, pos.x, pos.y, pos.z, 18, 0.35, 0.35, 0.35, 0.04);
        world.spawnParticles(DARK_PURPLE_DUST, pos.x, pos.y, pos.z, 8, 0.25, 0.25, 0.25, 0.03);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.ENTITY_PHANTOM_BITE,
                SoundCategory.PLAYERS,
                0.7F,
                0.75F
        );
        snowball.discard();
    }

    public static boolean tryCastShadowTeleport(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = TELEPORT_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            return false;
        }

        ServerWorld world = player.getServerWorld();
        Vec3d eyePos = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d maxEnd = eyePos.add(look.multiply(TELEPORT_MAX_DISTANCE));

        BlockHitResult hit = world.raycast(new RaycastContext(
                eyePos,
                maxEnd,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));

        Vec3d candidate;
        if (hit.getType() != HitResult.Type.MISS) {
            Vec3d faceOffset = Vec3d.of(hit.getSide().getVector()).multiply(0.65);
            candidate = hit.getPos().add(faceOffset);
        } else {
            candidate = maxEnd;
        }

        Vec3d safeDest = findSafeTeleportPos(world, candidate, look.multiply(-1.0), player);
        if (safeDest == null) {
            player.sendMessage(
                    Text.literal("Destino obstruído para o Teleporte Sombrio.")
                            .formatted(Formatting.DARK_PURPLE),
                    true
            );
            return false;
        }

        TELEPORT_COOLDOWN_UNTIL_MS.put(uuid, now + TELEPORT_COOLDOWN_MS);
        player.getItemCooldownManager().set(TELEPORT_COOLDOWN_GROUP_ID, TELEPORT_COOLDOWN_TICKS);

        Vec3d departure = player.getPos();
        spawnShadowTeleportCloud(world, departure);

        player.fallDistance = 0.0F;
        player.teleport(world, safeDest.x, safeDest.y, safeDest.z, Set.of(), player.getYaw(), player.getPitch(), false);
        player.setVelocity(Vec3d.ZERO);
        player.velocityModified = true;

        spawnShadowTeleportCloud(world, safeDest);
        world.playSound(
                null,
                safeDest.x,
                safeDest.y,
                safeDest.z,
                SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                SoundCategory.PLAYERS,
                0.9F,
                0.75F
        );
        return true;
    }

    public static boolean tryActivateShadowForm(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long cdUntil = SHADOW_FORM_COOLDOWN_UNTIL_MS.get(uuid);
        if (cdUntil != null && cdUntil > now) {
            double remainingSec = Math.max(0.1, (cdUntil - now) / 1000.0);
            player.sendMessage(
                    Text.literal(String.format("Forma Sombria em recarga (%.1fs).", remainingSec))
                            .formatted(Formatting.DARK_PURPLE),
                    true
            );
            return false;
        }

        SHADOW_FORM_COOLDOWN_UNTIL_MS.put(uuid, now + SHADOW_FORM_COOLDOWN_MS);
        SHADOW_FORM_UNTIL_MS.put(uuid, now + SHADOW_FORM_DURATION_MS);
        SHADOW_FORM_ACTIVE_PLAYERS.add(uuid);

        applyShadowFormEffects(player);
        spawnShadowFormBurst(player.getServerWorld(), player.getPos());
        player.getServerWorld().playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENTITY_WARDEN_SONIC_CHARGE,
                SoundCategory.PLAYERS,
                0.7F,
                0.6F
        );
        player.sendMessage(
                Text.literal("Forma Sombria ativada (5s)!")
                        .formatted(Formatting.DARK_PURPLE),
                true
        );
        return true;
    }

    public static boolean isInShadowForm(PlayerEntity player) {
        if (player == null) {
            return false;
        }
        Long until = SHADOW_FORM_UNTIL_MS.get(player.getUuid());
        return until != null && until > System.currentTimeMillis();
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();

        Long teleportUntil = TELEPORT_COOLDOWN_UNTIL_MS.get(uuid);
        if (teleportUntil != null) {
            long remainingMs = teleportUntil - now;
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(
                        TELEPORT_COOLDOWN_TICKS,
                        Math.max(1, (int) Math.ceil(remainingMs / 50.0))
                );
                player.getItemCooldownManager().set(TELEPORT_COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                TELEPORT_COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }

        if (!player.isCreative() && !player.isSpectator()) {
            if (player.isAlive() && StaffManager.hasCajadoSombras(player)) {
                player.getAbilities().allowFlying = true;
                player.sendAbilitiesUpdate();
                FLIGHT_GRANTED_PLAYERS.add(uuid);
            } else if (player.getAbilities().allowFlying
                    && !StaffManager.hasCajadoGravidade(player)
                    && !StaffManager.hasCajadoThor(player)
                    && !ServerFireStaffManager.canFlyWithFireStaff(player)) {
                player.getAbilities().allowFlying = false;
                player.getAbilities().flying = false;
                player.sendAbilitiesUpdate();
            }
        }
    }

    public static void onDisconnect(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        clearShadowForm(player);
        SHADOW_FORM_UNTIL_MS.remove(uuid);
        FLIGHT_GRANTED_PLAYERS.remove(uuid);
        LAST_POSITIONS.remove(uuid);
        LAST_RIGHT_CLICK_TICK.remove(uuid);
    }

    public static void tick(MinecraftServer server) {
        serverTickCounter++;
        long now = System.currentTimeMillis();

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            Vec3d currentPos = player.getPos();
            Vec3d prevPos = LAST_POSITIONS.put(uuid, currentPos);

            Long shadowUntil = SHADOW_FORM_UNTIL_MS.get(uuid);
            if (shadowUntil != null && shadowUntil > now && player.isAlive() && !player.isSpectator()) {
                SHADOW_FORM_ACTIVE_PLAYERS.add(uuid);
                applyShadowFormEffects(player);
                spawnShadowFormShroud(player, currentPos, prevPos);
            } else {
                if (shadowUntil != null) {
                    SHADOW_FORM_UNTIL_MS.remove(uuid);
                }
                clearShadowForm(player);
            }

            if (player.isCreative() || player.isSpectator()) {
                FLIGHT_GRANTED_PLAYERS.remove(uuid);
                continue;
            }

            boolean hasStaff = player.isAlive() && StaffManager.hasCajadoSombras(player);
            if (hasStaff) {
                if (!player.getAbilities().allowFlying || !FLIGHT_GRANTED_PLAYERS.contains(uuid)) {
                    player.getAbilities().allowFlying = true;
                    player.sendAbilitiesUpdate();
                    FLIGHT_GRANTED_PLAYERS.add(uuid);
                }
                if (player.getAbilities().flying && !SHADOW_FORM_ACTIVE_PLAYERS.contains(uuid)) {
                    spawnMovingShadowFlightParticles(player, currentPos, prevPos);
                }
            } else if (FLIGHT_GRANTED_PLAYERS.remove(uuid)) {
                if (!StaffManager.hasCajadoGravidade(player)
                        && !StaffManager.hasCajadoThor(player)
                        && !ServerFireStaffManager.canFlyWithFireStaff(player)) {
                    player.getAbilities().allowFlying = false;
                    player.getAbilities().flying = false;
                    player.sendAbilitiesUpdate();
                }
            }
        }
    }

    private static void applyShadowFormEffects(ServerPlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.INVISIBILITY,
                SHADOW_EFFECT_TICKS,
                0,
                true,
                false,
                true
        ));
        player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.SPEED,
                SHADOW_EFFECT_TICKS,
                SHADOW_SPEED_AMPLIFIER,
                true,
                false,
                true
        ));
        player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.JUMP_BOOST,
                SHADOW_EFFECT_TICKS,
                SHADOW_JUMP_AMPLIFIER,
                true,
                false,
                true
        ));
    }

    private static void clearShadowForm(ServerPlayerEntity player) {
        if (!SHADOW_FORM_ACTIVE_PLAYERS.remove(player.getUuid())) {
            return;
        }
        StatusEffectInstance invis = player.getStatusEffect(StatusEffects.INVISIBILITY);
        if (invis != null && invis.getAmplifier() == 0 && invis.getDuration() <= SHADOW_EFFECT_TICKS + 5) {
            player.removeStatusEffect(StatusEffects.INVISIBILITY);
        }
        StatusEffectInstance speed = player.getStatusEffect(StatusEffects.SPEED);
        if (speed != null && speed.getAmplifier() == SHADOW_SPEED_AMPLIFIER && speed.getDuration() <= SHADOW_EFFECT_TICKS + 5) {
            player.removeStatusEffect(StatusEffects.SPEED);
        }
        StatusEffectInstance jump = player.getStatusEffect(StatusEffects.JUMP_BOOST);
        if (jump != null && jump.getAmplifier() == SHADOW_JUMP_AMPLIFIER && jump.getDuration() <= SHADOW_EFFECT_TICKS + 5) {
            player.removeStatusEffect(StatusEffects.JUMP_BOOST);
        }
    }

    private static void spawnShadowFormBurst(ServerWorld world, Vec3d pos) {
        world.spawnParticles(SHROUD_BLACK_DUST, pos.x, pos.y + 0.9, pos.z, 26, 0.45, 0.7, 0.45, 0.03);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y + 0.9, pos.z, 18, 0.4, 0.65, 0.4, 0.04);
        world.spawnParticles(ParticleTypes.SQUID_INK, pos.x, pos.y + 0.9, pos.z, 12, 0.35, 0.55, 0.35, 0.03);
    }

    private static void spawnShadowFormShroud(ServerPlayerEntity player, Vec3d currentPos, Vec3d prevPos) {
        Vec3d moveDelta = prevPos != null ? currentPos.subtract(prevPos) : Vec3d.ZERO;
        if (moveDelta.lengthSquared() > 9.0) {
            moveDelta = Vec3d.ZERO;
        }
        ServerWorld world = player.getServerWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        double baseVx = moveDelta.x * 0.8;
        double baseVy = moveDelta.y * 0.8;
        double baseVz = moveDelta.z * 0.8;

        for (int i = 0; i < 16; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.85;
            double py = currentPos.y + 0.1 + random.nextDouble() * 1.75;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.85;
            world.spawnParticles(SHROUD_BLACK_DUST, px, py, pz, 1, 0.08, 0.08, 0.08, 0.0);
        }
        for (int i = 0; i < 6; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.75;
            double py = currentPos.y + 0.15 + random.nextDouble() * 1.65;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.75;
            world.spawnParticles(
                    ParticleTypes.LARGE_SMOKE,
                    px,
                    py,
                    pz,
                    0,
                    baseVx + (random.nextDouble() - 0.5) * 0.03,
                    baseVy + 0.01,
                    baseVz + (random.nextDouble() - 0.5) * 0.03,
                    1.0
            );
        }
        for (int i = 0; i < 4; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.7;
            double py = currentPos.y + 0.2 + random.nextDouble() * 1.5;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.7;
            world.spawnParticles(
                    ParticleTypes.SQUID_INK,
                    px,
                    py,
                    pz,
                    0,
                    baseVx + (random.nextDouble() - 0.5) * 0.03,
                    baseVy,
                    baseVz + (random.nextDouble() - 0.5) * 0.03,
                    1.0
            );
        }
    }

    private static void spawnMovingShadowFlightParticles(ServerPlayerEntity player, Vec3d currentPos, Vec3d prevPos) {
        Vec3d moveDelta = prevPos != null ? currentPos.subtract(prevPos) : Vec3d.ZERO;
        if (moveDelta.lengthSquared() > 9.0) {
            moveDelta = Vec3d.ZERO;
        }
        ServerWorld world = player.getServerWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        double baseVx = moveDelta.x * 0.85;
        double baseVy = moveDelta.y * 0.85 - 0.03;
        double baseVz = moveDelta.z * 0.85;

        for (int i = 0; i < 4; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.65;
            double py = currentPos.y + 0.05 + random.nextDouble() * 0.8;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.65;
            world.spawnParticles(BLACK_DUST, px, py, pz, 1, 0.05, 0.04, 0.05, 0.01);
        }
        for (int i = 0; i < 2; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.55;
            double py = currentPos.y + 0.1 + random.nextDouble() * 0.75;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.55;
            world.spawnParticles(
                    ParticleTypes.SMOKE,
                    px,
                    py,
                    pz,
                    0,
                    baseVx + (random.nextDouble() - 0.5) * 0.03,
                    baseVy - random.nextDouble() * 0.02,
                    baseVz + (random.nextDouble() - 0.5) * 0.03,
                    1.0
            );
        }
        if (serverTickCounter % 2L == 0L) {
            world.spawnParticles(DARK_PURPLE_DUST, currentPos.x, currentPos.y + 0.45, currentPos.z, 2, 0.25, 0.3, 0.25, 0.01);
        }
    }

    private static void spawnShadowTeleportCloud(ServerWorld world, Vec3d pos) {
        world.spawnParticles(BLACK_DUST, pos.x, pos.y + 0.9, pos.z, 26, 0.45, 0.65, 0.45, 0.04);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y + 0.9, pos.z, 18, 0.45, 0.65, 0.45, 0.05);
        world.spawnParticles(ParticleTypes.SQUID_INK, pos.x, pos.y + 0.9, pos.z, 10, 0.35, 0.55, 0.35, 0.04);
        world.spawnParticles(DARK_PURPLE_DUST, pos.x, pos.y + 0.9, pos.z, 10, 0.4, 0.6, 0.4, 0.03);
    }

    @Nullable
    private static Vec3d findSafeTeleportPos(ServerWorld world, Vec3d candidate, Vec3d stepBackDir, Entity entity) {
        Vec3d[] verticalOffsets = new Vec3d[] {
                Vec3d.ZERO,
                new Vec3d(0.0, 0.5, 0.0),
                new Vec3d(0.0, 1.0, 0.0),
                new Vec3d(0.0, 1.5, 0.0),
                new Vec3d(0.0, 2.0, 0.0),
                new Vec3d(0.0, -0.5, 0.0),
                new Vec3d(0.0, -1.0, 0.0)
        };

        for (Vec3d vOff : verticalOffsets) {
            Vec3d test = candidate.add(vOff);
            if (isSafeStandPos(world, test, entity)) {
                return test;
            }
        }

        if (stepBackDir.lengthSquared() > 1.0E-4) {
            Vec3d normBack = stepBackDir.normalize();
            for (int step = 1; step <= 10; step++) {
                Vec3d base = candidate.add(normBack.multiply(step * 0.5));
                for (Vec3d vOff : verticalOffsets) {
                    Vec3d test = base.add(vOff);
                    if (isSafeStandPos(world, test, entity)) {
                        return test;
                    }
                }
            }
        }

        double[][] sideOffsets = new double[][] {
                {0.6, 0.0}, {-0.6, 0.0}, {0.0, 0.6}, {0.0, -0.6},
                {1.0, 0.0}, {-1.0, 0.0}, {0.0, 1.0}, {0.0, -1.0}
        };
        for (double[] sOff : sideOffsets) {
            for (Vec3d vOff : verticalOffsets) {
                Vec3d test = candidate.add(sOff[0], vOff.y, sOff[1]);
                if (isSafeStandPos(world, test, entity)) {
                    return test;
                }
            }
        }
        return null;
    }

    private static boolean isSafeStandPos(ServerWorld world, Vec3d pos, Entity entity) {
        if (!world.getWorldBorder().contains(pos.x, pos.z)) {
            return false;
        }
        if (pos.y < world.getBottomY() || pos.y > world.getTopYInclusive() - 1) {
            return false;
        }
        double halfWidth = entity.getWidth() * 0.5;
        double height = entity.getHeight();
        Box box = new Box(
                pos.x - halfWidth,
                pos.y,
                pos.z - halfWidth,
                pos.x + halfWidth,
                pos.y + height,
                pos.z + halfWidth
        );
        return world.isSpaceEmpty(entity, box);
    }

    public static void clearServer() {
        PROJECTILE_COOLDOWN_UNTIL_MS.clear();
        TELEPORT_COOLDOWN_UNTIL_MS.clear();
        SHADOW_FORM_COOLDOWN_UNTIL_MS.clear();
        SHADOW_FORM_UNTIL_MS.clear();
        SHADOW_FORM_ACTIVE_PLAYERS.clear();
        FLIGHT_GRANTED_PLAYERS.clear();
        LAST_POSITIONS.clear();
        LAST_RIGHT_CLICK_TICK.clear();
        serverTickCounter = 0L;
    }
}
