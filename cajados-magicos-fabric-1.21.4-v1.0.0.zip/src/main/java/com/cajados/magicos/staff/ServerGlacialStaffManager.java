package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FrostedIceBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerGlacialStaffManager {
    public static final int PROJECTILE_COOLDOWN_TICKS = 40;
    public static final long PROJECTILE_COOLDOWN_MS = 2_000L;
    public static final long AREA_COOLDOWN_MS = 12_000L;
    public static final Identifier PROJECTILE_COOLDOWN_GROUP_ID = Identifier.of(
            CajadosMagicosMod.MOD_ID,
            StaffManager.CAJADO_GLACIAL_ID + "_projetil"
    );
    public static final String PROJECTILE_TAG = "cajados_glacial_projetil";
    public static final float PROJECTILE_DAMAGE = 8.0F;
    public static final int PROJECTILE_SLOWNESS_TICKS = 80;
    public static final int PROJECTILE_SLOWNESS_AMPLIFIER = 3;
    public static final double AREA_RADIUS = 5.0;
    public static final int AREA_SLOWNESS_TICKS = 100;
    public static final int AREA_SLOWNESS_AMPLIFIER = 5;
    public static final double AURA_RADIUS = 3.0;
    public static final int AURA_SLOWNESS_AMPLIFIER = 1;
    public static final int WATER_WALK_RADIUS = 2;
    public static final double TEMP_ICE_KEEP_DISTANCE_SQ = 10.24;
    public static final long TEMP_ICE_MELT_DELAY_TICKS = 16L;

    private static final Map<UUID, Long> PROJECTILE_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> AREA_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Set<UUID> AURA_ACTIVE_HOLDERS = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Set<UUID>> AURA_SLOWED_BY_HOLDER = new ConcurrentHashMap<>();
    private static final Map<IceKey, TempIceEntry> TEMP_ICE_BLOCKS = new ConcurrentHashMap<>();
    private static long serverTickCounter = 0L;

    private ServerGlacialStaffManager() {
    }

    private record IceKey(RegistryKey<World> worldKey, BlockPos pos) {
    }

    private static final class TempIceEntry {
        UUID ownerUuid;
        long lastSupportedTick;

        TempIceEntry(UUID ownerUuid, long lastSupportedTick) {
            this.ownerUuid = ownerUuid;
            this.lastSupportedTick = lastSupportedTick;
        }
    }

    public static boolean tryCastProjectile(ServerPlayerEntity player) {
        if (player == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        Long until = PROJECTILE_COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until != null && until > now) {
            int remainingTicks = Math.min(
                    PROJECTILE_COOLDOWN_TICKS,
                    Math.max(1, (int) Math.ceil((until - now) / 50.0))
            );
            player.getItemCooldownManager().set(PROJECTILE_COOLDOWN_GROUP_ID, remainingTicks);
            return false;
        }

        PROJECTILE_COOLDOWN_UNTIL_MS.put(player.getUuid(), now + PROJECTILE_COOLDOWN_MS);
        player.getItemCooldownManager().set(PROJECTILE_COOLDOWN_GROUP_ID, PROJECTILE_COOLDOWN_TICKS);

        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d spawnPos = player.getEyePos().add(look.multiply(0.85));

        SnowballEntity snowball = new SnowballEntity(world, player, new ItemStack(Items.SNOWBALL));
        snowball.setPosition(spawnPos);
        snowball.setVelocity(look.multiply(1.65));
        snowball.setNoGravity(true);
        snowball.addCommandTag(PROJECTILE_TAG);
        world.spawnEntity(snowball);

        world.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENTITY_SNOWBALL_THROW,
                SoundCategory.PLAYERS,
                1.1F,
                0.75F
        );
        world.spawnParticles(ParticleTypes.SNOWFLAKE, spawnPos.x, spawnPos.y, spawnPos.z, 8, 0.12, 0.12, 0.12, 0.04);
        return true;
    }

    public static boolean tryCastAreaFreeze(ServerPlayerEntity player) {
        if (player == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        Long until = AREA_COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until != null && until > now) {
            int secondsLeft = Math.max(1, (int) Math.ceil((until - now) / 1000.0));
            player.sendMessage(
                    Text.literal("Congelamento em Área em recarga: " + secondsLeft + "s")
                            .formatted(Formatting.AQUA),
                    true
            );
            return false;
        }

        AREA_COOLDOWN_UNTIL_MS.put(player.getUuid(), now + AREA_COOLDOWN_MS);

        ServerWorld world = player.getServerWorld();
        Box areaBox = player.getBoundingBox().expand(AREA_RADIUS);
        List<Entity> targets = world.getOtherEntities(
                player,
                areaBox,
                entity -> entity != player
                        && entity instanceof LivingEntity living
                        && living.isAlive()
                        && !entity.isSpectator()
                        && entity.squaredDistanceTo(player) <= AREA_RADIUS * AREA_RADIUS
        );
        for (Entity entity : targets) {
            LivingEntity living = (LivingEntity) entity;
            living.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.SLOWNESS,
                    AREA_SLOWNESS_TICKS,
                    AREA_SLOWNESS_AMPLIFIER,
                    false,
                    true,
                    true
            ));
        }

        Vec3d center = player.getPos();
        BlockStateParticleEffect iceBreak = new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.ICE.getDefaultState());
        for (int i = 0; i < 36; i++) {
            double angle = (Math.PI * 2.0 * i) / 36.0;
            for (double r = 1.0; r <= AREA_RADIUS; r += 1.3) {
                double px = center.x + Math.cos(angle) * r;
                double pz = center.z + Math.sin(angle) * r;
                world.spawnParticles(ParticleTypes.SNOWFLAKE, px, center.y + 0.35, pz, 2, 0.15, 0.25, 0.15, 0.03);
            }
            double ringX = center.x + Math.cos(angle) * (AREA_RADIUS * 0.75);
            double ringZ = center.z + Math.sin(angle) * (AREA_RADIUS * 0.75);
            world.spawnParticles(iceBreak, ringX, center.y + 0.5, ringZ, 2, 0.25, 0.25, 0.25, 0.08);
            world.spawnParticles(ParticleTypes.ITEM_SNOWBALL, ringX, center.y + 0.4, ringZ, 1, 0.2, 0.2, 0.2, 0.05);
        }

        world.playSound(
                null,
                center.x,
                center.y,
                center.z,
                SoundEvents.ENTITY_PLAYER_HURT_FREEZE,
                SoundCategory.PLAYERS,
                1.3F,
                0.9F
        );
        world.playSound(
                null,
                center.x,
                center.y,
                center.z,
                SoundEvents.BLOCK_GLASS_BREAK,
                SoundCategory.PLAYERS,
                1.1F,
                1.2F
        );
        return true;
    }

    public static void handleProjectileCollision(SnowballEntity snowball, HitResult hitResult) {
        if (snowball == null || snowball.isRemoved() || !(snowball.getWorld() instanceof ServerWorld world)) {
            return;
        }
        Entity owner = snowball.getOwner();
        if (hitResult instanceof EntityHitResult entityHit) {
            Entity target = entityHit.getEntity();
            if (target != null && target.isAlive()) {
                target.damage(world, snowball.getDamageSources().thrown(snowball, owner), PROJECTILE_DAMAGE);
                if (target instanceof LivingEntity living && living.isAlive()) {
                    living.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.SLOWNESS,
                            PROJECTILE_SLOWNESS_TICKS,
                            PROJECTILE_SLOWNESS_AMPLIFIER,
                            false,
                            true,
                            true
                    ));
                }
            }
        }

        Vec3d pos = snowball.getPos();
        BlockStateParticleEffect iceParticle = new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.ICE.getDefaultState());
        world.spawnParticles(ParticleTypes.SNOWFLAKE, pos.x, pos.y, pos.z, 24, 0.35, 0.35, 0.35, 0.08);
        world.spawnParticles(iceParticle, pos.x, pos.y, pos.z, 18, 0.3, 0.3, 0.3, 0.12);
        world.spawnParticles(ParticleTypes.ITEM_SNOWBALL, pos.x, pos.y, pos.z, 10, 0.25, 0.25, 0.25, 0.08);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.BLOCK_GLASS_BREAK,
                SoundCategory.PLAYERS,
                0.95F,
                1.35F
        );
        snowball.discard();
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        Long projUntil = PROJECTILE_COOLDOWN_UNTIL_MS.get(uuid);
        if (projUntil != null) {
            long remainingMs = projUntil - System.currentTimeMillis();
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(
                        PROJECTILE_COOLDOWN_TICKS,
                        Math.max(1, (int) Math.ceil(remainingMs / 50.0))
                );
                player.getItemCooldownManager().set(PROJECTILE_COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                PROJECTILE_COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }
    }

    public static void onDisconnect(MinecraftServer server, UUID uuid) {
        if (server != null) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
            if (player != null) {
                clearAuraForHolder(server, player);
            } else {
                AURA_ACTIVE_HOLDERS.remove(uuid);
                AURA_SLOWED_BY_HOLDER.remove(uuid);
            }
        } else {
            AURA_ACTIVE_HOLDERS.remove(uuid);
            AURA_SLOWED_BY_HOLDER.remove(uuid);
        }
    }

    public static void tick(MinecraftServer server) {
        serverTickCounter++;
        Map<UUID, ServerPlayerEntity> waterWalkers = new HashMap<>();

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            boolean hasStaff = player.isAlive() && !player.isSpectator() && StaffManager.hasCajadoGlacial(player);

            if (hasStaff) {
                AURA_ACTIVE_HOLDERS.add(uuid);
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.RESISTANCE,
                        30,
                        0,
                        true,
                        false,
                        true
                ));
                applyAuraSlowToNearbyEnemies(player);
                if (serverTickCounter % 4L == 0L) {
                    player.getServerWorld().spawnParticles(
                            ParticleTypes.SNOWFLAKE,
                            player.getX(),
                            player.getY() + 0.9,
                            player.getZ(),
                            2,
                            0.55,
                            0.45,
                            0.55,
                            0.01
                    );
                }

                if (StaffManager.isHoldingCajadoGlacial(player)) {
                    waterWalkers.put(uuid, player);
                    freezeWaterAroundPlayer(player);
                } else {
                    meltOwnerIceImmediately(server, uuid, waterWalkers);
                }
            } else {
                clearAuraForHolder(server, player);
                meltOwnerIceImmediately(server, uuid, waterWalkers);
            }
        }

        cleanupExpiredTempIce(server, waterWalkers);
    }

    private static void applyAuraSlowToNearbyEnemies(ServerPlayerEntity holder) {
        UUID holderId = holder.getUuid();
        ServerWorld world = holder.getServerWorld();
        Set<UUID> previousSlowed = AURA_SLOWED_BY_HOLDER.getOrDefault(holderId, Set.of());
        Set<UUID> currentSlowed = new HashSet<>();

        List<Entity> nearby = world.getOtherEntities(
                holder,
                holder.getBoundingBox().expand(AURA_RADIUS),
                entity -> isEnemy(holder, entity) && entity.squaredDistanceTo(holder) <= AURA_RADIUS * AURA_RADIUS
        );
        for (Entity entity : nearby) {
            LivingEntity living = (LivingEntity) entity;
            currentSlowed.add(living.getUuid());
            StatusEffectInstance existing = living.getStatusEffect(StatusEffects.SLOWNESS);
            if (existing == null || existing.getAmplifier() <= AURA_SLOWNESS_AMPLIFIER) {
                living.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.SLOWNESS,
                        25,
                        AURA_SLOWNESS_AMPLIFIER,
                        true,
                        true,
                        true
                ));
            }
        }

        for (UUID oldId : previousSlowed) {
            if (!currentSlowed.contains(oldId)) {
                removeAuraSlowIfApplicable(holder.getServer(), oldId);
            }
        }

        if (currentSlowed.isEmpty()) {
            AURA_SLOWED_BY_HOLDER.remove(holderId);
        } else {
            AURA_SLOWED_BY_HOLDER.put(holderId, currentSlowed);
        }
    }

    private static void clearAuraForHolder(MinecraftServer server, ServerPlayerEntity holder) {
        UUID holderId = holder.getUuid();
        if (AURA_ACTIVE_HOLDERS.remove(holderId)) {
            StatusEffectInstance resistance = holder.getStatusEffect(StatusEffects.RESISTANCE);
            if (resistance != null && resistance.getAmplifier() == 0 && resistance.getDuration() <= 35) {
                holder.removeStatusEffect(StatusEffects.RESISTANCE);
            }
        }
        Set<UUID> slowed = AURA_SLOWED_BY_HOLDER.remove(holderId);
        if (slowed != null && server != null) {
            for (UUID targetId : slowed) {
                removeAuraSlowIfApplicable(server, targetId);
            }
        }
    }

    private static void removeAuraSlowIfApplicable(MinecraftServer server, UUID entityId) {
        for (ServerWorld world : server.getWorlds()) {
            Entity entity = world.getEntity(entityId);
            if (entity instanceof LivingEntity living) {
                StatusEffectInstance slowness = living.getStatusEffect(StatusEffects.SLOWNESS);
                if (slowness != null && slowness.getAmplifier() <= AURA_SLOWNESS_AMPLIFIER && slowness.getDuration() <= 30) {
                    living.removeStatusEffect(StatusEffects.SLOWNESS);
                }
                return;
            }
        }
    }

    private static boolean isEnemy(ServerPlayerEntity holder, Entity entity) {
        if (entity == holder || !(entity instanceof LivingEntity living) || !living.isAlive() || entity.isSpectator()) {
            return false;
        }
        if (entity instanceof PlayerEntity otherPlayer) {
            return !otherPlayer.isCreative() && !otherPlayer.isSpectator() && !holder.isTeammate(otherPlayer);
        }
        if (entity instanceof Monster) {
            return true;
        }
        return entity instanceof MobEntity mob && mob.getTarget() == holder;
    }

    private static void freezeWaterAroundPlayer(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        RegistryKey<World> worldKey = world.getRegistryKey();
        int centerX = MathHelper.floor(player.getX());
        int centerZ = MathHelper.floor(player.getZ());
        int surfaceY = MathHelper.floor(player.getY() - 0.35);

        for (int dx = -WATER_WALK_RADIUS; dx <= WATER_WALK_RADIUS; dx++) {
            for (int dz = -WATER_WALK_RADIUS; dz <= WATER_WALK_RADIUS; dz++) {
                if (dx * dx + dz * dz > 5) {
                    continue;
                }
                BlockPos targetPos = new BlockPos(centerX + dx, surfaceY, centerZ + dz);
                if (!world.isChunkLoaded(targetPos)) {
                    continue;
                }
                BlockState current = world.getBlockState(targetPos);
                if (current.isOf(Blocks.WATER) && current.getFluidState().isStill() && world.isAir(targetPos.up())) {
                    if (player.getY() < targetPos.getY() + 0.85 && player.getBoundingBox().intersects(new Box(targetPos))) {
                        if (player.isTouchingWater()) {
                            Vec3d vel = player.getVelocity();
                            player.setVelocity(vel.x, Math.max(vel.y, 0.30), vel.z);
                            player.velocityModified = true;
                        }
                        continue;
                    }
                    world.setBlockState(targetPos, Blocks.FROSTED_ICE.getDefaultState(), Block.NOTIFY_ALL);
                    TEMP_ICE_BLOCKS.put(
                            new IceKey(worldKey, targetPos.toImmutable()),
                            new TempIceEntry(player.getUuid(), serverTickCounter)
                    );
                } else if (current.isOf(Blocks.FROSTED_ICE)) {
                    IceKey key = new IceKey(worldKey, targetPos.toImmutable());
                    TempIceEntry entry = TEMP_ICE_BLOCKS.get(key);
                    if (entry != null) {
                        entry.ownerUuid = player.getUuid();
                        entry.lastSupportedTick = serverTickCounter;
                        if (current.get(FrostedIceBlock.AGE) > 0) {
                            world.setBlockState(targetPos, current.with(FrostedIceBlock.AGE, 0), Block.NOTIFY_LISTENERS);
                        }
                    }
                }
            }
        }
    }

    private static void meltOwnerIceImmediately(
            MinecraftServer server,
            UUID ownerUuid,
            Map<UUID, ServerPlayerEntity> activeWalkers
    ) {
        Iterator<Map.Entry<IceKey, TempIceEntry>> it = TEMP_ICE_BLOCKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<IceKey, TempIceEntry> entry = it.next();
            if (!ownerUuid.equals(entry.getValue().ownerUuid)) {
                continue;
            }
            IceKey key = entry.getKey();
            ServerPlayerEntity nearbyWalker = findNearbyActiveWalker(key, activeWalkers);
            if (nearbyWalker != null) {
                entry.getValue().ownerUuid = nearbyWalker.getUuid();
                entry.getValue().lastSupportedTick = serverTickCounter;
                continue;
            }
            revertIceBlock(server, key);
            it.remove();
        }
    }

    private static void cleanupExpiredTempIce(MinecraftServer server, Map<UUID, ServerPlayerEntity> activeWalkers) {
        Iterator<Map.Entry<IceKey, TempIceEntry>> it = TEMP_ICE_BLOCKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<IceKey, TempIceEntry> entry = it.next();
            IceKey key = entry.getKey();
            ServerPlayerEntity nearbyWalker = findNearbyActiveWalker(key, activeWalkers);
            if (nearbyWalker != null) {
                entry.getValue().ownerUuid = nearbyWalker.getUuid();
                entry.getValue().lastSupportedTick = serverTickCounter;
                continue;
            }
            if (serverTickCounter - entry.getValue().lastSupportedTick >= TEMP_ICE_MELT_DELAY_TICKS) {
                revertIceBlock(server, key);
                it.remove();
            }
        }
    }

    private static ServerPlayerEntity findNearbyActiveWalker(
            IceKey key,
            Map<UUID, ServerPlayerEntity> activeWalkers
    ) {
        double cx = key.pos().getX() + 0.5;
        double cy = key.pos().getY() + 0.5;
        double cz = key.pos().getZ() + 0.5;
        for (ServerPlayerEntity walker : activeWalkers.values()) {
            if (walker.getServerWorld().getRegistryKey().equals(key.worldKey())
                    && walker.squaredDistanceTo(cx, cy, cz) <= TEMP_ICE_KEEP_DISTANCE_SQ) {
                return walker;
            }
        }
        return null;
    }

    private static void revertIceBlock(MinecraftServer server, IceKey key) {
        if (server == null) {
            return;
        }
        ServerWorld world = server.getWorld(key.worldKey());
        if (world != null && world.isChunkLoaded(key.pos()) && world.getBlockState(key.pos()).isOf(Blocks.FROSTED_ICE)) {
            world.setBlockState(key.pos(), Blocks.WATER.getDefaultState(), Block.NOTIFY_ALL);
        }
    }

    public static void clearServer(MinecraftServer server) {
        if (server != null) {
            for (IceKey key : TEMP_ICE_BLOCKS.keySet()) {
                revertIceBlock(server, key);
            }
        }
        TEMP_ICE_BLOCKS.clear();
        PROJECTILE_COOLDOWN_UNTIL_MS.clear();
        AREA_COOLDOWN_UNTIL_MS.clear();
        AURA_ACTIVE_HOLDERS.clear();
        AURA_SLOWED_BY_HOLDER.clear();
        serverTickCounter = 0L;
    }
}
