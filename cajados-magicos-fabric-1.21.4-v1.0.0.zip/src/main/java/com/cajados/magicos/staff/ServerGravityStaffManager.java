package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import com.cajados.magicos.mixin.FallingBlockEntityAccessor;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class ServerGravityStaffManager {
    public static final String METEOR_TAG = "cajados_gravidade_meteoro";
    public static final int METEOR_COOLDOWN_TICKS = 100;
    public static final long METEOR_COOLDOWN_MS = 5_000L;
    public static final float METEOR_DAMAGE = 16.0F;
    public static final double METEOR_DIRECT_HIT_RADIUS = 1.65;
    public static final double METEOR_SHOCKWAVE_RADIUS = 5.0;
    public static final double METEOR_MAX_DISTANCE = 56.0;
    public static final double METEOR_SPAWN_HEIGHT = 13.0;
    public static final double METEOR_SPEED = 0.95;

    public static final long REPULSION_COOLDOWN_MS = 8_000L;
    public static final double REPULSION_RADIUS = 6.0;

    public static final long FIELD_COOLDOWN_MS = 15_000L;
    public static final int FIELD_DURATION_TICKS = 80;
    public static final double FIELD_RADIUS = 5.0;
    public static final double FIELD_MAX_DISTANCE = 48.0;

    public static final Identifier METEOR_COOLDOWN_GROUP_ID =
            Identifier.of(CajadosMagicosMod.MOD_ID, StaffManager.CAJADO_GRAVIDADE_ID + "_meteoro");

    private static final DustParticleEffect PURPLE_DUST = new DustParticleEffect(0xA855F7, 1.35F);
    private static final DustParticleEffect DEEP_PURPLE_DUST = new DustParticleEffect(0x7E22CE, 1.45F);
    private static final DustParticleEffect BLUE_DUST = new DustParticleEffect(0x38BDF8, 1.25F);
    private static final BlockStateParticleEffect STONE_PARTICLES =
            new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.STONE.getDefaultState());

    private static final Map<UUID, Long> METEOR_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> REPULSION_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> FIELD_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_RIGHT_CLICK_TICK = new ConcurrentHashMap<>();
    private static final Map<UUID, MeteorData> ACTIVE_METEORS = new ConcurrentHashMap<>();
    private static final List<GravityField> ACTIVE_FIELDS = new ArrayList<>();
    private static final Set<UUID> FLIGHT_GRANTED_PLAYERS = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Vec3d> LAST_POSITIONS = new ConcurrentHashMap<>();

    private static long serverTickCounter = 0L;

    private ServerGravityStaffManager() {
    }

    private record MeteorData(UUID ownerUuid, Vec3d velocity, int ageTicks) {
    }

    private static final class GravityField {
        final RegistryKey<World> worldKey;
        final Vec3d center;
        final UUID ownerUuid;
        int remainingTicks;

        GravityField(RegistryKey<World> worldKey, Vec3d center, UUID ownerUuid, int remainingTicks) {
            this.worldKey = worldKey;
            this.center = center;
            this.ownerUuid = ownerUuid;
            this.remainingTicks = remainingTicks;
        }
    }

    public static void markRightClick(UUID playerUuid) {
        if (playerUuid != null) {
            LAST_RIGHT_CLICK_TICK.put(playerUuid, serverTickCounter);
        }
    }

    public static boolean tryUseGravityStaff(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return false;
        }
        if (player.isSneaking()) {
            return tryCastRepulsion(player);
        }
        return tryCastMeteor(player);
    }

    public static boolean tryCastMeteor(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = METEOR_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            long sec = Math.max(1L, (until - now + 999L) / 1000L);
            player.sendMessage(
                    Text.literal("Meteoro Gravitacional em recarga (" + sec + "s).")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        METEOR_COOLDOWN_UNTIL_MS.put(uuid, now + METEOR_COOLDOWN_MS);
        player.getItemCooldownManager().set(METEOR_COOLDOWN_GROUP_ID, METEOR_COOLDOWN_TICKS);

        ServerWorld world = player.getServerWorld();
        Vec3d targetPos = findTargetPoint(player, METEOR_MAX_DISTANCE);
        Vec3d playerPos = player.getPos();
        Vec3d toPlayerHoriz = new Vec3d(playerPos.x - targetPos.x, 0.0, playerPos.z - targetPos.z);
        double horizDist = toPlayerHoriz.length();
        Vec3d backDir = horizDist > 1.0E-4
                ? toPlayerHoriz.multiply(1.0 / horizDist)
                : new Vec3d(-player.getRotationVec(1.0F).x, 0.0, -player.getRotationVec(1.0F).z);
        if (backDir.lengthSquared() <= 1.0E-4) {
            backDir = new Vec3d(0.0, 0.0, 1.0);
        } else {
            backDir = backDir.normalize();
        }

        ThreadLocalRandom random = ThreadLocalRandom.current();
        double backShift = Math.min(5.5, Math.max(1.5, horizDist * 0.35));
        double sideShift = (random.nextDouble() - 0.5) * 2.5;
        Vec3d sideVec = new Vec3d(-backDir.z, 0.0, backDir.x);

        Vec3d idealSpawn = new Vec3d(
                targetPos.x + backDir.x * backShift + sideVec.x * sideShift,
                targetPos.y + METEOR_SPAWN_HEIGHT,
                targetPos.z + backDir.z * backShift + sideVec.z * sideShift
        );

        Vec3d clearOrigin = targetPos.add(0.0, 0.8, 0.0);
        BlockHitResult skyCheck = world.raycast(new RaycastContext(
                clearOrigin,
                idealSpawn,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));

        Vec3d spawnPos;
        if (skyCheck.getType() != HitResult.Type.MISS) {
            Vec3d backFromCeiling = clearOrigin.subtract(skyCheck.getPos());
            if (backFromCeiling.lengthSquared() > 1.0E-4) {
                spawnPos = skyCheck.getPos().add(backFromCeiling.normalize().multiply(1.2));
            } else {
                spawnPos = targetPos.add(0.0, 4.0, 0.0);
            }
        } else {
            spawnPos = idealSpawn;
        }

        if (spawnPos.squaredDistanceTo(targetPos) < 4.0) {
            spawnPos = targetPos.add(0.0, 5.0, 0.0);
        }

        Vec3d velocity = targetPos.subtract(spawnPos).normalize().multiply(METEOR_SPEED);

        FallingBlockEntity meteor = new FallingBlockEntity(EntityType.FALLING_BLOCK, world);
        ((FallingBlockEntityAccessor) meteor).cajados$setBlockState(Blocks.STONE.getDefaultState());
        meteor.setPosition(spawnPos);
        meteor.setFallingBlockPos(BlockPos.ofFloored(spawnPos));
        meteor.setNoGravity(true);
        meteor.dropItem = false;
        meteor.timeFalling = 1;
        meteor.setVelocity(velocity);
        meteor.velocityModified = true;
        meteor.addCommandTag(METEOR_TAG);

        ACTIVE_METEORS.put(meteor.getUuid(), new MeteorData(uuid, velocity, 0));
        world.spawnEntity(meteor);

        world.spawnParticles(PURPLE_DUST, spawnPos.x, spawnPos.y, spawnPos.z, 18, 0.65, 0.65, 0.65, 0.05);
        world.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENTITY_EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS,
                0.95F,
                0.7F
        );
        return true;
    }

    public static boolean tryCastRepulsion(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = REPULSION_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            long sec = Math.max(1L, (until - now + 999L) / 1000L);
            player.sendMessage(
                    Text.literal("Repulsão Gravitacional em recarga (" + sec + "s).")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return false;
        }

        REPULSION_COOLDOWN_UNTIL_MS.put(uuid, now + REPULSION_COOLDOWN_MS);

        ServerWorld world = player.getServerWorld();
        Vec3d origin = player.getPos().add(0.0, 0.9, 0.0);
        Box area = Box.of(origin, REPULSION_RADIUS * 2.0, REPULSION_RADIUS * 2.0, REPULSION_RADIUS * 2.0);
        List<Entity> targets = world.getOtherEntities(
                player,
                area,
                entity -> entity.isAlive()
                        && !entity.isSpectator()
                        && !entity.getCommandTags().contains(METEOR_TAG)
        );

        double maxDistSq = REPULSION_RADIUS * REPULSION_RADIUS;
        for (Entity target : targets) {
            Vec3d targetCenter = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0);
            double distSq = targetCenter.squaredDistanceTo(origin);
            if (distSq > maxDistSq) {
                continue;
            }
            Vec3d delta = targetCenter.subtract(origin);
            Vec3d horizontal = new Vec3d(delta.x, 0.0, delta.z);
            Vec3d pushDir = horizontal.lengthSquared() > 1.0E-4
                    ? horizontal.normalize()
                    : new Vec3d(player.getRotationVec(1.0F).x, 0.0, player.getRotationVec(1.0F).z).normalize();
            if (pushDir.lengthSquared() <= 1.0E-4) {
                pushDir = new Vec3d(1.0, 0.0, 0.0);
            }
            double falloff = 1.0 - Math.min(0.65, Math.sqrt(distSq) / (REPULSION_RADIUS * 1.4));
            target.addVelocity(pushDir.x * (1.75 * falloff + 0.55), 0.55, pushDir.z * (1.75 * falloff + 0.55));
            target.velocityModified = true;
        }

        for (int ring = 1; ring <= 3; ring++) {
            double radius = (REPULSION_RADIUS / 3.0) * ring;
            int points = 18 + ring * 8;
            for (int i = 0; i < points; i++) {
                double angle = (Math.PI * 2.0 * i) / points;
                double px = origin.x + Math.cos(angle) * radius;
                double pz = origin.z + Math.sin(angle) * radius;
                world.spawnParticles(PURPLE_DUST, px, origin.y, pz, 1, 0.08, 0.12, 0.08, 0.02);
                world.spawnParticles(BLUE_DUST, px, origin.y + 0.25, pz, 1, 0.08, 0.12, 0.08, 0.02);
            }
        }
        world.spawnParticles(ParticleTypes.PORTAL, origin.x, origin.y, origin.z, 32, 1.4, 0.6, 1.4, 0.4);
        world.playSound(
                null,
                origin.x,
                origin.y,
                origin.z,
                SoundEvents.ENTITY_ENDER_DRAGON_FLAP,
                SoundCategory.PLAYERS,
                1.0F,
                0.75F
        );
        return true;
    }

    public static void tryHandleLeftClickSwing(ServerPlayerEntity player) {
        if (player == null || !player.isAlive() || player.isSpectator()) {
            return;
        }
        if (!StaffManager.isCajadoGravidade(player.getMainHandStack())) {
            return;
        }
        Long lastRightClick = LAST_RIGHT_CLICK_TICK.get(player.getUuid());
        if (lastRightClick != null && (serverTickCounter - lastRightClick) <= 3L) {
            return;
        }

        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();
        Long until = FIELD_COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null && until > now) {
            long sec = Math.max(1L, (until - now + 999L) / 1000L);
            player.sendMessage(
                    Text.literal("Campo de Gravidade em recarga (" + sec + "s).")
                            .formatted(Formatting.LIGHT_PURPLE),
                    true
            );
            return;
        }

        FIELD_COOLDOWN_UNTIL_MS.put(uuid, now + FIELD_COOLDOWN_MS);

        Vec3d center = findTargetPoint(player, FIELD_MAX_DISTANCE);
        ServerWorld world = player.getServerWorld();
        ACTIVE_FIELDS.add(new GravityField(world.getRegistryKey(), center, uuid, FIELD_DURATION_TICKS));

        world.spawnParticles(DEEP_PURPLE_DUST, center.x, center.y + 0.5, center.z, 26, 0.9, 0.6, 0.9, 0.04);
        world.spawnParticles(ParticleTypes.PORTAL, center.x, center.y + 0.6, center.z, 30, 1.1, 0.7, 1.1, 0.35);
        world.playSound(
                null,
                center.x,
                center.y,
                center.z,
                SoundEvents.BLOCK_BEACON_ACTIVATE,
                SoundCategory.PLAYERS,
                1.0F,
                0.65F
        );
    }

    public static void tickMeteor(FallingBlockEntity meteor) {
        if (meteor.isRemoved() || !(meteor.getWorld() instanceof ServerWorld world)) {
            ACTIVE_METEORS.remove(meteor.getUuid());
            return;
        }

        MeteorData data = ACTIVE_METEORS.get(meteor.getUuid());
        if (data == null) {
            meteor.discard();
            return;
        }

        if (data.ageTicks > 120) {
            ACTIVE_METEORS.remove(meteor.getUuid());
            meteor.discard();
            return;
        }

        Vec3d currentPos = meteor.getPos();
        Vec3d velocity = data.velocity;
        Vec3d nextPos = currentPos.add(velocity);

        ACTIVE_METEORS.put(meteor.getUuid(), new MeteorData(data.ownerUuid, velocity, data.ageTicks + 1));

        world.spawnParticles(STONE_PARTICLES, currentPos.x, currentPos.y + 0.45, currentPos.z, 4, 0.25, 0.25, 0.25, 0.08);
        world.spawnParticles(PURPLE_DUST, currentPos.x, currentPos.y + 0.45, currentPos.z, 3, 0.2, 0.2, 0.2, 0.03);
        world.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, currentPos.x, currentPos.y + 0.5, currentPos.z, 2, 0.15, 0.15, 0.15, 0.02);

        Entity owner = world.getServer().getPlayerManager().getPlayer(data.ownerUuid);
        Box sweepBox = meteor.getBoundingBox().stretch(velocity).expand(0.6);
        EntityHitResult entityHit = ProjectileUtil.raycast(
                meteor,
                currentPos.add(0.0, 0.5, 0.0),
                nextPos.add(0.0, 0.5, 0.0),
                sweepBox,
                target -> target.isAlive()
                        && !target.isSpectator()
                        && target.canHit()
                        && !target.equals(owner)
                        && !target.getCommandTags().contains(METEOR_TAG),
                velocity.lengthSquared() + 0.5
        );

        if (entityHit != null) {
            detonateMeteor(world, meteor, data.ownerUuid, entityHit.getPos(), entityHit.getEntity());
            return;
        }

        BlockHitResult blockHit = world.raycast(new RaycastContext(
                currentPos.add(0.0, 0.5, 0.0),
                nextPos.add(0.0, 0.1, 0.0),
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                meteor
        ));

        if (blockHit.getType() != HitResult.Type.MISS) {
            detonateMeteor(world, meteor, data.ownerUuid, blockHit.getPos(), null);
            return;
        }

        meteor.setPosition(nextPos);
        meteor.setVelocity(velocity);
        meteor.velocityModified = true;
    }

    private static void detonateMeteor(
            ServerWorld world,
            FallingBlockEntity meteor,
            UUID ownerUuid,
            Vec3d impactPos,
            Entity directEntity
    ) {
        ACTIVE_METEORS.remove(meteor.getUuid());
        Entity owner = world.getServer().getPlayerManager().getPlayer(ownerUuid);

        if (directEntity != null && directEntity.isAlive() && !directEntity.equals(owner)) {
            directEntity.damage(world, world.getDamageSources().indirectMagic(meteor, owner), METEOR_DAMAGE);
        }

        Box directBox = Box.of(impactPos, METEOR_DIRECT_HIT_RADIUS * 2.0, METEOR_DIRECT_HIT_RADIUS * 2.0, METEOR_DIRECT_HIT_RADIUS * 2.0);
        List<Entity> directNearby = world.getOtherEntities(
                meteor,
                directBox,
                entity -> entity.isAlive()
                        && !entity.isSpectator()
                        && entity instanceof LivingEntity
                        && !entity.equals(owner)
                        && !entity.equals(directEntity)
        );
        for (Entity hit : directNearby) {
            if (hit.getPos().add(0.0, hit.getHeight() * 0.5, 0.0).squaredDistanceTo(impactPos)
                    <= METEOR_DIRECT_HIT_RADIUS * METEOR_DIRECT_HIT_RADIUS) {
                hit.damage(world, world.getDamageSources().indirectMagic(meteor, owner), METEOR_DAMAGE);
            }
        }

        Box shockwaveBox = Box.of(impactPos, METEOR_SHOCKWAVE_RADIUS * 2.0, METEOR_SHOCKWAVE_RADIUS * 2.0, METEOR_SHOCKWAVE_RADIUS * 2.0);
        List<Entity> pushTargets = world.getOtherEntities(
                meteor,
                shockwaveBox,
                entity -> entity.isAlive()
                        && !entity.isSpectator()
                        && !entity.equals(owner)
                        && !entity.getCommandTags().contains(METEOR_TAG)
        );
        double maxDistSq = METEOR_SHOCKWAVE_RADIUS * METEOR_SHOCKWAVE_RADIUS;
        for (Entity nearby : pushTargets) {
            Vec3d entityPos = nearby.getPos().add(0.0, nearby.getHeight() * 0.4, 0.0);
            double distSq = entityPos.squaredDistanceTo(impactPos);
            if (distSq > maxDistSq) {
                continue;
            }
            Vec3d delta = entityPos.subtract(impactPos);
            Vec3d horiz = new Vec3d(delta.x, 0.0, delta.z);
            Vec3d dir = horiz.lengthSquared() > 1.0E-4 ? horiz.normalize() : new Vec3d(0.0, 0.0, 1.0);
            double strength = 1.4 * (1.0 - Math.min(0.65, Math.sqrt(distSq) / (METEOR_SHOCKWAVE_RADIUS * 1.4)));
            nearby.addVelocity(dir.x * strength, 0.48, dir.z * strength);
            nearby.velocityModified = true;
        }

        world.spawnParticles(STONE_PARTICLES, impactPos.x, impactPos.y + 0.3, impactPos.z, 55, 1.6, 0.45, 1.6, 0.25);
        world.spawnParticles(ParticleTypes.POOF, impactPos.x, impactPos.y + 0.25, impactPos.z, 26, 1.5, 0.35, 1.5, 0.09);
        world.spawnParticles(ParticleTypes.CLOUD, impactPos.x, impactPos.y + 0.2, impactPos.z, 18, 1.7, 0.2, 1.7, 0.06);
        world.spawnParticles(PURPLE_DUST, impactPos.x, impactPos.y + 0.4, impactPos.z, 24, 1.4, 0.4, 1.4, 0.05);

        for (int i = 0; i < 24; i++) {
            double angle = (Math.PI * 2.0 * i) / 24.0;
            double rx = impactPos.x + Math.cos(angle) * 2.8;
            double rz = impactPos.z + Math.sin(angle) * 2.8;
            world.spawnParticles(STONE_PARTICLES, rx, impactPos.y + 0.2, rz, 2, 0.2, 0.1, 0.2, 0.08);
        }

        world.playSound(
                null,
                impactPos.x,
                impactPos.y,
                impactPos.z,
                SoundEvents.ENTITY_GENERIC_EXPLODE.value(),
                SoundCategory.PLAYERS,
                1.2F,
                0.75F
        );
        world.playSound(
                null,
                impactPos.x,
                impactPos.y,
                impactPos.z,
                SoundEvents.BLOCK_STONE_BREAK,
                SoundCategory.PLAYERS,
                1.4F,
                0.6F
        );

        meteor.discard();
    }

    private static Vec3d findTargetPoint(ServerPlayerEntity player, double maxDistance) {
        Vec3d eyePos = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d maxEnd = eyePos.add(look.multiply(maxDistance));

        BlockHitResult blockHit = player.getServerWorld().raycast(new RaycastContext(
                eyePos,
                maxEnd,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                player
        ));
        double maxEntityDistSq = blockHit.getType() != HitResult.Type.MISS
                ? blockHit.getPos().squaredDistanceTo(eyePos)
                : maxDistance * maxDistance;

        EntityHitResult entityHit = ProjectileUtil.raycast(
                player,
                eyePos,
                maxEnd,
                player.getBoundingBox().stretch(look.multiply(maxDistance)).expand(1.0),
                target -> target.isAlive() && !target.isSpectator() && target.canHit() && target != player,
                maxEntityDistSq
        );

        if (entityHit != null) {
            return entityHit.getPos();
        }
        if (blockHit.getType() != HitResult.Type.MISS) {
            return blockHit.getPos();
        }
        return eyePos.add(look.multiply(Math.min(maxDistance, 24.0)));
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        LAST_POSITIONS.put(uuid, player.getPos());

        Long meteorUntil = METEOR_COOLDOWN_UNTIL_MS.get(uuid);
        if (meteorUntil != null) {
            long remainingMs = meteorUntil - System.currentTimeMillis();
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(
                        METEOR_COOLDOWN_TICKS,
                        Math.max(1, (int) Math.ceil(remainingMs / 50.0))
                );
                player.getItemCooldownManager().set(METEOR_COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                METEOR_COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }

        if (!player.isCreative() && !player.isSpectator()) {
            if (player.isAlive() && StaffManager.hasCajadoGravidade(player)) {
                player.getAbilities().allowFlying = true;
                player.sendAbilitiesUpdate();
                FLIGHT_GRANTED_PLAYERS.add(uuid);
            } else if (player.getAbilities().allowFlying
                    && !StaffManager.hasCajadoSombras(player)
                    && !StaffManager.hasCajadoThor(player)
                    && !ServerFireStaffManager.canFlyWithFireStaff(player)) {
                player.getAbilities().allowFlying = false;
                player.getAbilities().flying = false;
                player.sendAbilitiesUpdate();
            }
        }
    }

    public static void onDisconnect(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        FLIGHT_GRANTED_PLAYERS.remove(uuid);
        LAST_POSITIONS.remove(uuid);
        LAST_RIGHT_CLICK_TICK.remove(uuid);
    }

    public static void tick(MinecraftServer server) {
        serverTickCounter++;

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            Vec3d currentPos = player.getPos();
            Vec3d prevPos = LAST_POSITIONS.put(uuid, currentPos);

            if (player.isCreative() || player.isSpectator()) {
                FLIGHT_GRANTED_PLAYERS.remove(uuid);
                continue;
            }

            boolean hasStaff = player.isAlive() && StaffManager.hasCajadoGravidade(player);
            if (hasStaff) {
                if (!player.getAbilities().allowFlying || !FLIGHT_GRANTED_PLAYERS.contains(uuid)) {
                    player.getAbilities().allowFlying = true;
                    player.sendAbilitiesUpdate();
                    FLIGHT_GRANTED_PLAYERS.add(uuid);
                }
                if (player.getAbilities().flying) {
                    spawnMovingGravityFlightParticles(player, currentPos, prevPos);
                }
            } else if (FLIGHT_GRANTED_PLAYERS.remove(uuid)) {
                if (!StaffManager.hasCajadoSombras(player)
                        && !StaffManager.hasCajadoThor(player)
                        && !ServerFireStaffManager.canFlyWithFireStaff(player)) {
                    player.getAbilities().allowFlying = false;
                    player.getAbilities().flying = false;
                    player.sendAbilitiesUpdate();
                }
            }
        }

        tickGravityFields(server);
    }

    private static void tickGravityFields(MinecraftServer server) {
        if (ACTIVE_FIELDS.isEmpty()) {
            return;
        }

        Iterator<GravityField> iterator = ACTIVE_FIELDS.iterator();
        while (iterator.hasNext()) {
            GravityField field = iterator.next();
            ServerWorld world = server.getWorld(field.worldKey);
            if (world == null || field.remainingTicks <= 0) {
                iterator.remove();
                continue;
            }
            field.remainingTicks--;

            Vec3d center = field.center;
            Vec3d pullCenter = center.add(0.0, 0.85, 0.0);
            Box area = Box.of(center, FIELD_RADIUS * 2.0, FIELD_RADIUS * 2.0, FIELD_RADIUS * 2.0);
            List<Entity> nearbyEntities = world.getOtherEntities(
                    null,
                    area,
                    entity -> entity.isAlive()
                            && !entity.isSpectator()
                            && !entity.getUuid().equals(field.ownerUuid)
                            && !entity.getCommandTags().contains(METEOR_TAG)
            );

            double maxDistSq = FIELD_RADIUS * FIELD_RADIUS;
            for (Entity entity : nearbyEntities) {
                Vec3d entityPos = entity.getPos().add(0.0, entity.getHeight() * 0.5, 0.0);
                double distSq = entityPos.squaredDistanceTo(pullCenter);
                if (distSq > maxDistSq || distSq < 0.09) {
                    continue;
                }
                Vec3d toCenter = pullCenter.subtract(entityPos).normalize();
                double speed = 0.24;
                Vec3d blended = entity.getVelocity().multiply(0.55).add(toCenter.multiply(speed));
                entity.setVelocity(blended);
                entity.velocityModified = true;
            }

            if (field.remainingTicks % 2 == 0) {
                double baseAngle = (FIELD_DURATION_TICKS - field.remainingTicks) * 0.35;
                for (int i = 0; i < 6; i++) {
                    double angle = baseAngle + (Math.PI * 2.0 * i) / 6.0;
                    double radius = 1.1 + (i % 3) * 1.1;
                    double px = center.x + Math.cos(angle) * radius;
                    double py = center.y + 0.35 + (i % 2) * 0.5;
                    double pz = center.z + Math.sin(angle) * radius;
                    world.spawnParticles(PURPLE_DUST, px, py, pz, 1, 0.05, 0.08, 0.05, 0.01);
                }
                world.spawnParticles(DEEP_PURPLE_DUST, pullCenter.x, pullCenter.y, pullCenter.z, 3, 0.35, 0.35, 0.35, 0.02);
                world.spawnParticles(ParticleTypes.PORTAL, pullCenter.x, pullCenter.y, pullCenter.z, 4, 0.45, 0.45, 0.45, 0.2);
            }
        }
    }

    private static void spawnMovingGravityFlightParticles(ServerPlayerEntity player, Vec3d currentPos, Vec3d prevPos) {
        Vec3d moveDelta = prevPos != null ? currentPos.subtract(prevPos) : Vec3d.ZERO;
        if (moveDelta.lengthSquared() > 9.0) {
            moveDelta = Vec3d.ZERO;
        }
        ServerWorld world = player.getServerWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        double baseVx = moveDelta.x * 0.85;
        double baseVy = moveDelta.y * 0.85 - 0.03;
        double baseVz = moveDelta.z * 0.85;

        for (int i = 0; i < 3; i++) {
            double fx = currentPos.x + (random.nextDouble() - 0.5) * 0.55;
            double fy = currentPos.y + 0.04 + random.nextDouble() * 0.25;
            double fz = currentPos.z + (random.nextDouble() - 0.5) * 0.55;
            world.spawnParticles(
                    i % 2 == 0 ? PURPLE_DUST : BLUE_DUST,
                    fx,
                    fy,
                    fz,
                    0,
                    baseVx + (random.nextDouble() - 0.5) * 0.03,
                    baseVy - random.nextDouble() * 0.02,
                    baseVz + (random.nextDouble() - 0.5) * 0.03,
                    1.0
            );
        }

        for (int i = 0; i < 2; i++) {
            double bx = currentPos.x + (random.nextDouble() - 0.5) * 0.85;
            double by = currentPos.y + 0.4 + random.nextDouble() * 1.1;
            double bz = currentPos.z + (random.nextDouble() - 0.5) * 0.85;
            world.spawnParticles(
                    i == 0 ? BLUE_DUST : PURPLE_DUST,
                    bx,
                    by,
                    bz,
                    0,
                    baseVx * 0.75 + (random.nextDouble() - 0.5) * 0.02,
                    baseVy * 0.75,
                    baseVz * 0.75 + (random.nextDouble() - 0.5) * 0.02,
                    1.0
            );
        }

        if (serverTickCounter % 2L == 0L) {
            world.spawnParticles(
                    ParticleTypes.WITCH,
                    currentPos.x,
                    currentPos.y + 0.15,
                    currentPos.z,
                    2,
                    0.28,
                    0.12,
                    0.28,
                    0.01
            );
        }
    }

    public static void clearServer() {
        METEOR_COOLDOWN_UNTIL_MS.clear();
        REPULSION_COOLDOWN_UNTIL_MS.clear();
        FIELD_COOLDOWN_UNTIL_MS.clear();
        LAST_RIGHT_CLICK_TICK.clear();
        ACTIVE_METEORS.clear();
        ACTIVE_FIELDS.clear();
        FLIGHT_GRANTED_PLAYERS.clear();
        LAST_POSITIONS.clear();
        serverTickCounter = 0L;
    }
}
