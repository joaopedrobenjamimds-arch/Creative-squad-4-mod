package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerHealingStaffManager {
    public static final int INSTANT_COOLDOWN_TICKS = 100;
    public static final long INSTANT_COOLDOWN_MS = 5_000L;
    public static final long AREA_COOLDOWN_MS = 15_000L;
    public static final long PURIFY_COOLDOWN_MS = 12_000L;
    public static final long LAST_CHANCE_COOLDOWN_MS = 60_000L;
    public static final float INSTANT_HEAL_AMOUNT = 8.0F;
    public static final float AREA_HEAL_AMOUNT = 8.0F;
    public static final double AREA_RADIUS = 6.0;
    public static final int BLESSING_REGEN_TICKS = 60;
    public static final float LAST_CHANCE_THRESHOLD_HP = 6.0F;
    public static final float LAST_CHANCE_HEAL_AMOUNT = 10.0F;

    public static final Identifier INSTANT_COOLDOWN_GROUP_ID = Identifier.of(
            CajadosMagicosMod.MOD_ID,
            StaffManager.CAJADO_CURA_ID + "_instantanea"
    );

    private static final Map<UUID, Long> INSTANT_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> AREA_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> PURIFY_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_CHANCE_COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Set<UUID> LAST_CHANCE_NEEDS_RECOVERY = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> BLESSING_ACTIVE_HOLDERS = ConcurrentHashMap.newKeySet();
    private static long serverTickCounter = 0L;

    private ServerHealingStaffManager() {
    }

    public static boolean tryUseHealingStaff(ServerPlayerEntity player) {
        if (player == null) {
            return false;
        }
        if (player.isSneaking()) {
            boolean areaHealed = tryCastAreaHeal(player);
            boolean purified = tryPurify(player, !areaHealed);
            return areaHealed || purified;
        }
        boolean instantHealed = tryCastInstantHeal(player);
        boolean purified = tryPurify(player, !instantHealed);
        return instantHealed || purified;
    }

    private static boolean tryCastInstantHeal(ServerPlayerEntity player) {
        long now = System.currentTimeMillis();
        Long until = INSTANT_COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until != null && until > now) {
            int remainingTicks = Math.min(
                    INSTANT_COOLDOWN_TICKS,
                    Math.max(1, (int) Math.ceil((until - now) / 50.0))
            );
            player.getItemCooldownManager().set(INSTANT_COOLDOWN_GROUP_ID, remainingTicks);
            return false;
        }

        INSTANT_COOLDOWN_UNTIL_MS.put(player.getUuid(), now + INSTANT_COOLDOWN_MS);
        player.getItemCooldownManager().set(INSTANT_COOLDOWN_GROUP_ID, INSTANT_COOLDOWN_TICKS);

        player.heal(INSTANT_HEAL_AMOUNT);

        ServerWorld world = player.getServerWorld();
        Vec3d pos = player.getPos();
        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, pos.x, pos.y + 1.0, pos.z, 24, 0.55, 0.65, 0.55, 0.08);
        world.spawnParticles(ParticleTypes.GLOW, pos.x, pos.y + 1.0, pos.z, 18, 0.45, 0.55, 0.45, 0.05);
        world.spawnParticles(ParticleTypes.HEART, pos.x, pos.y + 1.3, pos.z, 6, 0.35, 0.3, 0.35, 0.02);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                SoundCategory.PLAYERS,
                1.0F,
                1.35F
        );
        return true;
    }

    private static boolean tryCastAreaHeal(ServerPlayerEntity player) {
        long now = System.currentTimeMillis();
        Long until = AREA_COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until != null && until > now) {
            int secondsLeft = Math.max(1, (int) Math.ceil((until - now) / 1000.0));
            player.sendMessage(
                    Text.literal("Cura em Área em recarga: " + secondsLeft + "s")
                            .formatted(Formatting.GREEN),
                    true
            );
            return false;
        }

        AREA_COOLDOWN_UNTIL_MS.put(player.getUuid(), now + AREA_COOLDOWN_MS);

        ServerWorld world = player.getServerWorld();
        Vec3d center = player.getPos();
        List<ServerPlayerEntity> healedPlayers = new ArrayList<>();
        healedPlayers.add(player);

        Box areaBox = player.getBoundingBox().expand(AREA_RADIUS);
        List<Entity> nearby = world.getOtherEntities(
                player,
                areaBox,
                entity -> entity instanceof ServerPlayerEntity other
                        && isAlliedPlayer(player, other)
                        && other.squaredDistanceTo(player) <= AREA_RADIUS * AREA_RADIUS
        );
        for (Entity entity : nearby) {
            healedPlayers.add((ServerPlayerEntity) entity);
        }

        for (ServerPlayerEntity ally : healedPlayers) {
            ally.heal(AREA_HEAL_AMOUNT);
            Vec3d allyPos = ally.getPos();
            world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, allyPos.x, allyPos.y + 1.0, allyPos.z, 20, 0.5, 0.6, 0.5, 0.06);
            world.spawnParticles(ParticleTypes.HEART, allyPos.x, allyPos.y + 1.3, allyPos.z, 6, 0.35, 0.3, 0.35, 0.02);
            world.spawnParticles(ParticleTypes.GLOW, allyPos.x, allyPos.y + 1.0, allyPos.z, 12, 0.4, 0.5, 0.4, 0.04);
        }

        for (int i = 0; i < 36; i++) {
            double angle = (Math.PI * 2.0 * i) / 36.0;
            double rx = center.x + Math.cos(angle) * AREA_RADIUS;
            double rz = center.z + Math.sin(angle) * AREA_RADIUS;
            world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, rx, center.y + 0.4, rz, 2, 0.15, 0.25, 0.15, 0.03);
            world.spawnParticles(ParticleTypes.GLOW, rx, center.y + 0.5, rz, 1, 0.1, 0.2, 0.1, 0.02);
        }

        world.playSound(
                null,
                center.x,
                center.y,
                center.z,
                SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                SoundCategory.PLAYERS,
                1.3F,
                1.2F
        );
        return true;
    }

    private static boolean tryPurify(ServerPlayerEntity player, boolean showCooldownHint) {
        List<RegistryEntry<StatusEffect>> harmfulEffects = new ArrayList<>();
        for (StatusEffectInstance effect : player.getStatusEffects()) {
            if (effect.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL) {
                harmfulEffects.add(effect.getEffectType());
            }
        }
        if (harmfulEffects.isEmpty()) {
            return false;
        }

        long now = System.currentTimeMillis();
        Long until = PURIFY_COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until != null && until > now) {
            if (showCooldownHint) {
                int secondsLeft = Math.max(1, (int) Math.ceil((until - now) / 1000.0));
                player.sendMessage(
                        Text.literal("Purificação em recarga: " + secondsLeft + "s")
                                .formatted(Formatting.GREEN),
                        true
                );
            }
            return false;
        }

        PURIFY_COOLDOWN_UNTIL_MS.put(player.getUuid(), now + PURIFY_COOLDOWN_MS);
        for (RegistryEntry<StatusEffect> effectType : harmfulEffects) {
            player.removeStatusEffect(effectType);
        }

        ServerWorld world = player.getServerWorld();
        Vec3d pos = player.getPos();
        for (int i = 0; i < 20; i++) {
            double angle = (Math.PI * 2.0 * i) / 20.0;
            double px = pos.x + Math.cos(angle) * 0.85;
            double py = pos.y + 0.2 + (i * 0.09);
            double pz = pos.z + Math.sin(angle) * 0.85;
            world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, px, py, pz, 2, 0.08, 0.08, 0.08, 0.02);
            world.spawnParticles(ParticleTypes.GLOW, px, py, pz, 1, 0.05, 0.05, 0.05, 0.02);
        }
        world.spawnParticles(ParticleTypes.COMPOSTER, pos.x, pos.y + 1.0, pos.z, 20, 0.45, 0.65, 0.45, 0.08);
        world.spawnParticles(ParticleTypes.END_ROD, pos.x, pos.y + 1.0, pos.z, 10, 0.35, 0.5, 0.35, 0.05);
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                SoundCategory.PLAYERS,
                1.1F,
                1.5F
        );
        return true;
    }

    private static boolean isAlliedPlayer(ServerPlayerEntity holder, ServerPlayerEntity other) {
        if (!other.isAlive() || other.isSpectator()) {
            return false;
        }
        if (holder.getScoreboardTeam() != null) {
            return holder.isTeammate(other);
        }
        return other.getScoreboardTeam() == null;
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        Long instantUntil = INSTANT_COOLDOWN_UNTIL_MS.get(uuid);
        if (instantUntil != null) {
            long remainingMs = instantUntil - System.currentTimeMillis();
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(
                        INSTANT_COOLDOWN_TICKS,
                        Math.max(1, (int) Math.ceil(remainingMs / 50.0))
                );
                player.getItemCooldownManager().set(INSTANT_COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                INSTANT_COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }
    }

    public static void onDisconnect(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        removeBlessingIfPresent(player);
    }

    public static void tick(MinecraftServer server) {
        serverTickCounter++;
        long now = System.currentTimeMillis();

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            boolean hasStaff = player.isAlive() && !player.isSpectator() && StaffManager.hasCajadoCura(player);

            if (hasStaff) {
                BLESSING_ACTIVE_HOLDERS.add(uuid);
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.REGENERATION,
                        BLESSING_REGEN_TICKS,
                        0,
                        true,
                        false,
                        true
                ));

                if (serverTickCounter % 5L == 0L) {
                    player.getServerWorld().spawnParticles(
                            ParticleTypes.HAPPY_VILLAGER,
                            player.getX(),
                            player.getY() + 0.9,
                            player.getZ(),
                            2,
                            0.45,
                            0.45,
                            0.45,
                            0.01
                    );
                }

                float health = player.getHealth();
                if (health > LAST_CHANCE_THRESHOLD_HP) {
                    LAST_CHANCE_NEEDS_RECOVERY.remove(uuid);
                } else if (health > 0.0F && !LAST_CHANCE_NEEDS_RECOVERY.contains(uuid)) {
                    Long until = LAST_CHANCE_COOLDOWN_UNTIL_MS.get(uuid);
                    if (until == null || until <= now) {
                        LAST_CHANCE_COOLDOWN_UNTIL_MS.put(uuid, now + LAST_CHANCE_COOLDOWN_MS);
                        LAST_CHANCE_NEEDS_RECOVERY.add(uuid);
                        player.heal(LAST_CHANCE_HEAL_AMOUNT);

                        ServerWorld world = player.getServerWorld();
                        Vec3d pos = player.getPos();
                        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, pos.x, pos.y + 1.0, pos.z, 40, 0.7, 0.85, 0.7, 0.12);
                        world.spawnParticles(ParticleTypes.HEART, pos.x, pos.y + 1.2, pos.z, 16, 0.55, 0.55, 0.55, 0.04);
                        world.spawnParticles(ParticleTypes.GLOW, pos.x, pos.y + 1.0, pos.z, 26, 0.6, 0.75, 0.6, 0.08);
                        world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.x, pos.y + 1.1, pos.z, 28, 0.45, 0.65, 0.45, 0.25);
                        world.playSound(
                                null,
                                pos.x,
                                pos.y,
                                pos.z,
                                SoundEvents.ENTITY_PLAYER_LEVELUP,
                                SoundCategory.PLAYERS,
                                1.1F,
                                1.4F
                        );
                    }
                }
            } else {
                removeBlessingIfPresent(player);
                if (player.getHealth() > LAST_CHANCE_THRESHOLD_HP) {
                    LAST_CHANCE_NEEDS_RECOVERY.remove(uuid);
                }
            }
        }
    }

    private static void removeBlessingIfPresent(ServerPlayerEntity player) {
        if (BLESSING_ACTIVE_HOLDERS.remove(player.getUuid())) {
            StatusEffectInstance regen = player.getStatusEffect(StatusEffects.REGENERATION);
            if (regen != null && regen.getAmplifier() == 0 && regen.getDuration() <= BLESSING_REGEN_TICKS + 5) {
                player.removeStatusEffect(StatusEffects.REGENERATION);
            }
        }
    }

    public static void clearServer() {
        INSTANT_COOLDOWN_UNTIL_MS.clear();
        AREA_COOLDOWN_UNTIL_MS.clear();
        PURIFY_COOLDOWN_UNTIL_MS.clear();
        LAST_CHANCE_COOLDOWN_UNTIL_MS.clear();
        LAST_CHANCE_NEEDS_RECOVERY.clear();
        BLESSING_ACTIVE_HOLDERS.clear();
        serverTickCounter = 0L;
    }
}
