package com.cajados.magicos.staff;

import com.cajados.magicos.CajadosMagicosMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class ServerFireStaffManager {
    public static final int COOLDOWN_TICKS = 120;
    public static final long COOLDOWN_MS = 6_000L;
    public static final int ABILITY_HUNGER_COST = 10;
    public static final int FLIGHT_HUNGER_INTERVAL_TICKS = 300;
    public static final Identifier COOLDOWN_GROUP_ID = Identifier.of(CajadosMagicosMod.MOD_ID, StaffManager.CAJADO_FOGO_ID);
    public static final String PROJECTILE_TAG = "cajados_fogo_projetil";
    public static final float DIRECT_DAMAGE = 12.0F;
    public static final float SPLASH_DAMAGE = 6.0F;
    public static final double SPLASH_RADIUS = 2.25;

    private static final Map<UUID, Long> COOLDOWN_UNTIL_MS = new ConcurrentHashMap<>();
    private static final Set<UUID> FLIGHT_GRANTED_PLAYERS = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Vec3d> LAST_POSITIONS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> FLIGHT_DRAIN_TICKS = new ConcurrentHashMap<>();

    private ServerFireStaffManager() {
    }

    public static boolean tryCastFireball(ServerPlayerEntity player, ItemStack stack) {
        if (player == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        Long until = COOLDOWN_UNTIL_MS.get(player.getUuid());
        if (until != null && until > now) {
            int remainingTicks = Math.min(COOLDOWN_TICKS, Math.max(1, (int) Math.ceil((until - now) / 50.0)));
            player.getItemCooldownManager().set(COOLDOWN_GROUP_ID, remainingTicks);
            return false;
        }

        if (!player.isCreative() && !player.isSpectator()) {
            HungerManager hunger = player.getHungerManager();
            if (hunger.getFoodLevel() <= 0) {
                return false;
            }
            int nextFood = Math.max(0, hunger.getFoodLevel() - ABILITY_HUNGER_COST);
            hunger.setFoodLevel(nextFood);
            if (hunger.getSaturationLevel() > nextFood) {
                hunger.setSaturationLevel(nextFood);
            }
            if (nextFood <= 0 && FLIGHT_GRANTED_PLAYERS.remove(player.getUuid())) {
                player.getAbilities().allowFlying = false;
                player.getAbilities().flying = false;
                player.sendAbilitiesUpdate();
            }
        }

        COOLDOWN_UNTIL_MS.put(player.getUuid(), now + COOLDOWN_MS);
        player.getItemCooldownManager().set(COOLDOWN_GROUP_ID, COOLDOWN_TICKS);

        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d spawnPos = player.getEyePos().add(look.multiply(0.9));

        FireballEntity fireball = new FireballEntity(world, player, look, 0);
        fireball.setPosition(spawnPos);
        fireball.setVelocity(look.multiply(1.45));
        fireball.accelerationPower = 0.08;
        fireball.addCommandTag(PROJECTILE_TAG);
        world.spawnEntity(fireball);

        world.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENTITY_BLAZE_SHOOT,
                SoundCategory.PLAYERS,
                1.4F,
                0.95F
        );
        world.spawnParticles(ParticleTypes.FLAME, spawnPos.x, spawnPos.y, spawnPos.z, 10, 0.15, 0.15, 0.15, 0.05);
        return true;
    }

    public static void handleProjectileCollision(FireballEntity fireball, HitResult hitResult) {
        if (fireball == null || fireball.isRemoved() || !(fireball.getWorld() instanceof ServerWorld world)) {
            return;
        }
        Entity owner = fireball.getOwner();
        Entity directTarget = hitResult instanceof EntityHitResult entityHit ? entityHit.getEntity() : null;

        if (directTarget != null && directTarget.isAlive()) {
            directTarget.damage(world, fireball.getDamageSources().fireball(fireball, owner), DIRECT_DAMAGE);
            directTarget.setOnFireFor(5.0F);
        }

        Box splashBox = fireball.getBoundingBox().expand(SPLASH_RADIUS);
        List<Entity> nearby = world.getOtherEntities(
                fireball,
                splashBox,
                entity -> entity instanceof LivingEntity living && living.isAlive() && !entity.isSpectator()
        );
        for (Entity entity : nearby) {
            if (entity == directTarget) {
                continue;
            }
            if (entity == owner && fireball.squaredDistanceTo(entity) < 4.0) {
                continue;
            }
            entity.damage(world, fireball.getDamageSources().fireball(fireball, owner), SPLASH_DAMAGE);
            entity.setOnFireFor(3.0F);
        }

        Vec3d pos = fireball.getPos();
        world.playSound(
                null,
                pos.x,
                pos.y,
                pos.z,
                SoundEvents.ENTITY_GENERIC_EXPLODE.value(),
                SoundCategory.PLAYERS,
                1.1F,
                1.15F
        );
        world.spawnParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 28, 0.45, 0.45, 0.45, 0.12);
        world.spawnParticles(ParticleTypes.LAVA, pos.x, pos.y, pos.z, 10, 0.3, 0.3, 0.3, 0.08);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y, pos.z, 8, 0.35, 0.35, 0.35, 0.04);
        fireball.discard();
    }

    public static void onJoin(ServerPlayerEntity player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUuid();
        LAST_POSITIONS.put(uuid, player.getPos());

        Long until = COOLDOWN_UNTIL_MS.get(uuid);
        if (until != null) {
            long remainingMs = until - System.currentTimeMillis();
            if (remainingMs > 0L) {
                int remainingTicks = Math.min(COOLDOWN_TICKS, Math.max(1, (int) Math.ceil(remainingMs / 50.0)));
                player.getItemCooldownManager().set(COOLDOWN_GROUP_ID, remainingTicks);
            } else {
                COOLDOWN_UNTIL_MS.remove(uuid);
            }
        }

        if (!player.isCreative() && !player.isSpectator()) {
            if (player.isAlive() && StaffManager.hasCajadoFogo(player) && player.getHungerManager().getFoodLevel() > 0) {
                player.getAbilities().allowFlying = true;
                player.sendAbilitiesUpdate();
                FLIGHT_GRANTED_PLAYERS.add(uuid);
            } else if (player.getAbilities().allowFlying && !StaffManager.hasAnyFreeFlightStaff(player)) {
                player.getAbilities().allowFlying = false;
                player.getAbilities().flying = false;
                player.sendAbilitiesUpdate();
            }
        }
    }

    public static boolean canFlyWithFireStaff(ServerPlayerEntity player) {
        return player != null
                && player.isAlive()
                && !player.isCreative()
                && !player.isSpectator()
                && StaffManager.hasCajadoFogo(player)
                && player.getHungerManager().getFoodLevel() > 0;
    }

    public static void onDisconnect(UUID uuid) {
        FLIGHT_GRANTED_PLAYERS.remove(uuid);
        LAST_POSITIONS.remove(uuid);
        FLIGHT_DRAIN_TICKS.remove(uuid);
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            UUID uuid = player.getUuid();
            Vec3d currentPos = player.getPos();
            Vec3d prevPos = LAST_POSITIONS.put(uuid, currentPos);

            if (player.isCreative() || player.isSpectator()) {
                FLIGHT_GRANTED_PLAYERS.remove(uuid);
                FLIGHT_DRAIN_TICKS.remove(uuid);
                continue;
            }

            boolean hasStaff = player.isAlive() && StaffManager.hasCajadoFogo(player);
            boolean hasFreeFlightStaff = player.isAlive() && StaffManager.hasAnyFreeFlightStaff(player);
            if (hasStaff) {
                if (player.isOnFire()) {
                    player.extinguish();
                }
                HungerManager hunger = player.getHungerManager();
                if (hunger.getFoodLevel() > 0) {
                    if (!player.getAbilities().allowFlying || !FLIGHT_GRANTED_PLAYERS.contains(uuid)) {
                        player.getAbilities().allowFlying = true;
                        player.sendAbilitiesUpdate();
                        FLIGHT_GRANTED_PLAYERS.add(uuid);
                    }
                    if (player.getAbilities().flying) {
                        spawnMovingFlameParticles(player, currentPos, prevPos);
                        if (!hasFreeFlightStaff) {
                            int elapsed = FLIGHT_DRAIN_TICKS.getOrDefault(uuid, 0) + 1;
                            if (elapsed >= FLIGHT_HUNGER_INTERVAL_TICKS) {
                                FLIGHT_DRAIN_TICKS.put(uuid, 0);
                                int nextFood = Math.max(0, hunger.getFoodLevel() - 1);
                                hunger.setFoodLevel(nextFood);
                                if (hunger.getSaturationLevel() > nextFood) {
                                    hunger.setSaturationLevel(nextFood);
                                }
                                if (nextFood <= 0 && FLIGHT_GRANTED_PLAYERS.remove(uuid) && !hasFreeFlightStaff) {
                                    player.getAbilities().allowFlying = false;
                                    player.getAbilities().flying = false;
                                    player.sendAbilitiesUpdate();
                                }
                            } else {
                                FLIGHT_DRAIN_TICKS.put(uuid, elapsed);
                            }
                        } else {
                            FLIGHT_DRAIN_TICKS.remove(uuid);
                        }
                    }
                } else {
                    FLIGHT_DRAIN_TICKS.remove(uuid);
                    if (FLIGHT_GRANTED_PLAYERS.remove(uuid) && !hasFreeFlightStaff) {
                        player.getAbilities().allowFlying = false;
                        player.getAbilities().flying = false;
                        player.sendAbilitiesUpdate();
                    }
                }
            } else {
                FLIGHT_DRAIN_TICKS.remove(uuid);
                boolean wasGranted = FLIGHT_GRANTED_PLAYERS.remove(uuid);
                if (wasGranted && !hasFreeFlightStaff) {
                    player.getAbilities().allowFlying = false;
                    player.getAbilities().flying = false;
                    player.sendAbilitiesUpdate();
                }
            }
        }
    }

    private static void spawnMovingFlameParticles(ServerPlayerEntity player, Vec3d currentPos, Vec3d prevPos) {
        Vec3d moveDelta = prevPos != null ? currentPos.subtract(prevPos) : Vec3d.ZERO;
        if (moveDelta.lengthSquared() > 9.0) {
            moveDelta = Vec3d.ZERO;
        }
        ServerWorld world = player.getServerWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        double baseVx = moveDelta.x * 0.85;
        double baseVy = moveDelta.y * 0.85 - 0.05;
        double baseVz = moveDelta.z * 0.85;

        for (int i = 0; i < 4; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.65;
            double py = currentPos.y + 0.08 + random.nextDouble() * 0.85;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.65;
            double vx = baseVx + (random.nextDouble() - 0.5) * 0.04;
            double vy = baseVy - random.nextDouble() * 0.03;
            double vz = baseVz + (random.nextDouble() - 0.5) * 0.04;
            world.spawnParticles(ParticleTypes.FLAME, px, py, pz, 0, vx, vy, vz, 1.0);
        }

        for (int i = 0; i < 2; i++) {
            double px = currentPos.x + (random.nextDouble() - 0.5) * 0.55;
            double py = currentPos.y + 0.05 + random.nextDouble() * 0.65;
            double pz = currentPos.z + (random.nextDouble() - 0.5) * 0.55;
            world.spawnParticles(ParticleTypes.SMALL_FLAME, px, py, pz, 0, baseVx, baseVy - 0.02, baseVz, 1.0);
        }
    }

    public static void clearServer() {
        COOLDOWN_UNTIL_MS.clear();
        FLIGHT_GRANTED_PLAYERS.clear();
        LAST_POSITIONS.clear();
        FLIGHT_DRAIN_TICKS.clear();
    }
}
