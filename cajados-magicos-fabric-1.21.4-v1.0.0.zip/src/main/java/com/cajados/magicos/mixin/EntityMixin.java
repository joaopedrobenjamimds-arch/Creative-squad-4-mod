package com.cajados.magicos.mixin;

import com.cajados.magicos.staff.ServerFireStaffManager;
import com.cajados.magicos.staff.ServerGlacialStaffManager;
import com.cajados.magicos.staff.StaffManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "isFireImmune", at = @At("HEAD"), cancellable = true)
    private void cajados$fireStaffFireImmune(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity player && StaffManager.hasCajadoFogo(player)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void cajados$projectileTrails(CallbackInfo ci) {
        if ((Object) this instanceof FireballEntity fireball
                && fireball.getWorld() instanceof ServerWorld serverWorld
                && !fireball.isRemoved()
                && fireball.getCommandTags().contains(ServerFireStaffManager.PROJECTILE_TAG)) {
            serverWorld.spawnParticles(
                    ParticleTypes.FLAME,
                    fireball.getX(),
                    fireball.getY(),
                    fireball.getZ(),
                    4,
                    0.12,
                    0.12,
                    0.12,
                    0.02
            );
            serverWorld.spawnParticles(
                    ParticleTypes.SMALL_FLAME,
                    fireball.getX(),
                    fireball.getY(),
                    fireball.getZ(),
                    2,
                    0.1,
                    0.1,
                    0.1,
                    0.01
            );
            return;
        }

        if ((Object) this instanceof SnowballEntity snowball
                && snowball.getWorld() instanceof ServerWorld serverWorld
                && !snowball.isRemoved()
                && snowball.getCommandTags().contains(ServerGlacialStaffManager.PROJECTILE_TAG)) {
            if (snowball.age > 80) {
                snowball.discard();
                return;
            }
            serverWorld.spawnParticles(
                    ParticleTypes.SNOWFLAKE,
                    snowball.getX(),
                    snowball.getY(),
                    snowball.getZ(),
                    4,
                    0.1,
                    0.1,
                    0.1,
                    0.02
            );
            serverWorld.spawnParticles(
                    ParticleTypes.ITEM_SNOWBALL,
                    snowball.getX(),
                    snowball.getY(),
                    snowball.getZ(),
                    2,
                    0.06,
                    0.06,
                    0.06,
                    0.01
            );
        }
    }
}
