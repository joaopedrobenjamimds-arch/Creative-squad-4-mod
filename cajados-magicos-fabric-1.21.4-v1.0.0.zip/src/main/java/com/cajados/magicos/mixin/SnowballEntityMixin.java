package com.cajados.magicos.mixin;

import com.cajados.magicos.staff.ServerGlacialStaffManager;
import com.cajados.magicos.staff.ServerShadowStaffManager;
import com.cajados.magicos.staff.ServerThorStaffManager;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SnowballEntity.class)
public class SnowballEntityMixin {
    @Inject(method = "onCollision", at = @At("HEAD"), cancellable = true)
    private void cajados$onCustomProjectileCollision(HitResult hitResult, CallbackInfo ci) {
        SnowballEntity self = (SnowballEntity) (Object) this;
        if (!self.getWorld().isClient) {
            if (self.getCommandTags().contains(ServerGlacialStaffManager.PROJECTILE_TAG)) {
                ServerGlacialStaffManager.handleProjectileCollision(self, hitResult);
                ci.cancel();
                return;
            }
            if (self.getCommandTags().contains(ServerShadowStaffManager.PROJECTILE_TAG)) {
                ServerShadowStaffManager.handleProjectileCollision(self, hitResult);
                ci.cancel();
                return;
            }
            if (self.getCommandTags().contains(ServerThorStaffManager.PROJECTILE_TAG)) {
                ServerThorStaffManager.handleProjectileCollision(self, hitResult);
                ci.cancel();
            }
        }
    }
}
