package com.cajados.magicos.mixin;

import com.cajados.magicos.staff.ServerGravityStaffManager;
import net.minecraft.entity.FallingBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FallingBlockEntity.class)
public class FallingBlockEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void cajados$tickGravityMeteor(CallbackInfo ci) {
        FallingBlockEntity self = (FallingBlockEntity) (Object) this;
        if (!self.getWorld().isClient && self.getCommandTags().contains(ServerGravityStaffManager.METEOR_TAG)) {
            ServerGravityStaffManager.tickMeteor(self);
            ci.cancel();
        }
    }
}
