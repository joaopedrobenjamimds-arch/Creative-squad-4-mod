package com.cajados.magicos.mixin;

import com.cajados.magicos.staff.ServerGravityStaffManager;
import com.cajados.magicos.staff.ServerTeleportStaffManager;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public class ServerPlayNetworkHandlerMixin {
    @Shadow
    public ServerPlayerEntity player;

    @Inject(method = "onHandSwing", at = @At("TAIL"))
    private void cajados$onGravityStaffSwing(HandSwingC2SPacket packet, CallbackInfo ci) {
        if (packet.getHand() == Hand.MAIN_HAND && this.player != null) {
            ServerGravityStaffManager.tryHandleLeftClickSwing(this.player);
            ServerTeleportStaffManager.tryHandleLeftClickSwing(this.player);
        }
    }
}
