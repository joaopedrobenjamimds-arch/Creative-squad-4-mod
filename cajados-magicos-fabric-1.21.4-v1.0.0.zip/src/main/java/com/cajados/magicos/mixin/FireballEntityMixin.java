package com.cajados.magicos.mixin;

import com.cajados.magicos.staff.ServerFireStaffManager;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.util.hit.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FireballEntity.class)
public class FireballEntityMixin {
    @Inject(method = "onCollision", at = @At("HEAD"), cancellable = true)
    private void cajados$onFireStaffProjectileCollision(HitResult hitResult, CallbackInfo ci) {
        FireballEntity self = (FireballEntity) (Object) this;
        if (!self.getWorld().isClient && self.getCommandTags().contains(ServerFireStaffManager.PROJECTILE_TAG)) {
            ServerFireStaffManager.handleProjectileCollision(self, hitResult);
            ci.cancel();
        }
    }
}
