package com.cajados.magicos.mixin;

import com.cajados.magicos.staff.StaffManager;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void cajados$blockProtectedDamage(
            ServerWorld world,
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if ((Object) this instanceof PlayerEntity player) {
            if (source.isIn(DamageTypeTags.IS_FIRE) && StaffManager.hasCajadoFogo(player)) {
                player.extinguish();
                cir.setReturnValue(false);
                return;
            }
            if (source.isIn(DamageTypeTags.IS_FALL) && StaffManager.hasCajadoGravidade(player)) {
                player.fallDistance = 0.0F;
                cir.setReturnValue(false);
            }
        }
    }

    @Inject(method = "computeFallDamage", at = @At("HEAD"), cancellable = true)
    private void cajados$gravityStaffZeroFallDamage(
            float fallDistance,
            float damageMultiplier,
            CallbackInfoReturnable<Integer> cir
    ) {
        if ((Object) this instanceof PlayerEntity player && StaffManager.hasCajadoGravidade(player)) {
            player.fallDistance = 0.0F;
            cir.setReturnValue(0);
        }
    }

    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true, require = 0)
    private void cajados$gravityStaffSkipHandleFall(
            float fallDistance,
            float damageMultiplier,
            DamageSource damageSource,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if ((Object) this instanceof PlayerEntity player && StaffManager.hasCajadoGravidade(player)) {
            player.fallDistance = 0.0F;
            cir.setReturnValue(false);
        }
    }

    @Redirect(
            method = {"travelMidAir", "travel"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;getSlipperiness()F"
            ),
            require = 0
    )
    private float cajados$glacialStepsNormalTraction(Block block) {
        if ((Object) this instanceof PlayerEntity player
                && StaffManager.hasCajadoGlacial(player)
                && (block == Blocks.ICE
                        || block == Blocks.PACKED_ICE
                        || block == Blocks.BLUE_ICE
                        || block == Blocks.FROSTED_ICE)) {
            return 0.6F;
        }
        return block.getSlipperiness();
    }
}
