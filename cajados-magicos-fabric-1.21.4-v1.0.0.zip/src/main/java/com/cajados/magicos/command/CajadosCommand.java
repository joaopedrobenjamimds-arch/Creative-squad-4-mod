package com.cajados.magicos.command;

import com.cajados.magicos.staff.StaffManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

public final class CajadosCommand {
    private CajadosCommand() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                CommandManager.literal("cajados")
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes(context -> giveAllStaffs(context.getSource()))
                        .then(CommandManager.literal("todos")
                                .executes(context -> giveAllStaffs(context.getSource()))
                        )
                        .then(CommandManager.argument("cajado", StringArgumentType.greedyString())
                                .suggests((context, builder) -> {
                                    List<String> suggestions = new ArrayList<>(StaffManager.STAFF_COMMAND_NAMES.size() + 1);
                                    suggestions.add("todos");
                                    suggestions.addAll(StaffManager.STAFF_COMMAND_NAMES);
                                    return CommandSource.suggestMatching(suggestions, builder);
                                })
                                .executes(context -> {
                                    String name = StringArgumentType.getString(context, "cajado");
                                    if ("todos".equalsIgnoreCase(name.trim())) {
                                        return giveAllStaffs(context.getSource());
                                    }
                                    return giveStaff(context.getSource(), name);
                                })
                        )
        );
    }

    private static int giveAllStaffs(ServerCommandSource source) {
        try {
            ServerPlayerEntity player = source.getPlayerOrThrow();
            List<ItemStack> staffs = StaffManager.createAllStaffs();
            for (ItemStack staff : staffs) {
                player.giveOrDropStack(staff);
            }
            source.sendFeedback(
                    () -> Text.literal("Você recebeu todos os cajados (" + staffs.size() + ").")
                            .formatted(Formatting.GOLD),
                    false
            );
            return staffs.size();
        } catch (Exception e) {
            source.sendError(Text.literal("Este comando deve ser executado por um jogador."));
            return 0;
        }
    }

    private static int giveStaff(ServerCommandSource source, String name) {
        try {
            ServerPlayerEntity player = source.getPlayerOrThrow();
            ItemStack staff = StaffManager.createStaffByName(name);
            if (staff == null) {
                source.sendError(Text.literal(
                        "Cajado não encontrado: '" + name + "'. Opções: todos, "
                                + String.join(", ", StaffManager.STAFF_COMMAND_NAMES)
                ));
                return 0;
            }
            player.giveOrDropStack(staff);
            source.sendFeedback(
                    () -> Text.literal("Você recebeu o artefato: ")
                            .formatted(Formatting.GOLD)
                            .append(staff.getName().copy()),
                    false
            );
            return 1;
        } catch (Exception e) {
            source.sendError(Text.literal("Este comando deve ser executado por um jogador."));
            return 0;
        }
    }
}
