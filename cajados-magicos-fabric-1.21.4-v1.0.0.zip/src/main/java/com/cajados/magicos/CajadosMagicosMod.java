package com.cajados.magicos;

import com.cajados.magicos.command.CajadosCommand;
import com.cajados.magicos.staff.ServerFireStaffManager;
import com.cajados.magicos.staff.ServerGlacialStaffManager;
import com.cajados.magicos.staff.ServerGravityStaffManager;
import com.cajados.magicos.staff.ServerHealingStaffManager;
import com.cajados.magicos.staff.ServerShadowStaffManager;
import com.cajados.magicos.staff.ServerTeleportStaffManager;
import com.cajados.magicos.staff.ServerThorStaffManager;
import com.cajados.magicos.staff.StaffManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;

public class CajadosMagicosMod implements ModInitializer {
    public static final String MOD_ID = "cajadosmagicos";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                CajadosCommand.register(dispatcher)
        );

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);

            if (StaffManager.isCajadoFogo(stack)) {
                if (world.isClient) {
                    if (!player.isCreative() && !player.isSpectator() && player.getHungerManager().getFoodLevel() <= 0) {
                        return ActionResult.FAIL;
                    }
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.SUCCESS;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    boolean fired = ServerFireStaffManager.tryCastFireball(serverPlayer, stack);
                    return fired ? ActionResult.SUCCESS : ActionResult.FAIL;
                }
                return ActionResult.PASS;
            }

            if (StaffManager.isCajadoGlacial(stack)) {
                if (world.isClient) {
                    if (player.isSneaking()) {
                        return ActionResult.SUCCESS;
                    }
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.SUCCESS;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    boolean activated = serverPlayer.isSneaking()
                            ? ServerGlacialStaffManager.tryCastAreaFreeze(serverPlayer)
                            : ServerGlacialStaffManager.tryCastProjectile(serverPlayer);
                    return activated ? ActionResult.SUCCESS : ActionResult.FAIL;
                }
                return ActionResult.PASS;
            }

            if (StaffManager.isCajadoCura(stack)) {
                if (world.isClient) {
                    boolean hasNegative = player.getStatusEffects().stream()
                            .anyMatch(effect -> effect.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL);
                    if (player.isSneaking() || hasNegative) {
                        return ActionResult.SUCCESS;
                    }
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.SUCCESS;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    boolean activated = ServerHealingStaffManager.tryUseHealingStaff(serverPlayer);
                    return activated ? ActionResult.SUCCESS : ActionResult.FAIL;
                }
                return ActionResult.PASS;
            }

            if (StaffManager.isCajadoGravidade(stack)) {
                if (world.isClient) {
                    if (player.isSneaking()) {
                        return ActionResult.CONSUME;
                    }
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.CONSUME;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    ServerGravityStaffManager.markRightClick(serverPlayer.getUuid());
                    boolean activated = ServerGravityStaffManager.tryUseGravityStaff(serverPlayer);
                    return activated ? ActionResult.CONSUME : ActionResult.FAIL;
                }
                return ActionResult.PASS;
            }

            if (StaffManager.isCajadoTeleporte(stack)) {
                if (world.isClient) {
                    if (player.isSneaking()) {
                        return ActionResult.CONSUME;
                    }
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.CONSUME;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    ServerTeleportStaffManager.markRightClick(serverPlayer.getUuid());
                    boolean activated = ServerTeleportStaffManager.tryUseTeleportStaff(serverPlayer);
                    return activated ? ActionResult.CONSUME : ActionResult.FAIL;
                }
                return ActionResult.CONSUME;
            }

            if (StaffManager.isCajadoSombras(stack)) {
                if (world.isClient) {
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.CONSUME;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    ServerShadowStaffManager.markRightClick(serverPlayer.getUuid());
                    boolean activated = ServerShadowStaffManager.tryCastShadowTeleport(serverPlayer);
                    return activated ? ActionResult.CONSUME : ActionResult.FAIL;
                }
                return ActionResult.CONSUME;
            }

            if (StaffManager.isCajadoThor(stack)) {
                if (world.isClient) {
                    if (player.isSneaking()) {
                        return ActionResult.CONSUME;
                    }
                    return player.getItemCooldownManager().isCoolingDown(stack)
                            ? ActionResult.FAIL
                            : ActionResult.CONSUME;
                }
                if (player instanceof ServerPlayerEntity serverPlayer) {
                    ServerThorStaffManager.markRightClick(serverPlayer.getUuid());
                    boolean activated = ServerThorStaffManager.tryUseThorStaff(serverPlayer);
                    return activated ? ActionResult.CONSUME : ActionResult.FAIL;
                }
                return ActionResult.CONSUME;
            }

            return ActionResult.PASS;
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerFireStaffManager.onJoin(handler.player);
            ServerGlacialStaffManager.onJoin(handler.player);
            ServerHealingStaffManager.onJoin(handler.player);
            ServerGravityStaffManager.onJoin(handler.player);
            ServerTeleportStaffManager.onJoin(handler.player);
            ServerShadowStaffManager.onJoin(handler.player);
            ServerThorStaffManager.onJoin(handler.player);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerFireStaffManager.onDisconnect(handler.player.getUuid());
            ServerGlacialStaffManager.onDisconnect(server, handler.player.getUuid());
            ServerHealingStaffManager.onDisconnect(handler.player);
            ServerGravityStaffManager.onDisconnect(handler.player);
            ServerTeleportStaffManager.onDisconnect(handler.player);
            ServerShadowStaffManager.onDisconnect(handler.player);
            ServerThorStaffManager.onDisconnect(handler.player);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            ServerFireStaffManager.tick(server);
            ServerGlacialStaffManager.tick(server);
            ServerHealingStaffManager.tick(server);
            ServerGravityStaffManager.tick(server);
            ServerTeleportStaffManager.tick(server);
            ServerShadowStaffManager.tick(server);
            ServerThorStaffManager.tick(server);
        });

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            ServerFireStaffManager.clearServer();
            ServerGlacialStaffManager.clearServer(null);
            ServerHealingStaffManager.clearServer();
            ServerGravityStaffManager.clearServer();
            ServerTeleportStaffManager.clearServer();
            ServerShadowStaffManager.clearServer();
            ServerThorStaffManager.clearServer();
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server ->
                ServerGlacialStaffManager.clearServer(server)
        );

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            ServerFireStaffManager.clearServer();
            ServerGlacialStaffManager.clearServer(null);
            ServerHealingStaffManager.clearServer();
            ServerGravityStaffManager.clearServer();
            ServerTeleportStaffManager.clearServer();
            ServerShadowStaffManager.clearServer();
            ServerThorStaffManager.clearServer();
        });
    }
}
